"""Acquisition only: three public official articles; no app installation needed."""
import hashlib
import json
import time
import urllib.error
import urllib.request
from datetime import UTC, datetime
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

URLS = {
    'tenure.html': 'https://www.nba.com/raptors/news/raptors-extend-poeltl',
    'trade.html': 'https://www.nba.com/raptors/news/raptors-acquire-poeltl-from-san-antonio',
    'return.html': 'https://www.nba.com/raptors/news/raptors-re-sign-poeltl',
}


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def main():
    root = Path(__file__).resolve().parent / 'membership-capture'
    root.mkdir(exist_ok=False)
    opener = urllib.request.build_opener(NoRedirect)
    records = []
    for filename, url in URLS.items():
        record = dict(file=filename, url=url, captured_at=datetime.now(UTC).isoformat())
        try:
            request = urllib.request.Request(url, headers={'User-Agent': 'NBA-Tools-bounded-public-acquisition/1.0'})
            try:
                response = opener.open(request, timeout=30)
            except urllib.error.HTTPError as error:
                response = error
            with response:
                body = response.read(4_000_001)
                record['http_status'] = response.code
            if len(body) > 4_000_000:
                raise ValueError('Response exceeds4MB cap; quarantined, not usable')
            (root / filename).write_bytes(body)
            record.update(sha256=hashlib.sha256(body).hexdigest(), size_bytes=len(body),
                          state='received_unqualified' if record['http_status'] == 200 else 'quarantined_http_failure')
        except Exception as error:
            record.update(state='failed', error=f'{type(error).__name__}: {error}')
        records.append(record)
        (root / 'receipt.json').write_text(json.dumps(dict(classification='original_capture_only_not_qualified', records=records), indent=2) + '\n')
        print(filename + ': ' + record['state'])
        time.sleep(1)
    with ZipFile(root / 'collection.zip', 'x', compression=ZIP_DEFLATED) as archive:
        archive.write(root / 'receipt.json', 'receipt.json')
        for filename in URLS:
            if (root / filename).is_file():
                archive.write(root / filename, 'sources/' + filename)
    print('Return membership-capture/collection.zip, including any failures.')
    print('No data was published or qualified. No automatic retry is configured.')


if __name__ == '__main__':
    main()
