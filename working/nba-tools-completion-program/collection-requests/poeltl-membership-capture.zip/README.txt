NBA Tools: bounded membership evidence capture

Use the existing acquisition laptop with Python3. No app checkout, install,
credentials, paid service or settings change is needed.

1. Extract this ZIP to a new folder.
2. Mac: open Capture.command. Windows: open Capture.bat.
3. Return membership-capture/collection.zip, including if requests failed.

The helper makes one request each to3 fixed public NBA article URLs. It never
retries, follows redirects, asks for login, publishes data or changes a pointer.
It preserves literal responses and hashes. A403 body is quarantined, not evidence.
If a launcher is unavailable, run python3 capture_membership.py in this folder.
Do not rerun a failed capture without a new diagnosis; return the ZIP instead.

Why this is needed: the approved cloud runner returned403 for the official tenure
article. The app and all20 successful archive originals are already retained.
Cloud agents will qualify the returned sources, test the exact game populations,
obtain review and perform routine merges. A successful capture alone is not NBA
qualification or production publication.
