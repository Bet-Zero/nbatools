#!/bin/sh
cd "$(dirname "$0")" || exit 1
python3 capture_membership.py
printf '\nPress Return to close.\n'
read -r answer
