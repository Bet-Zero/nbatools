# Raw Query Answer QA Report

## Run Metadata

- Run ID: `r2_validation`
- Started: `2026-11-06T06:54:42.815069+00:00`
- Completed: `2026-11-06T06:54:48.948426+00:00`
- Corpus: `qa/raw_query_answer_corpus.yaml`
- Slices: `[]`
- Cases: `1`

## Summary Counts

- Result statuses: `{'ok': 1}`
- Categories: `{'participation': 1}`
- Routes: `{'game_finder': 1}`
- Manual review statuses: `{'unreviewed': 1}`
- Manual review tags: `{}`
- Answer text policies: `{'requires_backend_answer_text': 1}`
- Answer text statuses: `{'backend_answer_text_present': 1}`
- Suspicious flag cases: `0`
- Suspicious flags: `{}`
- Informational flag cases: `0`
- Informational flags: `{}`
- Verified outlier cases: `0`
- Verified outliers: `{}`
- Suggested review tags: `{}`
- Expectation cases: `{'pass': 1}`
- Expectation checks: `{'pass': 7}`
- Failed case IDs: `[]`

## Slowest Cases

| Case | Seconds | Status | Route |
|---|---:|---|---|
| k08_compact_home_absence_season | 6.133 | ok | game_finder |

## Suspicious / Review Flags

_None._

## Informational Flags

_None._

## Verified Outliers

_None._

## Failed Expectations

_None._

## Query Review Cards

### k08_compact_home_absence_season

#### k08_compact_home_absence_season

**Query**  
how many home games did LeBron miss in2025-26

**Answer shown**  
LeBron James missed 11 Lakers home games in the 2025-26 regular season.

**Rendered output**

##### Table — Game Detail

Subject: Los Angeles Lakers  
Mode: Team game log  
Filter: Without player: LeBron James; Location: Home  
Table type: team_game_log  
Column schema: team_game_log_default  
Rows: 11  

| # | Date | Team |  | Opp | W/L | PTS | Margin | REB | AST | 3PM | FG | 3P | FT | TOV | STL | BLK | oreb | dreb |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Apr 7 | LAL |  | OKC | L | 87 | — | 38 | 26 | 9 | — | — | — | 17 | 7 | 3 | 8 | 30 |
| 2 | Mar 10 | LAL |  | MIN | W | 120 | — | 47 | 31 | 11 | — | — | — | 6 | 7 | 2 | 14 | 33 |
| 3 | Mar 8 | LAL |  | NYK | W | 110 | — | 42 | 20 | 15 | — | — | — | 13 | 10 | 5 | 12 | 30 |

- Query: `how many home games did LeBron miss in2025-26`
- Category: `participation`
- Priority: `p1`
- Status: `ok`
- Reason: `<none>`
- Route: `game_finder`
- Intent: `finder`
- Query class: `count`
- Shape hint: `count_with_finder`
- Shape source: `backend_approximation`
- Answer text policy: `requires_backend_answer_text`
- Answer text status: backend answer text present
- Backend answer text: LeBron James missed 11 Lakers home games in the 2025-26 regular season.
- Answer summary: Count: 11
- Filters: `Without player=LeBron James (player)`, `Location=Home (location)`
- Sections: `count` 1 row(s), `finder` 11 row(s)
- Expectations: `pass` (7 pass, 0 fail)
- Review notes: Compact IN+season must preserve the absence predicate and home scope. PR559's qualified published generation contains22explicit DNP observations,11home. Appearance omission is not the oracle; no injury, tenure or current-freshness claim.
- Manual review: `unreviewed`

Section `count`

- Rows: `1`
- Columns: count

| count |
| --- |
| 11 |

Section `finder`

- Rows: `11`
- Columns: rank, game_date, game_id, season, season_type, team_name, team_abbr, opponent_team_name, opponent_team_abbr, is_home, is_away, wl, ...

| rank | team_name | team_abbr | season | game_date | opponent_team_abbr | wl | pts | reb | ast |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Los Angeles Lakers | LAL | 2025-26 | 2026-04-07T00:00:00 | OKC | L | 87 | 38 | 26 |
| 2 | Los Angeles Lakers | LAL | 2025-26 | 2026-03-10T00:00:00 | MIN | W | 120 | 47 | 31 |
| 3 | Los Angeles Lakers | LAL | 2025-26 | 2026-03-08T00:00:00 | NYK | W | 110 | 42 | 20 |
