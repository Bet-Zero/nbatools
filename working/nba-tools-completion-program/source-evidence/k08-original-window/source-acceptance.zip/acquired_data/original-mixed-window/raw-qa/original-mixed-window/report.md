# Raw Query Answer QA Report

## Run Metadata

- Run ID: `original-mixed-window`
- Started: `2026-11-01T05:09:08.023437+00:00`
- Completed: `2026-11-01T05:09:08.619464+00:00`
- Corpus: `qa/raw_query_answer_corpus.yaml`
- Slices: `[]`
- Cases: `3`

## Summary Counts

- Result statuses: `{'no_result': 1, 'ok': 2}`
- Categories: `{'participation': 3}`
- Routes: `{'team_record': 3}`
- Manual review statuses: `{'unreviewed': 3}`
- Manual review tags: `{}`
- Answer text policies: `{'frontend_hero_expected': 2, 'no_answer_text_expected': 1}`
- Answer text statuses: `{'frontend_hero_expected': 2, 'no_answer_text_expected': 1}`
- Suspicious flag cases: `0`
- Suspicious flags: `{}`
- Informational flag cases: `2`
- Informational flags: `{'frontend_hero_expected': 2}`
- Verified outlier cases: `0`
- Verified outliers: `{}`
- Suggested review tags: `{}`
- Expectation cases: `{'pass': 3}`
- Expectation checks: `{'pass': 33}`
- Failed case IDs: `[]`

## Slowest Cases

| Case | Seconds | Status | Route |
|---|---:|---|---|
| k08_original_mixed_team_bound | 0.22 | ok | team_record |
| k08_original_mixed_record | 0.196 | ok | team_record |
| k08_original_mixed_qualified_empty | 0.18 | no_result | team_record |

## Suspicious / Review Flags

_None._

## Informational Flags

| Case | Flags | Answer text policy | Answer text status |
|---|---|---|---|
| k08_original_mixed_record | frontend_hero_expected | frontend_hero_expected | frontend-rendered hero expected |
| k08_original_mixed_team_bound | frontend_hero_expected | frontend_hero_expected | frontend-rendered hero expected |

## Verified Outliers

_None._

## Failed Expectations

_None._

## Query Review Cards

### k08_original_mixed_record

#### k08_original_mixed_record

**Query**  
Lakers record within their last 20 games without LeBron James and with Luka Doncic in 2025-26

**Answer shown**  
The Los Angeles Lakers are 3-0 in 2025-26 Regular Season, a 100% win rate.

**Rendered output**

##### Card — Team Record

Subject: Los Angeles Lakers  
Mode: Team record  
Filter: Without player: LeBron James; With player: Luka Doncic; Last N games: 20; Sample selection: Select the last 20 original games before checking participation predicates  
Record: 3-0  
Games: 3  
Win %: 100.0%  
PPG: 119.3  
+/-: 12.7  

##### Table — Team record

Subject: Los Angeles Lakers  
Mode: Team record  
Filter: Without player: LeBron James; With player: Luka Doncic; Last N games: 20; Sample selection: Select the last 20 original games before checking participation predicates  
Table type: record_summary  
Column schema: team_record_summary_default  
Rows: 1  

| Team | W-L | Games | Win % | PPG | +/- |
| --- | --- | --- | --- | --- | --- |
| Los Angeles Lakers | 3-0 | 3 | 100.0% | 119.3 | 12.7 |

##### Detail — Game Detail

Subject: Los Angeles Lakers  
Mode: Team game log  
Filter: Without player: LeBron James; With player: Luka Doncic; Last N games: 20; Sample selection: Select the last 20 original games before checking participation predicates  
Table type: team_game_log  
Column schema: team_game_log_default  
Rows: 3  
Collapsed label: Show game detail  

| # | Date | Team |  | Opp | Score | W/L | PTS | Opp PTS | Margin | REB | AST | 3PM | FG | 3P | FT | TOV | STL | BLK | oreb | dreb |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Mar 6 | LAL |  | IND | 128-117 | W | 128 | 117 | — | 43 | 25 | 17 | — | — | — | 12 | 5 | 2 | 6 | 37 |
| 2 | Mar 8 | LAL |  | NYK | 110-97 | W | 110 | 97 | — | 42 | 20 | 15 | — | — | — | 13 | 10 | 5 | 12 | 30 |
| 3 | Mar 10 | LAL |  | MIN | 120-106 | W | 120 | 106 | — | 47 | 31 | 11 | — | — | — | 6 | 7 | 2 | 14 | 33 |

- Query: `Lakers record within their last 20 games without LeBron James and with Luka Doncic in 2025-26`
- Category: `participation`
- Priority: `p1`
- Status: `ok`
- Reason: `<none>`
- Route: `team_record`
- Intent: `summary`
- Query class: `summary`
- Shape hint: `team_record`
- Shape source: `backend_approximation`
- Answer text policy: `frontend_hero_expected`
- Answer text status: frontend-rendered hero expected
- Backend answer text: _not backend-provided_
- Answer summary: Los Angeles Lakers -- 3-0 over 3 games, 119.333 PPG, 44 RPG, 25.333 APG, Regular Season
- Filters: `Without player=LeBron James (player)`, `With player=Luka Doncic (player)`, `Last N games=20 (window)`, `Sample selection=Select the last 20 original games before checking participation predicates (window)`
- Sections: `summary` 1 row(s), `by_season` 1 row(s), `game_log` 3 row(s)
- Expectations: `pass` (15 pass, 0 fail)
- Review notes: Immutable published 82-game LeBron participation and positive 64 Luka appearances select only March 6/8/10 inside the original last 20 LAL games. Independent raw team totals are3–0 / 358 points; qualifying-first would select 15 games / 11–4 / 1736 points. No complete Luka DNP claim.
- Manual review: `unreviewed`
- Informational flags: `frontend_hero_expected`
- Notes: `['Original window selected 20 game(s) before testing participation predicates']`
- Caveats: `['record filtered to games with Luka Doncic', 'record filtered to games without LeBron James', 'last 20 original games (selected 20; participation matched in 3)']`

Section `summary`

- Rows: `1`
- Columns: team_name, season_start, season_end, season_type, games, wins, losses, win_pct, pts_avg, reb_avg, ast_avg, fg3m_avg, ...

| team_name | season_start | season_end | games | wins | losses | win_pct | pts_avg | reb_avg | ast_avg |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Los Angeles Lakers | 2025-26 | 2025-26 | 3 | 3 | 0 | 1 | 119.333 | 44 | 25.333 |

Section `by_season`

- Rows: `1`
- Columns: season, games, wins, losses, pts_avg, reb_avg, ast_avg, fg3m_avg, tov_avg, plus_minus_avg, efg_pct_avg, ts_pct_avg, ...

| season | games | wins | losses | win_pct | pts_avg | reb_avg | ast_avg | fg3m_avg | tov_avg |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2025-26 | 3 | 3 | 0 | 1 | 119.333 | 44 | 25.333 | 14.333 | 10.333 |

Section `game_log`

- Rows: `3`
- Columns: game_date, game_id, season, season_type, team_id, team_abbr, team_name, opponent_team_id, opponent_team_abbr, opponent_team_name, is_home, is_away, ...

| team_name | team_abbr | season | game_date | opponent_team_abbr | wl | pts | reb | ast | game_id |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Los Angeles Lakers | LAL | 2025-26 | 2026-03-06 | IND | W | 128 | 43 | 25 | 22500914 |
| Los Angeles Lakers | LAL | 2025-26 | 2026-03-08 | NYK | W | 110 | 42 | 20 | 22500922 |
| Los Angeles Lakers | LAL | 2025-26 | 2026-03-10 | MIN | W | 120 | 47 | 31 | 22500946 |

### k08_original_mixed_team_bound

#### k08_original_mixed_team_bound

**Query**  
Lakers record without LeBron James and with Luka Doncic within their last 20 games in 2025-26 where the Lakers scored at least 120 points

**Answer shown**  
The Los Angeles Lakers are 2-0 in 2025-26 Regular Season, a 100% win rate.

**Rendered output**

##### Card — Team Record

Subject: Los Angeles Lakers  
Mode: Team record  
Filter: Without player: LeBron James; With player: Luka Doncic; pts min: 120.0; Last N games: 20; Sample selection: Select the last 20 original games before checking participation predicates  
Record: 2-0  
Games: 2  
Win %: 100.0%  
PPG: 124.0  
+/-: 12.5  

##### Table — Team record

Subject: Los Angeles Lakers  
Mode: Team record  
Filter: Without player: LeBron James; With player: Luka Doncic; pts min: 120.0; Last N games: 20; Sample selection: Select the last 20 original games before checking participation predicates  
Table type: record_summary  
Column schema: team_record_summary_default  
Rows: 1  

| Team | W-L | Games | Win % | PPG | +/- |
| --- | --- | --- | --- | --- | --- |
| Los Angeles Lakers | 2-0 | 2 | 100.0% | 124.0 | 12.5 |

##### Detail — Game Detail

Subject: Los Angeles Lakers  
Mode: Team game log  
Filter: Without player: LeBron James; With player: Luka Doncic; pts min: 120.0; Last N games: 20; Sample selection: Select the last 20 original games before checking participation predicates  
Table type: team_game_log  
Column schema: team_game_log_default  
Rows: 2  
Collapsed label: Show game detail  

| # | Date | Team |  | Opp | Score | W/L | PTS | Opp PTS | Margin | REB | AST | 3PM | FG | 3P | FT | TOV | STL | BLK | oreb | dreb |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Mar 6 | LAL |  | IND | 128-117 | W | 128 | 117 | — | 43 | 25 | 17 | — | — | — | 12 | 5 | 2 | 6 | 37 |
| 2 | Mar 10 | LAL |  | MIN | 120-106 | W | 120 | 106 | — | 47 | 31 | 11 | — | — | — | 6 | 7 | 2 | 14 | 33 |

- Query: `Lakers record without LeBron James and with Luka Doncic within their last 20 games in 2025-26 where the Lakers scored at least 120 points`
- Category: `participation`
- Priority: `p1`
- Status: `ok`
- Reason: `<none>`
- Route: `team_record`
- Intent: `summary`
- Query class: `summary`
- Shape hint: `team_record`
- Shape source: `backend_approximation`
- Answer text policy: `frontend_hero_expected`
- Answer text status: frontend-rendered hero expected
- Backend answer text: _not backend-provided_
- Answer summary: Los Angeles Lakers -- 2-0 over 2 games, 124 PPG, 45 RPG, 28 APG, Regular Season
- Filters: `Without player=LeBron James (player)`, `With player=Luka Doncic (player)`, `pts min=120.0 (threshold)`, `Last N games=20 (window)`, `Sample selection=Select the last 20 original games before checking participation predicates (window)`
- Sections: `summary` 1 row(s), `by_season` 1 row(s), `game_log` 2 row(s)
- Expectations: `pass` (12 pass, 0 fail)
- Review notes: The same original 20-game population is qualified before either participation intersection or the explicit team-owned 120-point condition. March 8 (LAL 110) is excluded; March 6/10 total 248 points. The bound does not belong to Luka or LeBron.
- Manual review: `unreviewed`
- Informational flags: `frontend_hero_expected`
- Notes: `['Original window selected 20 game(s) before testing participation predicates']`
- Caveats: `['record filtered to games with Luka Doncic', 'record filtered to games without LeBron James', 'record in games where pts >= 120.0', 'last 20 original games (selected 20; participation matched in 3)']`

Section `summary`

- Rows: `1`
- Columns: team_name, season_start, season_end, season_type, games, wins, losses, win_pct, pts_avg, reb_avg, ast_avg, fg3m_avg, ...

| team_name | season_start | season_end | games | wins | losses | win_pct | pts_avg | reb_avg | ast_avg |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Los Angeles Lakers | 2025-26 | 2025-26 | 2 | 2 | 0 | 1 | 124 | 45 | 28 |

Section `by_season`

- Rows: `1`
- Columns: season, games, wins, losses, pts_avg, reb_avg, ast_avg, fg3m_avg, tov_avg, plus_minus_avg, efg_pct_avg, ts_pct_avg, ...

| season | games | wins | losses | win_pct | pts_avg | reb_avg | ast_avg | fg3m_avg | tov_avg |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2025-26 | 2 | 2 | 0 | 1 | 124 | 45 | 28 | 14 | 9 |

Section `game_log`

- Rows: `2`
- Columns: game_date, game_id, season, season_type, team_id, team_abbr, team_name, opponent_team_id, opponent_team_abbr, opponent_team_name, is_home, is_away, ...

| team_name | team_abbr | season | game_date | opponent_team_abbr | wl | pts | reb | ast | game_id |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Los Angeles Lakers | LAL | 2025-26 | 2026-03-06 | IND | W | 128 | 43 | 25 | 22500914 |
| Los Angeles Lakers | LAL | 2025-26 | 2026-03-10 | MIN | W | 120 | 47 | 31 | 22500946 |

### k08_original_mixed_qualified_empty

#### k08_original_mixed_qualified_empty

**Query**  
Lakers record among their last 10 games without LeBron James and with Luka Doncic in 2025-26

**Answer shown**  
No answer returned.

**Rendered output**

##### Message — No result

No answer rows returned; reason=no_match.  

- Query: `Lakers record among their last 10 games without LeBron James and with Luka Doncic in 2025-26`
- Category: `participation`
- Priority: `p1`
- Status: `no_result`
- Reason: `no_match`
- Route: `team_record`
- Intent: `summary`
- Query class: `summary`
- Shape hint: `no_result`
- Shape source: `backend_approximation`
- Answer text policy: `no_answer_text_expected`
- Answer text status: no answer text expected
- Backend answer text: _not backend-provided_
- Answer summary: No answer rows returned; reason=no_match
- Filters: `Without player=LeBron James (player)`, `With player=Luka Doncic (player)`, `Last N games=10 (window)`, `Sample selection=Select the last 10 original games before checking participation predicates (window)`
- Sections: _none_
- Expectations: `pass` (6 pass, 0 fail)
- Review notes: All original last 10 LAL games have known LeBron participation. None satisfiesLeBron DNP + Luka played. This is a qualified empty sample, not missing data and not the older latest 10 matching games.
- Manual review: `unreviewed`
- Notes: `['Original window selected 10 game(s) before testing participation predicates', 'No games matched the specified filters']`
