"""Held-out compact-calendar probes over synthetic explicit participation facts."""
from pathlib import Path
import shutil
import pandas as pd
import pytest
from nbatools.commands._constants import normalize_text
from nbatools.data_source import reset_data_source_cache
from nbatools.query_service import execute_natural_query

@pytest.fixture
def sample(tmp_path,monkeypatch):
    root=tmp_path/'independent-source';shutil.copytree(Path('qa/fixtures/query_engine_sample'),root)
    path=root/'data/raw/player_game_stats/2023-24_regular_season.csv';players=pd.read_csv(path)
    own=players.loc[players.player_id.eq(201939)].sort_values(['game_date','game_id'])
    home=own.loc[own.is_home.eq(True)].iloc[:2];away=own.loc[own.is_away.eq(True)].iloc[:2];dnp=pd.concat([home,away])
    explicit=dnp.assign(participation_state='did_not_play',coverage_scope='listed_player_rows_only',source='nba_official_finalbox:20231024_PHXGSW',source_sha256='b'*64)
    target=root/'data/raw/player_game_availability/2023-24_regular_season.csv';target.parent.mkdir(parents=True,exist_ok=True);explicit.to_csv(target,index=False)
    players.loc[~(players.player_id.eq(201939)&players.game_id.isin(dnp.game_id))].to_csv(path,index=False)
    monkeypatch.setenv('DATA_SOURCE','local');monkeypatch.setenv('NBATOOLS_DATA_ROOT',str(root));reset_data_source_cache()
    try:yield root,home,away
    finally:reset_data_source_cache()

@pytest.mark.parametrize('question',[
 'how many road games did Stephen Curry miss during2023-24?',
 'how many road games did Stephen Curry miss in2023-24',
 'games Stephen Curry missed in2023-24 on the road',
])
def test_unfamiliar_entity_season_preserves_away_absence_ids(sample,question):
    _,_,away=sample
    result=execute_natural_query(question);assert result.result_status=='ok',result.metadata
    sections=result.to_dict()['sections'];assert sections['count']==[{'count':2}]
    assert {int(r['game_id']) for r in sections['finder']}==set(away.game_id)
    assert result.metadata['without_player']=='Stephen Curry'

@pytest.mark.parametrize('question',[
 'Warriors record on the road without Stephen Curry in2023-24',
 'Golden State record away without Stephen Curry during2023-24',
])
def test_team_record_has_exact_dnp_sample_and_independent_arithmetic(sample,question):
    root,_,away=sample
    team=pd.read_csv(root/'data/raw/team_game_stats/2023-24_regular_season.csv')
    expected=team.loc[team.team_id.eq(1610612744)&team.game_id.isin(away.game_id)]
    assert len(expected)==2
    result=execute_natural_query(question);assert result.result_status=='ok',result.metadata
    row=result.to_dict()['sections']['summary'][0]
    assert row['games']==len(expected)
    assert row['wins']==expected.wl.eq('W').sum() and row['losses']==expected.wl.eq('L').sum()
    assert row['pts_avg']==pytest.approx(expected.pts.mean(),abs=.001)

def test_compact_date_and_absence_keep_exact_one_key(sample):
    _,_,away=sample;row=away.iloc[1];day=row.game_date[:10]
    result=execute_natural_query(f'how many road games did Stephen Curry miss on{day} in2023-24?')
    assert result.result_status=='ok',result.metadata
    sections=result.to_dict()['sections'];assert sections['count']==[{'count':1}]
    assert [int(r['game_id']) for r in sections['finder']]==[int(row.game_id)]

def test_compact_clause_does_not_convert_unknown_to_dnp(sample):
    root,_,_=sample;path=root/'data/raw/player_game_stats/2023-24_regular_season.csv';players=pd.read_csv(path)
    row=players.loc[players.player_id.eq(201939)].iloc[-1]
    players.loc[~(players.player_id.eq(201939)&players.game_id.eq(row.game_id))].to_csv(path,index=False)
    result=execute_natural_query('how many games did Stephen Curry miss in2023-24')
    assert result.result_status=='no_result'
    assert not result.to_dict().get('sections',{}).get('count')

@pytest.mark.parametrize('question',[
 'how many road games was Stephen Curry injured in2023-24',
 'Warriors record while Stephen Curry was healthy in2023-24',
])
def test_medical_predicate_does_not_become_played_or_dnp(sample,question):
    result=execute_natural_query(question)
    assert result.result_status=='no_result'
    assert not result.to_dict().get('sections',{}).get('count')

@pytest.mark.parametrize('text',[
 'within2024-25','Martin2024','Kevin2025','dominion2023','30points','top10','in20230','since2024players',
])
def test_calendar_boundary_does_not_modify_embedded_words_or_stat_tokens(text):
    assert normalize_text(text)==text.lower()

@pytest.mark.parametrize('text,expected',[
 ('in2023-24','in 2023-24'),('after2024-01-01','after 2024-01-01'),('between1999-00 and2000-01','between 1999-00 and2000-01'),('on2023-10-24?','on 2023-10-24'),
])
def test_calendar_glue_shared_normalization_is_idempotent(text,expected):
    assert normalize_text(text)==expected
    assert normalize_text(normalize_text(text))==expected
