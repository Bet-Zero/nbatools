exec(open('/workspace/chronology-audit.py').read().split("out=dict(")[0])
from collections import Counter
from fractions import Fraction
with zipfile.ZipFile(base/'current-refresh-20261104/current-sources.zip') as z:event=z.read('playbyplayv3-0022600116.json')
whole=(base/'readiness-reassessment/sources/boxscoretraditionalv3_0022600116.json').read_bytes()
with zipfile.ZipFile(base/'partial-capture-20261103/collection.zip') as z:trad=z.read('sources/boxscoretraditionalv3_0022600116_q1.json')
with zipfile.ZipFile(base/'recovery-capture-20261104/collection.zip') as z:adv=z.read('sources/boxscoreadvancedv3_0022600116_q1.json')
rows=[r for r in json.loads(event)['game']['actions'] if r['period']==1];tid=1610612746;opp=1610612760
independent=lineups(event,whole);assert not independent['errors'];trace={t['id']:t['lineups'] for t in independent['traces'][1]}
# Identify independently the exact ordered transfer events and terminal own actions.
transfers=[];ownends=[]
for r in rows:
 kind=r['actionType'];owner=r['teamId'];is_transfer=False
 if kind in ['Made Shot','Missed Shot','Turnover','Free Throw']:assert owner in [tid,opp]
 if owner==opp and kind in ['Made Shot','Turnover']:is_transfer=True
 if owner==opp and kind=='Free Throw' and not r['description'].startswith('MISS '):
  ft=re.fullmatch(r'Free Throw (\d) of (\d)',r['subType']);assert ft
  is_transfer=ft[1]==ft[2]
 if kind=='Rebound':
  owner=owner or r['personId'];assert owner in [tid,opp]
  is_transfer=owner==tid
 if is_transfer:transfers.append(r['actionId'])
 if owner==tid and kind in ['Made Shot','Missed Shot','Turnover']:ownends.append(r['actionId'])
assert rows[2]['actionId']==3 and rows[2]['actionType']=='Turnover' and rows[2]['teamId']==opp
# Pair intervals based solely on action order. Every transfer must precede a
# unique own ending action or be the lone unfinished final-period interval.
intervals=[];transfer_iter=iter(transfers);start=next(transfer_iter);next_start=None
for stop in ownends:
 assert start<stop
 next_start=next(transfer_iter,None)
 assert next_start is None or next_start>stop
 selected=[r for r in rows if start<=r['actionId']<=stop]
 players=set().union(*(set(trace[r['actionId']][tid]) for r in selected))
 intervals.append(dict(start_action=start,end_action=stop,players=sorted(players),incomplete=False))
 assert next_start is not None
 start=next_start
assert start==123 and rows[-1]['actionId']==124
intervals.append(dict(start_action=start,end_action=124,players=trace[124][tid],incomplete=True))
assert next(transfer_iter,None) is None
exposures=Counter(p for interval in intervals for p in interval['players'])
usage=[]
traditional=json.loads(trad)['boxScoreTraditional']['awayTeam'];reported=json.loads(adv)['boxScoreAdvanced']['awayTeam'];assert traditional['teamId']==tid
assert traditional['statistics']['freeThrowsAttempted']==traditional['statistics']['reboundsOffensive']==0
source={p['personId']:p for p in reported['players']}
for p in traditional['players']:
 pid=p['personId'];stats=p['statistics']
 if pid not in exposures:continue
 numerator=sum(r['personId']==pid and r['teamId']==tid and r['actionType'] in ['Made Shot','Missed Shot','Turnover'] for r in rows)
 assert numerator==stats['fieldGoalsAttempted']+stats['turnovers']
 rate=Fraction(numerator,exposures[pid]);literal=Fraction(str(source[pid]['statistics']['usagePercentage']))
 assert abs(rate-literal)<=Fraction(1,2000)
 usage.append(dict(player_id=pid,numerator=numerator,independent_exposure_count=exposures[pid],exact_rate=str(rate),reported_rate=str(literal)))
assert len(usage)==10
r=json.load(open('/workspace/chronology-independent.json'))
r['independent_usage_review']=dict(game_id='0022600116',period=1,team_id=tid,source_hashes={k:sha(v) for k,v in [('events',event),('whole',whole),('traditional',trad),('advanced',adv)]},independently_enumerated_intervals=intervals,cases=usage,sample_all_ten_match=True,full_independent_NBA_usage_accepted=False,scope='No ownFTA/OREB; source0116Q1only. Exposureunion during partial/unfinished possession, rather than onlyendingaction lineup. Possessionownership validation finding mustbe fixed beforecodeapproval.')
Path('/workspace/chronology-independent.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(usage,indent=2));print(len(intervals),'ownpossession intervals; sourcePOSS notused')
