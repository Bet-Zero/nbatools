import json,hashlib,zipfile,re,unicodedata
from pathlib import Path
from fractions import Fraction
from collections import defaultdict
base=Path('/workspace/nbatools/working/nba-tools-completion-program/source-evidence/rollover-2026-27')
def sha(b):return hashlib.sha256(b).hexdigest()
def sec(t):
 m=re.fullmatch(r'PT(\d+)M(\d+(?:\.\d+)?)S',t); assert m and 0<=Fraction(m[2])<60
 return int(m[1])*60+Fraction(m[2])
def norm(s):return re.sub('[^a-z0-9]','',unicodedata.normalize('NFKD',s).encode('ascii','ignore').decode().lower())
def files(g):
 if g=='0022600161':
  with zipfile.ZipFile(base/'incremental-return-20261104/clock-source-originals.zip') as z:raw=z.read(g+'.json')
  with zipfile.ZipFile(base/'current-refresh-20261104/current-sources.zip') as z:whole=z.read('boxscoretraditionalv3-'+g+'.json')
 else:
  with zipfile.ZipFile(base/'current-refresh-20261104/current-sources.zip') as z:raw=z.read('playbyplayv3-'+g+'.json')
  with zipfile.ZipFile(base/'recovery-capture-20261104/collection.zip') as z:whole=z.read('sources/boxscoretraditionalv3_'+g+'_full.json')
 return raw,whole

def scoring_audit(raw,whole):
 rows=json.loads(raw)['game']['actions'];box=json.loads(whole)['boxScoreTraditional'];tids=[box[s]['teamId'] for s in ['homeTeam','awayTeam']]
 score=dict.fromkeys(tids,0);groups=[];errors=[];mis=[];ends={};prev=None;oldclock=None
 for i,r in enumerate(rows):
  assert r['actionId']==i+1
  clock=sec(r['clock']);period=r['period'];assert 0<=clock<=(720 if period<=4 else 300)
  if prev is not None:assert period==prev and clock<=oldclock or period==prev+1
  key=(period,clock)
  if not groups or groups[-1]['key']!=key:groups.append(dict(key=key,rows=[]))
  groups[-1]['rows'].append(r);prev=period;oldclock=clock
 for g in groups:
  prefixes=[score.copy()];startscore=score.copy()
  for r in g['rows']:
   value=r['shotValue'] if r['actionType']=='Made Shot' else 1 if r['actionType']=='Free Throw' and not r['description'].startswith('MISS ') else 0
   if value:
    assert value in [1,2,3] and r['teamId'] in score and r['personId']>0
    score[r['teamId']]+=value
   prefixes.append(score.copy())
  for i,r in enumerate(g['rows']):
   observed={tid:int(r[f]) for tid,f in zip(tids,['scoreHome','scoreAway']) if r[f] not in ['',None]}
   legal=[j for j,p in enumerate(prefixes) if all(p[tid]==v for tid,v in observed.items())]
   if not legal:errors.append(dict(id=r['actionId'],kind=r['actionType'],observed=observed,prefixes=prefixes))
   if observed and not all(prefixes[i+1][tid]==v for tid,v in observed.items()):mis.append(dict(id=r['actionId'],kind=r['actionType'],period=r['period'],clock=r['clock'],observed=observed,strict_expected=prefixes[i+1],explained_same_clock_prefixes=legal,group_ids=[x['actionId'] for x in g['rows']]))
   if r['actionType']=='period' and r['subType']=='end':ends[r['period']]=score.copy()
 assert score=={box[s]['teamId']:box[s]['statistics']['points'] for s in ['homeTeam','awayTeam']}
 return dict(events=len(rows),groups=len(groups),same_clock_mismatches=mis,unexplained_score_observations=errors,final_scores=score,period_end_scores=ends)

def lineups(raw,whole):
 box=json.loads(whole)['boxScoreTraditional'];teams={box[s]['teamId']:box[s]['players'] for s in ['homeTeam','awayTeam']}
 aliases={}; starters={}
 for tid,players in teams.items():
  aliases[tid]=defaultdict(set);starters[tid]={p['personId'] for p in players if p.get('position','').strip()}
  assert len(starters[tid])==5
  for p in players:
   family=p['familyName'];basic=re.sub(r'\s+(?:Jr\.?|Sr\.?|II|III|IV)$','',family)
   for f in {family,basic}:
    aliases[tid][norm(f)].add(p['personId'])
    for n in range(1,len(p['firstName'])+1):aliases[tid][norm(p['firstName'][:n]+f)].add(p['personId'])
 rows=json.loads(raw)['game']['actions'];results={};errors={};traces={}
 for q in sorted({r['period'] for r in rows}):
  subset=[r for r in rows if r['period']==q];first={tid:{} for tid in teams};actors={tid:set() for tid in teams};subs={}
  try:
   for r in subset:
    tid=r['teamId'];pid=r['personId']
    if r['actionType']=='Substitution':
     m=re.fullmatch('SUB: (.+) FOR (.+)',r['description']);assert m and len(aliases[tid][norm(m[1])])==1
     incoming=next(iter(aliases[tid][norm(m[1])]))
     assert incoming!=pid
     first[tid].setdefault(pid,'out');first[tid].setdefault(incoming,'in');subs[r['actionId']]=(tid,pid,incoming)
    elif tid in teams and pid>0 and r['actionType'] in ['Made Shot','Missed Shot','Free Throw','Turnover','Rebound','Jump Ball','Foul']:
     actors[tid].add(pid)
   active={tid:starters[tid].copy() if q==1 else {p for p,r in first[tid].items() if r=='out'} | (actors[tid]-set(first[tid])) for tid in teams}
   assert all(len(a)==5 for a in active.values()), ('not unique starting lineups',active)
   seconds={tid:defaultdict(Fraction) for tid in teams};prev=Fraction(720 if q<=4 else 300)
   trace=[]
   for r in subset:
    clock=sec(r['clock']);elapsed=prev-clock;assert elapsed>=0
    for tid,a in active.items():
     assert len(a)==5
     for pid in a:seconds[tid][pid]+=elapsed
    if r['actionId'] in subs:
     tid,pid,incoming=subs[r['actionId']];assert pid in active[tid] and incoming not in active[tid], ('contradictory substitution',r['actionId'],r['description'],active[tid])
     active[tid].remove(pid);active[tid].add(incoming)
    elif r['teamId'] in teams and r['personId']>0 and r['actionType'] in ['Made Shot','Missed Shot','Free Throw','Turnover','Rebound','Jump Ball','Foul']:
     assert r['personId'] in active[r['teamId']],('actor absent',r['actionId'],r['description'])
    trace.append(dict(id=r['actionId'],clock=r['clock'],lineups={t:sorted(a) for t,a in active.items()}));prev=clock
   assert prev==0 and all(sum(ss.values())==5*(720 if q<=4 else 300) for ss in seconds.values())
   results[q]={tid:{pid:str(s) for pid,s in ss.items()} for tid,ss in seconds.items()};traces[q]=trace
  except (AssertionError,KeyError) as e:errors[q]=str(e)
 return dict(exact_clock_vectors=results,errors=errors,traces=traces)

out=dict(reviewer='/root/chronology_checker',scope='independent retained source arithmetic; no implementation edits',games={})
for gid in ['0022600161','0022600142','0022600144']:
 raw,whole=files(gid);out['games'][gid]=dict(source_event_sha256=sha(raw),source_whole_sha256=sha(whole),scoring=scoring_audit(raw,whole),lineups=lineups(raw,whole))
Path('/workspace/chronology-independent.json').write_text(json.dumps(out,indent=2)+'\n')
for gid,r in out['games'].items():print(gid, 'scoreexceptions',r['scoring']['same_clock_mismatches'],'scoreerrors',r['scoring']['unexplained_score_observations'],'clockerrors',r['lineups']['errors'])
