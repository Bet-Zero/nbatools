import json,zipfile,hashlib
from pathlib import Path
from fractions import Fraction
import pandas as pd
base=Path('/workspace/nbatools/working/nba-tools-completion-program/source-evidence/rollover-2026-27')
root=Path('/workspace/retained-periods-0161');report=json.load(open('/workspace/chronology-independent.json'));facts=report['games']['0022600161'];vectors=facts['lineups']['exact_clock_vectors']
original={}
with zipfile.ZipFile(base/'incremental-return-20261104/collection.zip') as z:
 for q in [2,3]:
  for ep in ['boxscoretraditionalv3','boxscoreadvancedv3']:
   original[q,ep]=json.loads(z.read(f'sources/{ep}_0022600161_q{q}.json'))
checked=0
for q in [2,3]:
 for ep,key in [('boxscoretraditionalv3','boxScoreTraditional'),('boxscoreadvancedv3','boxScoreAdvanced')]:
  copy=json.loads((root/f'clock-copies/0161-q{q}/{ep}.json').read_bytes());old=original[q,ep]
  assert copy[key]['gameId']=='0022600161'
  for side in ['homeTeam','awayTeam']:
   team=copy[key][side];tid=str(team['teamId']);source=old[key][side]
   assert team['statistics']==source['statistics']
   for p,s in zip(team['players'],source['players'],strict=True):
    mins,secs=p['statistics']['minutes'].split(':');exact=int(mins)*60+Fraction(secs);expected=Fraction(vectors[str(q)][tid].get(str(p['personId']),'0'))
    assert exact==expected,(q,ep,p['personId'],exact,expected)
    p['statistics']['minutes']=s['statistics']['minutes'];checked+=1
  assert copy==old
assert checked==78,checked
preserved={};appends={}
with zipfile.ZipFile(base/'incremental-return-20261104/qualification-evidence.zip') as z:
 for name in z.namelist():
  if name.startswith('stage/data/raw/') and name.endswith('.csv'):
   before=z.read(name);after=(root/name).read_bytes()
   if 'game_period_stats/' in name:
    assert after.startswith(before);appends[name]=len(after)-len(before)
   else:assert after==before;preserved[name]=hashlib.sha256(after).hexdigest()
period=pd.read_csv(root/'stage/data/raw/team_game_period_stats/2026-27_regular_season.csv')
assert len(period.drop_duplicates(['game_id','period_family','period_value']))==643
r=json.loads((root/'assessment.json').read_bytes());assert len(r['admissions'])==2 and not r['full_snapshot_accepted'];assert len(r['consumers'])==2
assert all(x['state']=='passed' for x in r['executed_stages'][1:])
required=[d for d in r['dataset_assessment']['datasets'] if d['required']];assert len(required)==16
assert sum(d['validation']['state']=='passed' for d in required)==14
for x in r['consumers']:
 selected=[row for row in x['rows'] if int(row['game_id'])==22600161];assert len(selected)==1
 print(x['quarter'],selected[0]['pts'],selected[0]['minutes'])
report['stage_audit']=dict(stage=str(root),clock_cells_independently_compared=checked,non_clock_json_restored=True,prior_raw_identical=preserved,period_append_bytes=appends,observed_windows=643,required_records_passed=14,required_records_failed=2,all_five_builders_passed=True,consumer_checks='twoquarterqueries returned correctgame scope; values subject to independent source comparison below',full_acceptance=False)
Path('/workspace/chronology-independent.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS',checked,'copied cells, all prior raw and prefixes,643windows14structuralpass2periodfail')
