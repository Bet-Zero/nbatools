audit_source = open('/workspace/chronology-audit.py').read().split("out=dict(")[0]
audit_source = audit_source.replace("r['actionType'] in ['Made Shot','Missed Shot','Free Throw','Turnover','Rebound','Jump Ball','Foul']", "(r['actionType'] in ['Made Shot','Missed Shot','Free Throw','Turnover','Rebound','Jump Ball'] or (r['actionType']=='Foul' and r.get('subType','').lower() in ['away from play','loose ball','offensive','offensive charge','personal','shooting']))")
audit_source = audit_source.replace("family=p['familyName'];basic=", "display=re.fullmatch(r'[A-Z]\\.\\s+(.+)',p.get('nameI',''));\n   if display:aliases[tid][norm(display[1])].add(p['personId'])\n   family=p['familyName'];basic=")
exec(audit_source)
from tools.period_event_evidence import period_facts,clock_facts,same_clock_score_evidence
from tools.qualify_advanced_basis import qualify
from tools.stage_current_season import _whole_original
metadata=json.load(open('/workspace/precision-sources/sources.json'))
older=json.load(open('/workspace/advanced-basis-exact-clock/qualification.json'))
source_scope={str(r['player_id']):r for r in older['minute_basis'] if r['independent_timing_state']=='real_clock_boundary_unknown'}
assert len(source_scope)==6
needed={g for r in source_scope.values() for g in r['game_ids']};assert len(needed)==16
assert needed==set(metadata['required_game_ids'])|{'0022600168'}

def whole_raw(gid):
 if gid<='0022600146':return _whole_original(gid)
 if gid in ['0022600147','0022600149']:
  with zipfile.ZipFile(base/'period-milestone/archive-refresh.zip') as z:return z.read(f'boxscoretraditionalv3_{gid}.json')
 with zipfile.ZipFile(base/'current-refresh-20261104/current-sources.zip') as z:return z.read(f'boxscoretraditionalv3-{gid}.json')

universe={}
for gid in sorted(needed):
 if gid=='0022600160':
  universe[gid]=dict(state='genuine_archive_body_absent');continue
 if gid=='0022600168':
  with zipfile.ZipFile(base/'incremental-return-20261104/clock-source-originals.zip') as z:e=z.read(gid+'.json')
 else:e=(Path('/workspace/precision-sources')/(gid+'.json')).read_bytes()
 w=whole_raw(gid);box=json.loads(w)['boxScoreTraditional'];sc=scoring_audit(e,w);ind=lineups(e,w)
 score_exceptions=sc['same_clock_mismatches']
 metadata_explained=all(x['kind']=='Instant Replay' and len(x['explained_same_clock_prefixes'])==1 for x in score_exceptions)
 state='qualified_exact_clock' if metadata_explained and not sc['unexplained_score_observations'] and not ind['errors'] else 'source_or_clock_qualification_failed' 
 rooterror=None
 try:
  final={box[s]['teamId']:box[s]['statistics']['points'] for s in ['homeTeam','awayTeam']}
  proof=same_clock_score_evidence(e,game_id=gid,final_teams=final) if score_exceptions else None
  facts=period_facts(e,game_id=gid,final_teams=final,score_snapshots=proof)
  runtime=clock_facts(e,w,period_report=facts)
 except ValueError as ex:rooterror=str(ex)
 else:
  assert state=='qualified_exact_clock',(gid,sc['same_clock_mismatches'],ind['errors'])
  assert {str(q):{str(t):{str(p):str(v) for p,v in ps.items()} for t,ps in ts.items()} for q,ts in runtime.items()}=={str(q):{str(t):{str(p):str(v) for p,v in ps.items()} for t,ps in ts.items()} for q,ts in ind['exact_clock_vectors'].items()}
 universe[gid]=dict(state=state,root_guard_failure=rooterror,source_event_sha256=sha(e),source_whole_sha256=sha(w),scoring_audit=sc,independent_lineups=ind)

players={}
for pid,record in source_scope.items():
 failed=[gid for gid in record['game_ids'] if universe[gid]['state']!='qualified_exact_clock'];values=[]
 if failed:
  players[pid]=dict(state='unknown',games=record['game_ids'],unqualified_games=failed)
  continue
 for gid in record['game_ids']:
  result=universe[gid]['independent_lineups']['exact_clock_vectors']
  seconds=sum((Fraction(ps.get(int(pid),'0')) for teams in result.values() for ps in teams.values()),Fraction(0))
  assert seconds>0
  values.append(dict(game_id=gid,exact_seconds=str(seconds)))
 mean=sum((Fraction(x['exact_seconds']) for x in values),Fraction(0))/60/len(values);actual=Fraction(record['reported_minutes']);residual=abs(mean-actual)
 players[pid]=dict(state='qualified_exact_mean_matches_inclusive_tolerance' if residual<=Fraction(1,20) else 'qualified_exact_mean_source_disagrees',games=values,exact_mean_minutes=str(mean),reported_mean_minutes=str(actual),exact_residual=str(residual))
report=dict(reviewer='/root/chronology_checker',scope='independent delta source/oracle audit, no producer edits',new_event_bodies=14,reused_event_bodies=1,missing_event_body='0022600160',needed_games=sorted(needed),source_manifest_sha256=sha(Path('/workspace/precision-sources/sources.json').read_bytes()),game_qualification=universe,player_exact_means=players,full_snapshot_accepted=False)
Path('/workspace/precision-independent.json').write_text(json.dumps(report,indent=2)+'\n')
for gid,g in universe.items():print(gid,g['state'],g.get('root_guard_failure'))
print(json.dumps(players,indent=2))
