import json,zipfile,hashlib
from pathlib import Path
from fractions import Fraction
from collections import defaultdict
from decimal import Decimal
base=Path('/workspace/nbatools/working/nba-tools-completion-program/source-evidence/rollover-2026-27')
def table(raw,name):
 d=json.loads(raw,parse_float=Decimal);s=next(s for s in d['resultSets'] if s['name']==name)
 return [dict(zip(s['headers'],r,strict=True)) for r in s['rowSet']]
def ratio(pts,fga,fta):
 denom=2*(Fraction(fga)+Fraction(11,25)*fta)
 assert denom or pts==0
 return Fraction(pts)/denom if denom else Fraction(0)
with zipfile.ZipFile(base/'current-refresh-20261104/current-sources.zip') as z:logsraw=z.read('playergamelogs-regular-season_base_totals.json')
with zipfile.ZipFile(base/'incremental-return-20261104/collection.zip') as z:praw=z.read('sources/leaguedashplayerstats_advanced_through_20261102.json');traw=z.read('sources/leaguedashteamstats_advanced_through_20261102.json')
logs=table(logsraw,'PlayerGameLogs');players=table(praw,'LeagueDashPlayerStats');teams=table(traw,'LeagueDashTeamStats')
assert len({r['GAME_ID'] for r in logs})==107
checks={}
for grain,rows,identity in [('player',players,'PLAYER_ID'),('team',teams,'TEAM_ID')]:
 totals=defaultdict(lambda:[0,0,0]);games=defaultdict(set)
 for r in logs:
  for i,f in enumerate(['PTS','FGA','FTA']):totals[r[identity]][i]+=r[f]
  games[r[identity]].add(r['GAME_ID'])
 assert set(totals)=={r[identity] for r in rows}
 vals=[]
 for r in rows:
  ident=r[identity];expected=ratio(*totals[ident]);actual=Fraction(r['TS_PCT']);assert abs(expected-actual)<=Fraction(1,2000)
  assert len(games[ident])==r['GP']
  vals.append(dict(identity=ident,original_counts=totals[ident],exact_ratio=str(expected),reported=str(actual),GP=len(games[ident])))
 checks[grain]=vals
mins=defaultdict(list)
for r in logs:mins[r['PLAYER_ID']].append(Fraction(str(r['MIN'])))
minutechecks=[]
for r in players:
 exact=sum(mins[r['PLAYER_ID']],Fraction(0))/len(mins[r['PLAYER_ID']]);actual=Fraction(r['MIN']);residual=abs(exact-actual)
 assert residual<=Fraction(1,20)+Fraction(1,10**12)
 minutechecks.append(dict(player_id=r['PLAYER_ID'],serialized_mean=str(exact),reported=str(actual),exact_residual=str(residual),near_tie=abs(residual-Fraction(1,20))<Fraction(1,10**12)))
report=json.load(open('/workspace/chronology-independent.json'))
report['independent_advanced_source_basis']=dict(raw_basis_TS_all448players_and30teams_match=True,scope_games=107,checks=checks,minutes=minutechecks,raw_serialized_ties_or_near_ties=sum(r['near_tie'] for r in minutechecks),real_clock_ties_resolved=False,canonical_corrected_counts_not_replaced=True,source_hashes={k:hashlib.sha256(v).hexdigest() for k,v in [('logs',logsraw),('playerAdvanced',praw),('teamAdvanced',traw)]})
Path('/workspace/chronology-independent.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS:448player+30teamGP/TS sourcebasis with independent stdlib oracle; near-boundary count',sum(r['near_tie'] for r in minutechecks))
for r in checks['player']:
 if r['identity'] in [203924,1630230,1630552]:print(r)
