import json
from collections import Counter
from pathlib import Path
import pandas as pd
from tools.stage_current_season import SUFFIX,CURRENT
root=Path('work/technical-ft-stage-v2/stage/data/raw')
orig=json.loads((CURRENT/'period-basis-deltas.json').read_bytes())
core=pd.read_csv(root/'player_game_stats'/SUFFIX).set_index(['game_id','team_id','player_id'])
period=pd.read_csv(root/'player_game_period_stats'/SUFFIX)
qu=period[period.period_family.isin(['quarter','overtime'])]
cols=['fgm','fga','fg3m','fg3a','ftm','fta','oreb','dreb','reb','ast','stl','blk','tov','pf','pts','plus_minus']
windows=qu.groupby('game_id').apply(lambda d:set(zip(d.period_family,d.period_value.astype(str))),include_groups=False)
required={gid:4+int(any(family=='overtime' for family,value in s)) for gid,s in windows.items()}
complete={gid for gid,s in windows.items() if len(s)==required[gid]}
summed=qu[qu.game_id.isin(complete)].groupby(['game_id','team_id','player_id'])[cols].sum()
conf=[]
for key,row in summed.iterrows():
 if key not in core.index:
  assert row.eq(0).all();continue
 for col in cols:
  if row[col]!=core.loc[key,col]:conf.append(dict(game_id=str(key[0]).zfill(10),team_id=int(key[1]),player_id=int(key[2]),field=col,period_sum=float(row[col]),canonical=float(core.loc[key,col])))
report=dict(classification='current_admitted_period_count_contradictions_not_repair',original_ledger='current-refresh-20261104/period-basis-deltas.json',original_ledger_conflicts=orig['integer_cell_conflicts'],original_ledger_games=len(orig['conflict_game_ids']),current_complete_game_count=len(complete),uncompared_incomplete_game_ids=['0022600142'],current_conflict_count=len(conf),current_conflict_game_ids=sorted({r['game_id']for r in conf}),by_field=dict(Counter(r['field']for r in conf)),conflicts=conf,accepted_cells_rewritten=False,full_numerical_acceptance=False)
Path('work/current-count-coherence.json').write_text(json.dumps(report,indent=2)+'\n')
print({k:v for k,v in report.items() if k!='conflicts'})
print('144old',[r for r in orig['conflicts']if r['game_id']=='0022600144'])
