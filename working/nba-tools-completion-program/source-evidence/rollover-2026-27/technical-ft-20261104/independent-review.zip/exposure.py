exec(open('work/credit-checker/oracle.py').read().replace("if __name__=='__main__':", "if False:"))
import contextlib,io
with contextlib.redirect_stdout(io.StringIO()):teams,rows,traces,clocks=run('0022600144')
allout={}
for q in [1,2]:
 acts=[r for r in rows if r['period']==q];owners=set(teams);plays=[];possessions=[];play=None;poss=None
 def clock(r):
  m,s=re.fullmatch(r'PT(\d+)M(\d+(?:\.\d+)?)S',r['clock']).groups();return Fraction(m)*60+Fraction(s)
 def begin(owner,aid):return {'team':owner,'first':aid,'seconds':Counter(),'credits':set()}
 def end(unit,aid,out):
  unit['last']=aid;unit['players']=sorted({pid for pid,t in unit['seconds'].items()if t>0}|unit['credits']);out.append(unit)
 first=next(r for r in acts if r['actionType']in['Made Shot','Missed Shot','Turnover','Free Throw']);play=begin(first['teamId'],acts[0]['actionId']);poss=begin(first['teamId'],acts[0]['actionId']);previous=clock(acts[0]);lastline=traces[acts[0]['actionId']]
 ft_andone={r['actionId']:next((f['actionId']for f in acts if f['clock']==r['clock']and f['teamId']==r['teamId']and f['personId']==r['personId']and f['subType']=='Free Throw 1 of 1'),None)for r in acts if r['actionType']=='Made Shot'}
 lastft=None;pointfor=Counter();pointagainst=Counter()
 for r in acts:
  aid,kind,owner=r['actionId'],r['actionType'],r['teamId'];now=clock(r)
  if kind=='Substitution':continue
  # State after substitutions is used on next positive clock segment.
  for unit in [play,poss]:
   if unit:
    for pid in traces[aid][unit['team']]:unit['seconds'][pid]+=previous-now
  previous=now
  if kind in ['Made Shot','Free Throw']and not r['description'].startswith('MISS '):
   val=r['shotValue']if kind=='Made Shot'else 1
   credit=traces[aid]
   if kind=='Free Throw':
    anchors=[a for a in acts if a['clock']==r['clock']and a['actionId']<aid and a['actionType']=='Foul']
    assert anchors
    credit=traces[anchors[-1]['actionId']]
   for tid in teams:
    for pid in credit[tid]:(pointfor if tid==owner else pointagainst)[tid,pid]+=val
   for unit in [play,poss]:
    if unit and unit['team']==owner:unit['credits'].update(credit[owner])
  if kind=='Free Throw'and r['subType']=='Free Throw Technical':continue
  if kind in ['Made Shot','Missed Shot','Turnover','Free Throw']:assert play and play['team']==owner,(q,aid,kind,play)
  if kind=='Made Shot'and ft_andone[aid]:continue
  terminal=kind in ['Made Shot','Missed Shot','Turnover','Heave']or kind=='Free Throw'and(lambda m:m and m[1]==m[2])(re.fullmatch('Free Throw ([123]) of ([123])',r['subType']))
  if terminal:
   assert play and poss
   own=play['team'];end(play,aid,plays);play=None
   if kind in ['Made Shot','Turnover']or kind=='Free Throw'and not r['description'].startswith('MISS '):
    end(poss,aid,possessions);poss=None;op=next(t for t in owners if t!=own);play=begin(op,aid);poss=begin(op,aid)
  elif kind=='Rebound':
   before=next(v for v in reversed(acts[:acts.index(r)])if v['actionType']in ['Missed Shot','Free Throw','Heave'])
   if before['actionType']=='Free Throw':
    m=re.fullmatch('Free Throw ([123]) of ([123])',before['subType'])
    if m and m[1]!=m[2]:continue
   assert play is None
   rebounder=owner if owner else r['personId'];play=begin(rebounder,aid)
   if poss['team']!=rebounder:end(poss,aid,possessions);poss=begin(rebounder,aid)
  elif kind=='period'and r['subType']=='end':
   if play:end(play,aid,plays)
   if poss:end(poss,aid,possessions)
 allout[q]={'plays':plays,'possessions':possessions,'pointfor':pointfor,'pointagainst':pointagainst}
 print('Q',q,'plays',Counter(x['team']for x in plays),'POSS',Counter(x['team']for x in possessions))
for window,qs in [('q1',[1]),('q2',[2]),('h1',[1,2])]:
 orig=load('boxscoretraditionalv3','0022600144',window);adv=load('boxscoreadvancedv3','0022600144',window)
 for side in ['homeTeam','awayTeam']:
  tid=orig[side]['teamId'];playden=Counter(pid for q in qs for p in allout[q]['plays']if p['team']==tid for pid in p['players']);possden=Counter(pid for q in qs for p in allout[q]['possessions']if p['team']==tid for pid in p['players']);oppden=Counter()
  # Defensive exposure requires per-team time in opponent possession, separate from current offensive-player set. Reconstruct from interval first/last bounds.
  for q in qs:
   for unit in allout[q]['possessions']:
    if unit['team']==tid:continue
    start,end=unit['first'],unit['last'];exposed=set();previous=next(clock(r)for r in rows if r['actionId']==start)
    for r in rows:
     if not start<=r['actionId']<=end or r['actionType']=='Substitution':continue
     current=clock(r)
     if previous>current:exposed.update(traces[r['actionId']][tid])
     previous=current
    oppden.update(exposed)
  for p in orig[side]['players']:
   pid=p['personId'];a=next(a for a in adv[side]['players']if a['personId']==pid)['statistics'];acts=[r for r in rows if r['period']in qs];n=sum(r['personId']==pid and r['teamId']==tid and r['actionType']in ['Made Shot','Missed Shot','Turnover']for r in acts)+sum(r['personId']==pid and r['teamId']==tid and r['subType']in ['Free Throw 1 of 2','Free Throw 1 of 3']for r in acts);pt=sum(allout[q]['pointfor'][tid,pid]for q in qs);pa=sum(allout[q]['pointagainst'][tid,pid]for q in qs)
   if not playden[pid]:continue
   usg=Fraction(n,playden[pid]);ortg=Fraction(pt*100,possden[pid]);pm=pt-pa
   print(window,pid,p['familyName'],'usage',n,playden[pid],str(usg),a['usagePercentage'],abs(usg-Fraction(str(a['usagePercentage'])))<=Fraction(1,2000),'ortg',pt,possden[pid],round(float(ortg),1),a['offensiveRating'], 'pm',pm,p['statistics']['plusMinusPoints'],'defpts',pa,'defexp',oppden[pid])
records=[]
for window,qs in [('q1',[1]),('q2',[2]),('h1',[1,2])]:
 orig=load('boxscoretraditionalv3','0022600144',window);adv=load('boxscoreadvancedv3','0022600144',window)
 acts=[r for r in rows if r['period']in qs];counts=defaultdict(Counter);tfgm=Counter();rebden=Counter()
 for r in acts:
  tid,pid,aid=r['teamId'],r['personId'],r['actionId'];kind=r['actionType']
  if kind in ['Made Shot','Missed Shot']:counts[tid,pid]['fga']+=1
  if kind=='Made Shot':
   counts[tid,pid]['fgm']+=1
   for on in traces[aid][tid]:tfgm[tid,on]+=1
   m=re.search(r'\(([^()]+) [0-9]+ AST\)$',r['description'])
   if m:
    lookup=[p['personId']for p in teams[tid]['players']if norm(re.sub(r'\s+(?:Jr\.?|Sr\.?|II|III|IV)$','',p['familyName']))==norm(re.sub(r'\s+(?:Jr\.?|Sr\.?|II|III|IV)$','',m[1]))or norm(p['familyName'])==norm(m[1])];assert len(lookup)==1,(aid,m[1],lookup);counts[tid,lookup[0]]['ast']+=1
  if kind=='Turnover':counts[tid,pid]['tov']+=1
  if kind=='Free Throw'and r['subType']in ['Free Throw 1 of 2','Free Throw 1 of 3']:counts[tid,pid]['trip']+=1
  if kind=='Rebound':
   preceding=next(a for a in reversed(rows[:rows.index(r)])if a['actionType']in ['Missed Shot','Free Throw','Heave'])
   if preceding['actionType']=='Free Throw':
    m=re.fullmatch('Free Throw ([123]) of ([123])',preceding['subType'])
    if m and m[1]!=m[2]:continue
   for t in teams:
    for on in traces[aid][t]:rebden[t,on]+=1
   if tid in teams and pid in {p['personId']for p in teams[tid]['players']}:counts[tid,pid]['reb']+=1
 for side in ['homeTeam','awayTeam']:
  tid=orig[side]['teamId'];playden=Counter(pid for q in qs for p in allout[q]['plays']if p['team']==tid for pid in p['players']);possden=Counter(pid for q in qs for p in allout[q]['possessions']if p['team']==tid for pid in p['players'])
  for p in orig[side]['players']:
   pid=p['personId'];c=counts[tid,pid];a=next(a for a in adv[side]['players']if a['personId']==pid)['statistics'];s=p['statistics'];n=c['fga']+c['trip']+c['tov'];pt=sum(allout[q]['pointfor'][tid,pid]for q in qs);pa=sum(allout[q]['pointagainst'][tid,pid]for q in qs)
   if not playden[pid]:continue
   af=tfgm[tid,pid]-c['fgm'];tr=c['fga']+c['trip']+c['ast']+c['tov'];ar=Fraction(c['ast'],af)if af else Fraction(0);rr=Fraction(c['reb'],rebden[tid,pid])if rebden[tid,pid]else Fraction(0);tor=Fraction(100*c['tov'],tr)if tr else Fraction(0)
   record={'window':window,'team_id':tid,'player_id':pid,'points_for':pt,'points_against':pa,'plus_minus':pt-pa,'reported_plus_minus':s['plusMinusPoints'],'play_numerator':n,'play_exposure':playden[pid],'usage_ratio':str(Fraction(n,playden[pid])),'reported_usage':a['usagePercentage'],'possessions_exposed':possden[pid],'offensive_rating':str(Fraction(100*pt,possden[pid])),'reported_offensive_rating':a['offensiveRating'],'assist_count':c['ast'],'teammate_fgm_exposure':af,'assist_ratio':str(ar),'reported_assist_percentage':a['assistPercentage'],'player_rebounds':c['reb'],'live_rebound_opportunities':rebden[tid,pid],'rebound_ratio':str(rr),'reported_rebound_percentage':a['reboundPercentage'],'turnovers':c['tov'],'tov_ratio_basis':tr,'turnover_ratio':str(tor),'reported_turnover_ratio':a['turnoverRatio']}
   for expected,reported,limit in [('plus_minus','reported_plus_minus',0),('usage_ratio','reported_usage',Fraction(1,2000)),('offensive_rating','reported_offensive_rating',Fraction(1,20)),('assist_ratio','reported_assist_percentage',Fraction(1,2000)),('rebound_ratio','reported_rebound_percentage',Fraction(1,2000)),('turnover_ratio','reported_turnover_ratio',Fraction(1,20))]:
    record[expected+'_matches']=abs(Fraction(str(record[expected]))-Fraction(str(record[reported])))<=limit
   records.append(record)
Path('work/credit-checker/independent-rate-oracles.json').write_text(json.dumps({'classification':'independent_event_oracles_not_general_semantics_or_production_acceptance','source_archives':{'recovery-capture-20261104/collection.zip':hashlib.sha256((BASE/'recovery-capture-20261104/collection.zip').read_bytes()).hexdigest(),'current-refresh-20261104/current-sources.zip':hashlib.sha256((BASE/'current-refresh-20261104/current-sources.zip').read_bytes()).hexdigest()},'records':records,'reported_possessions_read':False},indent=2)+'\n')
print('SUMMARY',len(records),Counter(r['window']for r in records),{k:sum(r[k]for r in records)for k in records[0]if k.endswith('_matches')})
