import json,hashlib
from pathlib import Path
from collections import Counter
import pandas as pd
from tools.stage_current_season import CURRENT,SUFFIX
root=Path('work/technical-ft-stage-v2/stage/data/raw');games=pd.read_csv(root/'games'/SUFFIX);core=pd.read_csv(root/'player_game_stats'/SUFFIX);period=pd.read_csv(root/'player_game_period_stats'/SUFFIX)
fields=['pts','fgm','fga','fg3m','fg3a','ftm','fta','oreb','dreb','reb','ast','stl','blk','tov','pf','plus_minus'];quarter=period.loc[period.period_family.isin(['quarter','overtime'])];complete=[];missing=[];catalog_raw=(CURRENT/'summary-catalog.json').read_bytes();assert hashlib.sha256(catalog_raw).hexdigest()=='e03bc219cf7545e6926d004e0d6806726da0066a6e41f08a97dfbc182c462812';counts={k:v['periods']for k,v in json.loads(catalog_raw).items()};counts['0022600161']=4
for g in games.itertuples():
 observed=set(zip(quarter.loc[quarter.game_id.eq(g.game_id),'period_family'],quarter.loc[quarter.game_id.eq(g.game_id),'period_value'].astype(str)))
 expected={('quarter',str(q))for q in range(1,5)}|({('overtime','ot')}if counts[str(g.game_id).zfill(10)]>4 else set())
 if observed==expected:complete.append(g.game_id)
 else:missing.append({'game_id':str(g.game_id).zfill(10),'missing_windows':sorted(expected-observed),'unexpected_windows':sorted(observed-expected)})
s=quarter.loc[quarter.game_id.isin(complete)].groupby(['game_id','team_id','player_id'])[fields].sum();c=core.loc[core.game_id.isin(complete)].set_index(['game_id','team_id','player_id'])[fields]
assert (s.index==c.index).all()if s.index.equals(c.index)else set(s.index)==set(c.index)
c=c.reindex(s.index);delta=s-c;conf=[]
for key,row in delta.iterrows():
 for f,v in row.items():
  if v:conf.append((str(key[0]).zfill(10),int(key[1]),int(key[2]),f,float(s.loc[key,f]),float(c.loc[key,f])))
original=json.loads((CURRENT/'period-basis-deltas.json').read_text());norm=lambda r:(r['game_id'],r['team_id'],r['player_id'],r['field'].lower(),float(r['period_sum']),float(r['staged_core']))
o=[norm(r)for r in original['conflicts']];remain=[r for r in o if r[0]!='0022600144'];observed=set(conf);assert observed=={r for r in remain if r[0]!='0022600142'};assert len(remain)==83;assert len(conf)==80;assert len(complete)==106
report={'classification':'independent_count_diagnostic_population_review_not_repair','reviewed_implementation_sha':'f123299a05fcf8e0287c6e698ae8aaf68131a5b6','complete_games_from_qualified_summary_period_requirements':len(complete),'incomplete_games':missing,'original_conflict_count':86,'original_conflict_games':19,'resolved_original_conflicts':[list(r)for r in o if r[0]=='0022600144'],'current_compared_conflicts':len(conf),'current_compared_conflict_games':len({r[0]for r in conf}),'unadmitted_original_conflicts':[list(r)for r in remain if r[0]=='0022600142'],'remaining_known_original_obligations':len(remain),'current_compared_conflicts_exactly_equal_original_non142_non144_population':True,'accepted_cells_rewritten':False,'full_numerical_acceptance':False}
Path('work/credit-checker/count-coherence-review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
