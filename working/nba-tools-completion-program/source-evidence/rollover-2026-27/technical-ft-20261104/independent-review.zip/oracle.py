import json, zipfile, re, hashlib, unicodedata
from pathlib import Path
from fractions import Fraction
from collections import defaultdict,Counter
BASE=Path('working/nba-tools-completion-program/source-evidence/rollover-2026-27')
Z=zipfile.ZipFile(BASE/'recovery-capture-20261104/collection.zip')
def load(ep,gid,w):return json.loads(Z.read(f'sources/{ep}_{gid}_{w}.json'))['boxScoreTraditional'if ep=='boxscoretraditionalv3'else 'boxScoreAdvanced']
def norm(v):return re.sub('[^a-z0-9]','',unicodedata.normalize('NFKD',v).encode('ascii','ignore').decode().lower())
def read(gid):
 with zipfile.ZipFile(BASE/'current-refresh-20261104/current-sources.zip')as z:return z.read('playbyplayv3-'+gid+'.json')
def run(gid):
 box=load('boxscoretraditionalv3',gid,'full');raw=read(gid);rows=json.loads(raw)['game']['actions']
 teams={box[s]['teamId']:box[s]for s in ['homeTeam','awayTeam']};idx={}
 for tid,t in teams.items():
  aliases=defaultdict(set)
  for p in t['players']:
   fam=re.sub(r'\s+(?:Jr\.?|Sr\.?|II|III|IV)$','',p['familyName'])
   for name in [p['familyName'],fam,p.get('nameI','').split('. ',1)[-1]]:
    for size in range(0,len(p['firstName'])+1):aliases[norm(p['firstName'][:size]+' '+name)].add(p['personId'])
  idx[tid]=aliases
 traces={};clock={};errors=[]
 for q in sorted({r['period']for r in rows}):
  subset=[r for r in rows if r['period']==q];subs={};first=defaultdict(dict);actors=defaultdict(set)
  for r in subset:
   tid,pid,typ=r['teamId'],r['personId'],r['actionType']
   if typ=='Substitution':
    name=r['description'][5:].split(' FOR ')[0];cand=idx[tid][norm(name)];assert len(cand)==1
    pin=next(iter(cand));subs[r['actionId']]=(tid,pid,pin);first[tid].setdefault(pid,'out');first[tid].setdefault(pin,'in')
   elif tid in teams and pid>0 and(typ in ['Made Shot','Missed Shot','Free Throw','Rebound','Turnover']or typ=='Foul'and r['subType']in['Personal','Shooting','Loose Ball','Offensive']):actors[tid].add(pid)
  active={tid:({p['personId']for p in t['players']if p['position']}if q==1 else{pid for pid,x in first[tid].items()if x=='out'}| (actors[tid]-set(first[tid])))for tid,t in teams.items()}
  if not all(len(v)==5 for v in active.values()):errors.append(('initial',q,{k:sorted(v)for k,v in active.items()}));continue
  sec=defaultdict(Fraction);previous=Fraction(720 if q<=4 else 300)
  for r in subset:
   aid=r['actionId'];m,s=re.fullmatch(r'PT(\d+)M(\d+(?:\.\d+)?)S',r['clock']).groups();now=Fraction(m)*60+Fraction(s)
   for tid,ps in active.items():
    for pid in ps:sec[tid,pid]+=previous-now
   if aid in subs:
    tid,out,pin=subs[aid]
    if out not in active[tid]or pin in active[tid]:errors.append(('sub',q,aid,sorted(active[tid]),out,pin));break
    active[tid].remove(out);active[tid].add(pin)
   traces[aid]={tid:sorted(v)for tid,v in active.items()};previous=now
  else:clock[q]={f'{t}:{p}':str(v)for(t,p),v in sec.items()}
 result={'sha256':hashlib.sha256(raw).hexdigest(),'errors':errors,'clocks':clock}
 if gid.endswith('0144'):
  pm=Counter();pm_pre=Counter();scores=Counter();window=[r for r in rows if r['period']==2]
  for r in window:
   made=r['actionType']=='Made Shot';ft=r['actionType']=='Free Throw'and not r['description'].startswith('MISS ')
   if not(made or ft):continue
   v=r['shotValue']if made else 1;scores[r['teamId']]+=v
   for tid in teams:
    for pid in traces[r['actionId']][tid]:pm[tid,pid]+=v if tid==r['teamId']else-v
    for pid in traces[162 if r['actionId']==168 else r['actionId']][tid]:pm_pre[tid,pid]+=v if tid==r['teamId']else-v
  print('144CLOCKS',clock[2]);print('144SCORE',dict(scores));print('TECH POST',traces[168],'PRE',traces[162]);print('PM')
  t=load('boxscoretraditionalv3',gid,'q2')
  for side in ['homeTeam','awayTeam']:
   tid=t[side]['teamId']
   for p in t[side]['players']:print(tid,p['personId'],p['familyName'],'reported',p['statistics']['plusMinusPoints'],'literal',pm[tid,p['personId']],'pretech',pm_pre[tid,p['personId']])
 Path('work/credit-checker/'+gid+'.json').write_text(json.dumps(result,indent=2))
 print(gid,'errors',errors)
 return teams,rows,traces,clock
if __name__=='__main__':
 run('0022600144');run('0022600142')
