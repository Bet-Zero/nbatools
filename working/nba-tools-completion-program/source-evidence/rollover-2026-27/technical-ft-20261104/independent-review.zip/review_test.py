import json,copy,hashlib
from pathlib import Path
from fractions import Fraction
import pandas as pd
import pytest
from tools.qualify_technical_ft import event_basis,qualify_pair,retained_inputs,stage
from tools.readiness_refresh import SourceCache
ROOT=Path(__file__).parent
CACHE=Path('work/credit-cache')
@pytest.fixture(scope='module')
def retained():return retained_inputs(SourceCache(CACHE))
@pytest.fixture(scope='module')
def qualified(retained):
 raw,summary,whole,read=retained
 return {(a,b):qualify_pair(raw,whole,read('boxscoretraditionalv3',a,b,1),read('boxscoreadvancedv3',a,b,1),start=a,end=b)for a,b in [(1,1),(2,2),(1,2)]}
def test_independent_all_fifty_five_source_rate_oracles(qualified):
 independent=json.loads((ROOT/'independent-rate-oracles.json').read_text())['records']; seen=0
 for window,key in [('q1',(1,1)),('q2',(2,2)),('h1',(1,2))]:
  actual={p['player_id']:p for p in qualified[key][1]['cases']}
  expected=[p for p in independent if p['window']==window]
  assert set(actual)=={p['player_id']for p in expected}
  for e in expected:
   p=actual[e['player_id']];assert p['credited_points_for']==e['points_for'];assert p['credited_points_against']==e['points_against'];assert p['independent_possessions']==e['possessions_exposed'];assert Fraction(p['independent_offensive_rating'])==Fraction(e['offensive_rating'])
   for source,col in [('usagePercentage','usage_ratio'),('assistPercentage','assist_ratio'),('reboundPercentage','rebound_ratio'),('turnoverRatio','turnover_ratio')]:assert Fraction(p['rates'][source]['exact'])==Fraction(e[col])
   seen+=1
 assert seen==55

def test_independent_q2_and_h1_exact_full_clock_vectors(qualified):
 from tools.season_rollover_core_bridge import _literal_clock_seconds
 clock=json.loads((ROOT/'0022600144.json').read_text())['clocks']
 for key in [(2,2),(1,2)]:
  for row in qualified[key][1]['clock_ledger']:
   expected=sum(Fraction(clock[str(q)].get(str(row['team_id'])+':'+str(row['player_id']),'0'))for q in range(key[0],key[1]+1))
   assert Fraction(row['exact_seconds'])==expected

def test_independent_0142_two_actor_consistent_timing_witnesses():
 ledger=json.loads((ROOT/'0142-obligation-ledger.json').read_text());w=ledger['counterfactual_witnesses'];assert len(w)==2
 for v in w:assert v['all_substitutions_and_on_floor_actors_consistent_under_hypothesis'];assert not v['admitted']
 assert w[0]['quarter3_clock_seconds']['1610612742:1631204']=='102';assert w[1]['quarter3_clock_seconds']['1610612742:1631204']=='224'
 assert w[0]['quarter3_clock_seconds']['1610612742:1642258']=='544';assert w[1]['quarter3_clock_seconds']['1610612742:1642258']=='422'
 assert not ledger['source_bytes_changed'] and not ledger['periods_admitted']

@pytest.mark.parametrize('mutation',['foul_team','technical_clock','rebound_owner','remove_heave','assist_not_onfloor'])
def test_hostile_event_changes_cannot_gain_acceptance(retained,mutation):
 raw,_,whole,_=retained;d=json.loads(raw);r=d['game']['actions']
 if mutation=='foul_team':r[161]['teamId']=1610612739
 if mutation=='technical_clock':r[167]['clock']='PT06M53.99S'
 if mutation=='rebound_owner':r[171]['personId']=123456
 if mutation=='remove_heave':r[235]['actionType']=''
 if mutation=='assist_not_onfloor':r[156]['description']=r[156]['description'].replace('(Flemings 2 AST)','(Daniels 2 AST)')
 with pytest.raises(ValueError):event_basis(json.dumps(d).encode(),whole)

@pytest.mark.parametrize('mutation',['positive_rate_missing','wrong_rebounds','wrong_margin','wrong_usg','wrong_assist','wrong_rate_population'])
def test_hostile_direct_period_fields_cannot_gain_acceptance(retained,mutation):
 raw,_,whole,read=retained;t=json.loads(read('boxscoretraditionalv3',2,2,1));a=json.loads(read('boxscoreadvancedv3',2,2,1));tp=t['boxScoreTraditional']['homeTeam']['players'];ap=a['boxScoreAdvanced']['homeTeam']['players'];p=next(p for p in tp if p['personId']==1630552);r=next(p for p in ap if p['personId']==1630552)
 if mutation=='positive_rate_missing':a['boxScoreAdvanced']['homeTeam']['players'].remove(r)
 if mutation=='wrong_rebounds':p['statistics']['reboundsDefensive']+=1;p['statistics']['reboundsTotal']+=1
 if mutation=='wrong_margin':p['statistics']['plusMinusPoints']+=1
 if mutation=='wrong_usg':r['statistics']['usagePercentage']+=.001
 if mutation=='wrong_assist':p['statistics']['assists']+=1
 if mutation=='wrong_rate_population':r['statistics']['minutes']='0:00'
 with pytest.raises(ValueError):qualify_pair(raw,whole,json.dumps(t).encode(),json.dumps(a).encode(),start=2,end=2)

def test_true_shooting_is_independent_computed_count_basis(retained,qualified):
 raw,_,whole,read=retained
 for key,expected in [((2,2),Fraction(75,122)),((1,2),Fraction(125,272))]:
  t=json.loads(qualified[key][0]['boxscoretraditionalv3'])['boxScoreTraditional'];p=next(p for p in t['homeTeam']['players']if p['personId']==1630552)['statistics'];ts=Fraction(p['points'],1)/(2*(p['fieldGoalsAttempted']+Fraction(11,25)*p['freeThrowsAttempted']));assert ts==expected
  before=json.loads(read('boxscoretraditionalv3',*key,1))['boxScoreTraditional'];assert p['points']==next(p for p in before['homeTeam']['players']if p['personId']==1630552)['statistics']['points']+1

def test_independent_pipeline_replay_and_preserved_old_data(tmp_path):
 from tools.qualify_incremental_return import bound_zip
 from tools.stage_current_season import CURRENT,SUFFIX
 r=stage(CACHE,tmp_path/'reviewed-stage');assert r['admitted_windows']==645;assert r['retained_direct_successes']==1537;assert len(r['remaining_period_windows'])==2
 ds=r['dataset_assessment']['datasets'];assert sum(v['required']for v in ds)==16
 assert r['executed_stages'][0]['state']=='failed';assert all(v['state']=='passed'for v in r['executed_stages'][1:]);assert not r['full_snapshot_accepted']
 root=tmp_path/'reviewed-stage/stage'
 with bound_zip(CURRENT.parent/'retained-qualification-20261104/qualification-evidence.zip','8e177a33ee0c8f91e7f6d93c0030d8ef5575f379b09574bb3d71d7f19b3686e4')as z:
  for n in z.namelist():
   if n.startswith('period-qualification/stage/data/raw/')and n.endswith('.csv'):
    rel=n.removeprefix('period-qualification/stage/');old=z.read(n);new=(root/rel).read_bytes()
    assert new.startswith(old)if'game_period_stats/'in rel else new==old
 players=pd.read_csv(root/'data/raw/player_game_period_stats'/SUFFIX)
 slice=players[players.game_id.eq(22600144)&players.player_id.eq(1630552)]
 assert slice[slice.period_family.eq('quarter')&slice.period_value.eq('2')].pts.item()==3
 assert slice[slice.period_family.eq('half')&slice.period_value.eq('first')].pts.item()==5
 for grain in ['player','team']:
  period=pd.read_csv(root/f'data/raw/{grain}_game_period_stats'/SUFFIX);assert not (period.game_id.eq(22600142)&((period.period_family.eq('quarter')&period.period_value.eq('3'))|(period.period_family.eq('half')&period.period_value.eq('second')))).any()
