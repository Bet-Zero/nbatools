exec(open('work/credit-checker/oracle.py').read().replace("if __name__=='__main__':", "if False:"))
import contextlib,io,copy
original=read('0022600142');original_doc=json.loads(original);original_read=read
results=[]
for outgoing in [1631204,1642258]:
 doc=copy.deepcopy(original_doc);row=next(r for r in doc['game']['actions']if r['actionId']==368);row['personId']=outgoing;row['description']='SUB: Martin FOR '+('Sasser'if outgoing==1631204 else 'Risacher')
 alternative=json.dumps(doc).encode()
 def read(gid):return alternative
 with contextlib.redirect_stdout(io.StringIO()):teams,rows,traces,clocks=run('0022600142')
 assert not json.loads(Path('work/credit-checker/0022600142.json').read_text())['errors']
 for r in rows:
  tid,pid,typ=r['teamId'],r['personId'],r['actionType']
  if tid in teams and pid>0 and(typ in ['Made Shot','Missed Shot','Free Throw','Rebound','Turnover']or typ=='Foul'and r['subType']in ['Personal','Shooting','Loose Ball','Offensive']):assert pid in traces[r['actionId']][tid],r
 results.append({'hypothesis_only':True,'admitted':False,'changed_action_id':368,'original_outgoing_player_id':1629023,'hypothetical_outgoing_player_id':outgoing,'incoming_player_id':1628997,'clock_unchanged':'PT02M02.00S','all_substitutions_and_on_floor_actors_consistent_under_hypothesis':True,'quarter3_clock_seconds':clocks[3],'quarter3_end_lineup':traces[387]if 387 in traces and next(r for r in rows if r['actionId']==387)['period']==3 else traces[max(a['actionId']for a in rows if a['period']==3)]})
read=original_read
with contextlib.redirect_stdout(io.StringIO()):run('0022600142')
whole=load('boxscoretraditionalv3','0022600142','full');quarter=load('boxscoretraditionalv3','0022600142','q3');aquarter=load('boxscoreadvancedv3','0022600142','q3')
record={'classification':'nonunique_source_interpretation_witnesses_not_corrections','game_id':'0022600142','original_event_sha256':hashlib.sha256(original).hexdigest(),'recovery_archive_sha256':hashlib.sha256((BASE/'recovery-capture-20261104/collection.zip').read_bytes()).hexdigest(),'original_source_error':json.loads(Path('work/credit-checker/0022600142.json').read_text())['errors'],'ambiguous_action_ids':[343,368],'original_facts':{'Washington_substituted_out_action343':True,'Washington_again_recorded_out_action368':True,'Martin_scores_action375':{'team_id':1610612742,'player_id':1628997,'points':2,'field_goals_made':1,'field_goals_attempted':1,'clock':'PT01M00.00S'},'Q3_Traditional_Martin_positive_row_absent':not any(p['personId']==1628997 for p in quarter['homeTeam']['players']),'Q3_Advanced_Martin_positive_row_absent':not any(p['personId']==1628997 for p in aquarter['homeTeam']['players'])},'counterfactual_witnesses':results,'conclusion':'At least two possible outgoing-player identities at action368 satisfy the remaining original events; no unique exact full clock vector or Advanced exposure credit can be inferred. Shooting event375 establishes Martin2PTS+1FGM+1FGA in Q3/H2; it does not establish which player left, complete clocks, possession or rate exposures. Original timing/rate gates remain unresolved.','exact_missing_information':['A qualified same-game on-court or substitution record identifying the actual outgoing player at action368 and any omitted/corrected substitutions around343/368.','Qualified period Traditional and Advanced positive-player rows including Martin with the complete Q3/H2 clock and rate population, or uniquely reconstructible corrected event chronology.'],'source_bytes_changed':False,'periods_admitted':False,'production_writes':0}
Path('work/credit-checker/0142-obligation-ledger.json').write_text(json.dumps(record,indent=2)+'\n')
print('WITNESSES',[(r['hypothetical_outgoing_player_id'], {pid:r['quarter3_clock_seconds'].get('1610612742:'+str(pid),'0')for pid in [1631204,1642258,1628997]})for r in results])
