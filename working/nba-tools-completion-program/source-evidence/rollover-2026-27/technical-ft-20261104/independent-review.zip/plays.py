exec(open('work/credit-checker/oracle.py').read().replace("if __name__=='__main__':", "if False:"))
import contextlib,io
with contextlib.redirect_stdout(io.StringIO()): teams,rows,traces,clocks=run('0022600144')
for q in [1,2]:
 acts=[r for r in rows if r['period']==q];tidset=set(teams);plays=[];active=None
 def begin(owner,aid):return {'team':owner,'first':aid,'players':set(traces[aid][owner])}
 def end(aid):
  global active
  active['last']=aid;active['players']=sorted(active['players']);plays.append(active);active=None
 first=next(r for r in acts if r['actionType']in['Made Shot','Missed Shot','Turnover','Free Throw'])
 active=begin(first['teamId'],acts[0]['actionId'])
 ft_andone={r['actionId']:next((f['actionId']for f in acts if f['clock']==r['clock']and f['teamId']==r['teamId']and f['personId']==r['personId']and f['subType']=='Free Throw 1 of 1'),None)for r in acts if r['actionType']=='Made Shot'}
 pending_andone=None
 for r in acts:
  aid,kind,owner=r['actionId'],r['actionType'],r['teamId']
  if kind=='Substitution':continue
  if active:active['players'].update(traces[aid][active['team']])
  if kind=='Free Throw'and r['subType']=='Free Throw Technical':continue
  if kind in ['Made Shot','Missed Shot','Turnover','Free Throw']:
   assert active and active['team']==owner,(q,aid,kind,active)
  if kind=='Made Shot'and ft_andone[aid]:pending_andone=ft_andone[aid];continue
  terminal=kind in ['Made Shot','Missed Shot','Turnover','Heave'] or kind=='Free Throw'and (lambda m:m and m[1]==m[2])(re.fullmatch('Free Throw ([123]) of ([123])',r['subType']))
  if terminal:
   assert active,(aid,kind)
   own=active['team'];end(aid)
   if kind in ['Made Shot','Turnover']or kind=='Free Throw'and not r['description'].startswith('MISS '):active=begin(next(t for t in tidset if t!=own),aid)
  elif kind=='Rebound':
   before=next(v for v in reversed(acts[:acts.index(r)])if v['actionType']in ['Missed Shot','Free Throw','Heave'])
   if before['actionType']=='Free Throw':
    m=re.fullmatch('Free Throw ([123]) of ([123])',before['subType'])
    if m and m[1]!=m[2]:continue
   assert active is None,(aid,active)
   active=begin(owner if owner else r['personId'],aid)
  elif kind=='period'and r['subType']=='end'and active:end(aid)
 print('PERIOD',q,'N',Counter(p['team']for p in plays))
 for tid in teams:
  den=Counter(pid for p in plays if p['team']==tid for pid in p['players'])
  orig=load('boxscoretraditionalv3','0022600144','q'+str(q));adv=load('boxscoreadvancedv3','0022600144','q'+str(q));side=next(s for s in ['homeTeam','awayTeam']if orig[s]['teamId']==tid)
  for p in orig[side]['players']:
   pid=p['personId'];num=sum(r['personId']==pid and r['teamId']==tid and r['actionType']in ['Made Shot','Missed Shot','Turnover']for r in acts)
   num+=sum(r['personId']==pid and r['teamId']==tid and r['subType']in ['Free Throw 1 of 2','Free Throw 1 of 3']for r in acts)
   a=next(a for a in adv[side]['players']if a['personId']==pid)['statistics']['usagePercentage']
   if den[pid]: print(tid,pid,p['familyName'],'USG',num,den[pid],round(num/den[pid],3),a,'OK',abs(Fraction(num,den[pid])-Fraction(str(a)))<=Fraction(1,2000))
 Path('work/credit-checker/plays-q'+str(q)+'.json').write_text(json.dumps(plays,indent=2))
