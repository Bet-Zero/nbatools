exec(open('work/credit-checker/exposure.py').read().split('records=[]')[0])
result=[]
for window,qs in [('q1',[1]),('q2',[2]),('h1',[1,2])]:
 adv=load('boxscoreadvancedv3','0022600144',window)
 for side in ['homeTeam','awayTeam']:
  tid=adv[side]['teamId'];den=Counter()
  for q in qs:
   for unit in allout[q]['possessions']:
    if unit['team']==tid:continue
    start,end=unit['first'],unit['last'];exposed=set();previous=next(clock(r)for r in rows if r['actionId']==start)
    for r in rows:
     if not start<=r['actionId']<=end or r['actionType']=='Substitution':continue
     current=clock(r)
     if previous>current:exposed.update(traces[r['actionId']][tid])
     previous=current
     if r['actionId']<=start or r['teamId']!=unit['team']:continue
     kind=r['actionType'];made=kind in ['Made Shot','Free Throw']and not r['description'].startswith('MISS ')
     if made:
      anchor=r['actionId']
      if kind=='Free Throw':anchor=max(a['actionId']for a in rows if a['period']==q and a['clock']==r['clock']and a['actionId']<r['actionId']and a['actionType']=='Foul')
      exposed.update(traces[anchor][tid])
    den.update(exposed)
  for p in adv[side]['players']:
   pid=p['personId'];pa=sum(allout[q]['pointagainst'][tid,pid]for q in qs)
   if not den[pid]:continue
   dr=Fraction(pa*100,den[pid]);reported=Fraction(str(p['statistics']['defensiveRating']));result.append(dict(window=window,player_id=pid,points_against=pa,opponent_possessions_exposed=den[pid],defensive_rating=str(dr),reported=str(reported),matches=abs(dr-reported)<=Fraction(1,20)))
Path('work/credit-checker/defensive-rating-oracles.json').write_text(json.dumps(result,indent=2)+'\n')
print('DEFENSE',len(result),sum(r['matches']for r in result),[r for r in result if not r['matches']])
