import json,zipfile,pathlib,collections,re,hashlib,unicodedata
def norm(s):return "".join(c for c in unicodedata.normalize("NFKD",s) if not unicodedata.combining(c) and c.isalnum()).casefold()
P=pathlib.Path('working/nba-tools-completion-program/source-evidence/rollover-2026-27')
ledger=json.load(open(P/'technical-ft-20261104/count-coherence.json'))['conflicts']
events={}
for fn in ['current-refresh-20261104/current-sources.zip','retained-qualification-20261104/precision-source-originals.zip']:
 z=zipfile.ZipFile(P/fn)
 for n in z.namelist():
  if n.endswith('.json'):
   d=json.loads(z.read(n))
   if isinstance(d,dict) and 'game' in d and 'actions' in d['game']:events[d['game']['gameId']]=(d['game']['actions'],hashlib.sha256(z.read(n)).hexdigest())
for f in pathlib.Path('work/count-groups').glob('002260*.json'):
 raw=f.read_bytes();d=json.loads(raw);events[d['game']['gameId']]=(d['game']['actions'],hashlib.sha256(raw).hexdigest())
for c in json.load(open(P/'current-refresh-20261104/period-basis-deltas.json'))['conflicts']:
 if c['game_id']=='0022600142':ledger.append(dict(game_id=c['game_id'],player_id=c['player_id'],team_id=c['team_id'],field=c['field'].lower(),period_sum=c['period_sum'],canonical=c['staged_core']))
res=[]
vectors=[]
for gid,(rows,sha) in events.items():
 if gid not in {c['game_id'] for c in ledger}:continue
 counts=collections.Counter(); observations=collections.defaultdict(list)
 aliases=collections.defaultdict(set)
 # independent literal name set from actor source identities
 for r in rows:
  if r['teamId']>0 and r['personId']>0:
   for name in [r['playerName'],r['playerNameI']]:
    if name:aliases[(r['teamId'],norm(name))].add(r['personId'])
 path=P/f'readiness-reassessment/sources/boxscoretraditionalv3_{gid}.json'
 whole=json.loads(path.read_bytes())['boxScoreTraditional'] if path.exists() else json.loads(zipfile.ZipFile(P/'stats-sources.zip').read(f'representative-sources/traditional_{gid}.json'))['boxScoreTraditional']
 for side in ['homeTeam','awayTeam']:
  for player in whole[side]['players']:
   for n in range(1,len(player['firstName'])+1):aliases[(whole[side]['teamId'],norm(player['firstName'][:n]+player['familyName']))].add(player['personId'])
 last_shot=None
 for r in rows:
  pid=r['personId'];tid=r['teamId'];kind=r['actionType'];desc=r['description'];updates={}
  if pid<1000000000 and tid>0:
   if kind=='':
    if ' STEAL ' in desc: updates['stl']=1
    if ' BLOCK ' in desc: updates['blk']=1
   if kind=='Turnover':updates['tov']=1
   if kind in ['Made Shot','Missed Shot']:
    made=int(kind=='Made Shot'); updates.update(fga=1,fgm=made,pts=made*r['shotValue'],fg3a=int(r['shotValue']==3))
   if kind=='Free Throw':updates['pts']=int(not desc.startswith('MISS'))
   if kind=='Rebound':
    assert last_shot is not None and (last_shot['actionType']=='Missed Shot' or last_shot['description'].startswith('MISS ')),(gid,r,last_shot)
    updates['oreb' if tid==last_shot['teamId'] else 'dreb']=1
    updates['reb']=1
   for f,v in updates.items():
    counts[(pid,f)]+=v; observations[(pid,f)].append({'id':r['actionId'],'period':r['period'],'clock':r['clock'],'description':desc,'value':v})
  if kind in ['Made Shot','Missed Shot','Free Throw','Heave']:last_shot=r
  if kind=='Made Shot':
   m=re.search(r'\(([^()]+) \d+ AST\)',desc)
   if m:
    ids=aliases[(tid,norm(m[1]))]
    if len(ids)==1:
     aid=next(iter(ids));counts[(aid,'ast')]+=1;observations[(aid,'ast')].append({'id':r['actionId'],'period':r['period'],'clock':r['clock'],'description':desc,'value':1})
 for f in sorted({c['field'] for c in ledger if c['game_id']==gid}):
  if f not in ['stl','blk','tov','fga','fgm','pts','fg3a','reb','oreb','dreb','ast']:continue
  for pid in sorted({r['personId'] for r in rows if r['teamId']>0 and r['personId']<1000000000}):
   vectors.append(dict(game_id=gid,player_id=pid,field=f,full=counts[(pid,f)],quarters={q:sum(o['value'] for o in observations[(pid,f)] if o['period']==q) for q in [1,2,3,4]}))
 for c in ledger:
  if c['game_id']!=gid or c['field'] not in ['stl','blk','tov','fga','fgm','pts','fg3a','reb','oreb','dreb','ast']:continue
  k=(c['player_id'],c['field']);v=counts[k]
  res.append(dict(c,event_count=v,agrees_canonical=v==c['canonical'],agrees_period=v==c['period_sum'],source_sha256=sha,events=observations[k]))
print(json.dumps({'covered':len(res),'uncovered':83-len(res),'canonical':sum(x['agrees_canonical'] for x in res),'period':sum(x['agrees_period'] for x in res),'observations':res,'vectors':vectors},indent=2))
