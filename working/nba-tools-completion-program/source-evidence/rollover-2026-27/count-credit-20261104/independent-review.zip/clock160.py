import json,zipfile,pathlib,re,collections,unicodedata,hashlib
from fractions import Fraction
P=pathlib.Path('working/nba-tools-completion-program/source-evidence/rollover-2026-27')
raw=pathlib.Path('work/count-groups/0022600160.json').read_bytes();rows=json.loads(raw)['game']['actions']
with zipfile.ZipFile(P/'current-refresh-20261104/current-sources.zip') as z:whole_raw=z.read('boxscoretraditionalv3-0022600160.json')
whole=json.loads(whole_raw)['boxScoreTraditional'];teams={whole[s]['teamId']:whole[s] for s in ['homeTeam','awayTeam']}
def norm(s):return ''.join(c for c in unicodedata.normalize('NFKD',s).casefold() if c.isalnum())
def clock(s):
 m=re.fullmatch(r'PT(\d+)M(\d+(?:\.\d+)?)S',s);assert m
 return Fraction(m[1])*60+Fraction(m[2])
alias=collections.defaultdict(set)
for t,team in teams.items():
 for p in team['players']:
  for family in [p['familyName'],re.sub(r'\s+Jr\.?$','',p['familyName'])]:
   alias[t,norm(family)].add(p['personId'])
   for n in range(1,len(p['firstName'])+1):alias[t,norm(p['firstName'][:n]+family)].add(p['personId'])
def incoming(r):
 m=re.fullmatch(r'SUB: (.+) FOR (.+)',r['description']);assert m,r
 ids=alias[r['teamId'],norm(m[1])];assert len(ids)==1,(r,ids)
 return next(iter(ids))
def actor(r):return r['actionType'] in ['Made Shot','Missed Shot','Free Throw','Rebound','Turnover','Jump Ball'] or r['actionType']=='Foul' and r['subType'] in ['Personal','Shooting','Loose Ball','Offensive','Offensive Charge','Away From Play'] or r['actionType']=='' and (' STEAL ' in r['description'] or ' BLOCK ' in r['description'])
seconds=collections.Counter();starts={};traces=[]
for q in [1,2,3,4]:
 acts=[r for r in rows if r['period']==q];entered=set();starters=collections.defaultdict(set)
 for r in acts:
  t,p=r['teamId'],r['personId']
  if r['actionType']=='Substitution':
   if (t,p) not in entered:starters[t].add(p)
   entered.add((t,incoming(r)))
  elif t in teams and p<1000000000 and actor(r) and (t,p) not in entered:starters[t].add(p)
 assert all(len(starters[t])==5 for t in teams),(q,starters)
 starts[q]={t:sorted(ps) for t,ps in starters.items()};floor={t:set(ps) for t,ps in starters.items()};previous=Fraction(720)
 for r in acts:
  now=clock(r['clock']);assert 0<=now<=previous;elapsed=previous-now
  for t,ps in floor.items():
   for p in ps:seconds[q,t,p]+=elapsed
  t,p=r['teamId'],r['personId']
  if r['actionType']=='Substitution':
   incoming_id=incoming(r);assert p in floor[t] and incoming_id not in floor[t],r
   floor[t].remove(p);floor[t].add(incoming_id)
  elif t in teams and p<1000000000 and actor(r):assert p in floor[t],r
  traces.append(dict(action_id=r['actionId'],quarter=q,lineups={str(t):sorted(ps) for t,ps in floor.items()}));previous=now
 assert previous==0
 for t in teams:assert sum(v for (quarter,team,p),v in seconds.items() if (quarter,team)==(q,t))==3600
pid=1642854;person=next(p for team in teams.values() for p in team['players'] if p['personId']==pid);tid=next(t for t,team in teams.items() if person in team['players'])
vals=[seconds[q,tid,pid] for q in [1,2,3,4]];assert vals==[275,335,211,209];assert sum(vals)==1030
other=[488,82,1124];precise=(sum(vals)+sum(other))/Fraction(60*4);reported=Fraction('11.4');difference=abs(precise-reported);assert precise==Fraction('11.35') and difference==Fraction('0.05')
print(json.dumps(dict(event_sha256=hashlib.sha256(raw).hexdigest(),whole_sha256=hashlib.sha256(whole_raw).hexdigest(),independent_replay='inferred5starters_eachquarter_then_exact_elapsed5player_substitution_replay',all_quarter_team_seconds_3600=True,actor_presence_and_substitution_consistent=True,player_id=pid,quarter_seconds=list(map(str,vals)),full_seconds='1030',other_previously_qualified_game_seconds=other,mean_minutes=str(precise),reported_minutes='11.4',absolute_difference=str(difference),unchanged_inclusive_tolerance='1/20',passes_boundary=True,starters=starts),indent=2))
