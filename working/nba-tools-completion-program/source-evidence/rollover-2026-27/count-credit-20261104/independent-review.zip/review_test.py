"""Separate checker tests; expected counts were derived independently before candidate."""
import copy
import json
import pathlib
import zipfile
import pytest
from tools.qualify_period_counts import count_events, retained_sources
from tools.stage_current_season import CURRENT, _whole_original

ORACLE=json.loads(pathlib.Path('work/count-checker/oracles.json').read_text())

@pytest.fixture(scope='module')
def sources():
    return retained_sources()


def whole(gid):
    if gid in {'0022600142','0022600138'}:
        with zipfile.ZipFile(CURRENT.parent/'stats-sources.zip') as z:
            return z.read(f'representative-sources/traditional_{gid}.json')
    return _whole_original(gid)


def test_all83_independently_derived_obligation_totals(sources):
    actual={}
    for gid in sorted({x['game_id'] for x in ORACLE['observations']}):
        actual[gid]=count_events(sources[gid],whole(gid))[0]
    for obs in ORACLE['observations']:
        observed=sum(v for (q,t,p,f),v in actual[obs['game_id']].items() if (t,p,f)==(obs['team_id'],obs['player_id'],obs['field']))
        assert observed==obs['event_count']==obs['canonical']


def test_complete964_affected_actor_vectors_and_quarters(sources):
    actual={gid:count_events(sources[gid],whole(gid))[0] for gid in sorted({x['game_id'] for x in ORACLE['vectors']})}
    for obs in ORACLE['vectors']:
        counts=actual[obs['game_id']]
        for q,v in obs['quarters'].items():
            assert sum(c for (quarter,t,p,f),c in counts.items() if (quarter,p,f)==(int(q),obs['player_id'],obs['field']))==v


@pytest.mark.parametrize('mutation',['unmatched_credit','ambiguous_assist','shot_value','bad_rebound','reordered','oversize_clock','duplicate_start'])
def test_hostile_source_evidence_rejected(sources,mutation):
    gid='0022600007';document=json.loads(sources[gid]);rows=document['game']['actions']
    if mutation=='unmatched_credit':
        idx=next(i for i,r in enumerate(rows) if ' STEAL ' in r['description']);rows[idx-1]['actionType']='Violation'
    elif mutation=='ambiguous_assist':
        r=next(r for r in rows if r['actionType']=='Made Shot' and 'Jal. Williams 1 AST' in r['description']);r['description']=r['description'].replace('Jal. Williams','Williams')
    elif mutation=='shot_value':next(r for r in rows if r['actionType']=='Made Shot')['shotValue']=4
    elif mutation=='bad_rebound':
        idx=next(i for i,r in enumerate(rows) if r['actionType']=='Rebound' and r['teamId']>0 and r['personId']<1000000000)
        prev=next(r for r in reversed(rows[:idx]) if r['actionType'] in ['Made Shot','Missed Shot','Free Throw']);prev['actionType']='Made Shot'
    elif mutation=='reordered':rows[20],rows[21]=rows[21],rows[20]
    elif mutation=='oversize_clock':rows[0]['clock']='PT13M00S'
    elif mutation=='duplicate_start':
        rows.insert(1,copy.deepcopy(rows[0]))
        for i,r in enumerate(rows,1):r['actionId']=i
    with pytest.raises(ValueError):count_events(json.dumps(document).encode(),whole(gid))


def test_0009_score_failure_remains_explicit_and_narrow(sources):
    _,_,facts=count_events(sources['0022600009'],whole('0022600009'))
    assert facts['strict_score_validation'] is False
    assert 'score' in facts['strict_error'].lower()


def test_0009_score_failure_does_not_hide_duplicate_period_end(sources):
    gid='0022600009';document=json.loads(sources[gid]);rows=document['game']['actions']
    i=next(i for i,r in enumerate(rows) if r['actionType']=='period' and r['subType']=='end')
    rows.insert(i,copy.deepcopy(rows[i]))
    for j,r in enumerate(rows,1):r['actionId']=j
    with pytest.raises(ValueError):count_events(json.dumps(document).encode(),whole(gid))
