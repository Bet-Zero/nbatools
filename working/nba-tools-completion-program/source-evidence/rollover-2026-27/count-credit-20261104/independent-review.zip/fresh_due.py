"""Independent raw-schedule due membership, separate from readiness helper."""
import json,datetime,zoneinfo,csv,pathlib,hashlib
p=pathlib.Path('work/count-groups/fresh-schedule.json');d=json.loads(p.read_bytes());now=datetime.datetime.now(datetime.timezone.utc);cutoff=now-datetime.timedelta(hours=24);games=[]
for group in d['leagueSchedule']['gameDates']:
 for g in group['games']:
  if g['gameId'].startswith('00226'):
   t=datetime.datetime.fromisoformat(g['gameDateTimeUTC'].replace('Z','+00:00'));date=datetime.datetime.strptime(group['gameDate'],'%m/%d/%Y %H:%M:%S').date();assert t.astimezone(zoneinfo.ZoneInfo('America/New_York')).date()==date;games.append((g['gameId'],t,g['gameStatus'],date.isoformat()))
assert len(games)==len({g[0] for g in games});due=sorted(g[0] for g in games if g[1]<=cutoff)
stage=pathlib.Path('work/count-checker/retained-stage/stage/data/raw/games/2026-27_regular_season.csv');observed={str(int(r['game_id'])).zfill(10):r for r in csv.DictReader(stage.open())};missing=[gid for gid in due if gid not in observed or int(observed[gid]['is_final'])!=1]
print(json.dumps(dict(checked_at=now.isoformat(),cutoff=cutoff.isoformat(),lag_hours=24,raw_regular_season_rows=len(games),due_game_ids=due,missing_from_retained_stage=missing,independent_implementation='raw NBA schedule UTCtimes minus24hours; regularseason00226 IDs; uniqueIDandNYbasketballdate checks; finalstage membership',source_sha256=hashlib.sha256(p.read_bytes()).hexdigest()),indent=2))
