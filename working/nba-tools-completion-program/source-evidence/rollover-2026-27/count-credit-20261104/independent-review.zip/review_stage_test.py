import csv,io,json,pathlib,zipfile
import pandas as pd
from tools.qualify_period_counts import CURRENT,SUFFIX,RATE_FIELDS
from tools.qualify_rollover_q1 import _local_stage
from nbatools.commands.player_game_finder import build_result
ROOT=pathlib.Path('work/count-checker/frozen-stage').resolve()
REPORT=json.loads((ROOT/'qualification.json').read_text())
ORACLE=json.loads(pathlib.Path('work/count-checker/oracles.json').read_text())


def test_corrected_quarters_and_halves_against_independent_actor_vectors():
    d=pd.read_csv(ROOT/f'stage/data/raw/player_game_period_stats/{SUFFIX}')
    compared=0
    for x in ORACLE['vectors']:
        rows=d.loc[d.game_id.eq(int(x['game_id'])) & d.player_id.eq(x['player_id'])]
        for row in rows.itertuples():
            qs=range(int(row.source_start_period),int(row.source_end_period)+1)
            expected=sum(x['quarters'].get(str(q),0) for q in qs)
            assert getattr(row,x['field'])==expected
            compared+=1
    assert compared>5000


def test_all_undeclared_tokens_and_other_dataset_bytes_preserved():
    changes=REPORT['count_changes']+REPORT['explicit_rate_invalidations']+REPORT['derived_count_ratio_changes']
    with zipfile.ZipFile(CURRENT.parent/'technical-ft-20261104/qualification-evidence.zip') as z:
        for n in z.namelist():
            if not n.startswith('stage/data/') or not n.endswith('.csv'):continue
            after=(ROOT/n).read_bytes();before=z.read(n)
            if 'game_period_stats/' not in n:assert before==after;continue
            grain='player' if '/player_game_period_stats/' in n else 'team'
            left=list(csv.reader(io.StringIO(before.decode())));right=list(csv.reader(io.StringIO(after.decode())))
            allowed={(c['row']+1,left[0].index(c['field'])) for c in changes if c['dataset']==grain}
            assert len(left)==len(right)
            for i,(a,b) in enumerate(zip(left,right,strict=True)):
                for j,(old,new) in enumerate(zip(a,b,strict=True)):
                    assert old==new or (i,j) in allowed


def test_all_sixteen_requirements_and_false_readiness_preserved():
    datasets=[d for d in REPORT['dataset_assessment']['datasets'] if d['required']];assert len(datasets)==16
    assert sum(d['required'] for d in datasets)==16
    assert sum(d['layer']=='raw' for d in datasets)==11
    assert sum(d['layer']=='processed' for d in datasets)==5
    states={d['name']:d['validation']['state'] for d in datasets}
    assert sum(s=='passed' for s in states.values())==14
    assert {n for n,s in states.items() if s=='failed'}=={'player_game_period_stats','team_game_period_stats'}
    assert REPORT['full_numerical_acceptance'] is False and REPORT['production_ready'] is False
    assert REPORT['general_possession_usage_accepted'] is False
    assert REPORT['production_writes']==0


def test_actual_count_consumers_and_null_rate_consumer():
    with _local_stage(ROOT/'stage'):
        for name,expected in [('Ajay Mitchell',2),('Jalen Williams',0)]:
            r=build_result(player=name,season='2026-27',quarter='2',start_date='2026-10-22',end_date='2026-10-22')
            assert r.result_status=='ok' and r.games.game_id.tolist()==[22600007]
            assert r.games.stl.tolist()==[expected]
        r=build_result(player='Jalen Williams',season='2026-27',quarter='3',start_date='2026-10-22',end_date='2026-10-22')
        assert r.result_status=='ok' and r.games.reb_pct.isna().all()


def test_independent_timing_and_fresh_due_agree():
    timing=json.loads(pathlib.Path('work/count-checker/0160-clock-review.json').read_text())
    due=json.loads(pathlib.Path('work/count-checker/fresh-due-review.json').read_text())
    assert timing['quarter_seconds']==REPORT['timing_addendum']['quarter_seconds']
    assert timing['absolute_difference']==REPORT['timing_addendum']['inclusive_limit']=='1/20'
    assert due['due_game_ids']==REPORT['due_population']['due_game_ids']
    assert not due['missing_from_retained_stage'] and not REPORT['due_population']['missing_due_game_ids']
    assert REPORT['due_population']['game0142_pbp_unchanged']
