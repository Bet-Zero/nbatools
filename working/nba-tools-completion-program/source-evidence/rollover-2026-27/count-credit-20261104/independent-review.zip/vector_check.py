import json,pathlib,zipfile,collections
p=pathlib.Path('working/nba-tools-completion-program/source-evidence/rollover-2026-27');r=json.load(open('work/count-checker/oracles.json'));names=dict(ast='assists',oreb='reboundsOffensive',reb='reboundsTotal',stl='steals',dreb='reboundsDefensive',fga='fieldGoalsAttempted',fg3a='threePointersAttempted',tov='turnovers',blk='blocks',fgm='fieldGoalsMade',pts='points');bad=[];known=0
for x in r['vectors']:
 gid=x['game_id'];path=p/f'readiness-reassessment/sources/boxscoretraditionalv3_{gid}.json'
 if path.exists():d=json.loads(path.read_bytes())['boxScoreTraditional']
 else:d=json.loads(zipfile.ZipFile(p/'stats-sources.zip').read(f'representative-sources/traditional_{gid}.json'))['boxScoreTraditional']
 ps=[v for s in ['homeTeam','awayTeam'] for v in d[s]['players'] if v['personId']==x['player_id']]
 assert len(ps)==1
 v=ps[0]['statistics'][names[x['field']]];known+=1
 if x['full']!=v:bad.append(dict(x,whole=v))
print(json.dumps(dict(compared=known,bad=bad),indent=2))
