import json,pathlib,pandas as pd,collections,zipfile
p=pathlib.Path('working/nba-tools-completion-program/source-evidence/rollover-2026-27')
r=json.load(open('work/count-checker/oracles.json')); names=dict(ast='assists',oreb='reboundsOffensive',reb='reboundsTotal',stl='steals',dreb='reboundsDefensive',fga='fieldGoalsAttempted',fg3a='threePointersAttempted',tov='turnovers',blk='blocks',fgm='fieldGoalsMade',pts='points')
core=pd.read_csv('work/count-checker/retained-stage/stage/data/raw/player_game_stats/2026-27_regular_season.csv'); ok=[]
for x in r['observations']:
 gid=x['game_id'];path=p/f'readiness-reassessment/sources/boxscoretraditionalv3_{gid}.json'
 if path.exists():whole=json.loads(path.read_bytes())['boxScoreTraditional']
 else:whole=json.loads(zipfile.ZipFile(p/'stats-sources.zip').read(f'representative-sources/traditional_{gid}.json'))['boxScoreTraditional']
 player=next(v for s in ['homeTeam','awayTeam'] for v in whole[s]['players'] if v['personId']==x['player_id']);v=player['statistics'][names[x['field']]];row=core[(core.game_id==int(gid))&(core.player_id==x['player_id'])].iloc[0]
 ok.append(dict(game_id=gid,player_id=x['player_id'],field=x['field'],whole=v,canonical=float(row[x['field']]),event=x['event_count'],all_match=bool(v==row[x['field']]==x['event_count'])))
assert all(x['all_match'] for x in ok)
print(json.dumps(ok,indent=2))
