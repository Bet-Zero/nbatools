"""Check retained full-game minutes as a potential independent on-court discriminator."""
from pathlib import Path
from fractions import Fraction
import json,zipfile,hashlib
P=Path('working/nba-tools-completion-program/source-evidence/rollover-2026-27')
with zipfile.ZipFile(P/'technical-ft-20261104/independent-review.zip') as z:
    base=json.loads(z.read('0022600142.json'))
    witness=json.loads(z.read('0142-obligation-ledger.json'))
with zipfile.ZipFile(P/'stats-sources.zip') as z:
    raw=z.read('representative-sources/traditional_0022600142.json')
whole=json.loads(raw)['boxScoreTraditional'];observations=[]
for side in ['homeTeam','awayTeam']:
    for person in whole[side]['players']:
        if person['personId'] not in [1631204,1642258,1628997]:continue
        pid=person['personId'];tid=whole[side]['teamId'];key=f'{tid}:{pid}'
        other=sum(Fraction(base['clocks'].get(str(q),{}).get(key,'0')) for q in [1,2,4])
        literal=person['statistics']['minutes'];mm,ss=literal.split(':');seconds=Fraction(mm)*60+Fraction(ss)
        observations.append(dict(player_id=pid,whole_literal=literal,other_quarters_event_seconds=str(other),whole_minus_other_quarters=str(seconds-other),counterfactual_Q3_seconds={str(w['hypothetical_outgoing_player_id']):w['quarter3_clock_seconds'].get(key,'0') for w in witness['counterfactual_witnesses']}))
print(json.dumps(dict(classification='retained_whole_minutes_are_conflicting_not_unique_oncourt_evidence',whole_source_sha256=hashlib.sha256(raw).hexdigest(),observations=observations,conclusion='Whole minutes favor incompatible outgoing-player hypotheses for Sasser and Risacher; no witness admitted. Martin positive122seconds corroborated to displayprecision but no Advanced row fabricated.',periods_admitted=False,source_requests=0),indent=2))
