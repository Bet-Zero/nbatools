"""Independent full input-vector and literal-preservation check for c55a4a59."""
import csv,hashlib,io,json,zipfile
from collections import Counter
from fractions import Fraction
from pathlib import Path
import pandas as pd
from tools.qualify_period_counts import retained_sources,count_events,FIELDS_BY_COLUMN
from tools.qualify_period_rates import whole_original,SUFFIX
from tools.period_event_evidence import clock_facts,period_facts
base=Path('working/nba-tools-completion-program/source-evidence/rollover-2026-27/grouped-rates-20261105')
out=Path('work/rate-semantics/candidate');report=json.loads((out/'qualification.json').read_text())
with zipfile.ZipFile(base/'qualification-evidence.zip') as z:
    previous=json.loads(z.read('qualification.json'))
    originals={n:z.read(n) for n in z.namelist() if n.startswith('stage/data/') and n.endswith('.csv')}
old={(c['row'],c['field']) for c in previous['changes']}
new=[c for c in report['changes'] if (c['row'],c['field']) not in old]
newkeys={(c['row'],c['field']) for c in new}
assert len(new)==len(newkeys)==110
assert {(c['row'],c['field']) for c in previous['unknown']}==newkeys|{(c['row'],c['field']) for c in report['unknown']}
assert len(report['unknown'])==554 and sum(not g['qualified'] for g in report['groups'])==22
name=f'stage/data/raw/player_game_period_stats/{SUFFIX}'
before=list(csv.reader(io.StringIO(originals[name].decode())))
after=list(csv.reader(io.StringIO((out/name).read_text())))
alltokens=0;changed=[]
for i,(left,right) in enumerate(zip(before,after,strict=True)):
    for j,(a,b) in enumerate(zip(left,right,strict=True)):
        alltokens+=1
        if a!=b:
            assert (i-1,before[0][j]) in newkeys
            changed.append((i-1,before[0][j]))
assert set(changed)==newkeys
otherfiles=[]
for n,raw in originals.items():
    if n==name:continue
    assert (out/n).read_bytes()==raw
    otherfiles.append({'file':n,'sha256':hashlib.sha256(raw).hexdigest()})
frame=pd.read_csv(out/name);core=pd.read_csv(out/f'stage/data/raw/player_game_stats/{SUFFIX}')
sources=retained_sources();full=[];windows=[];clocks=[];groups={}
for c in new:groups[c['game_id'],tuple(c['periods']),c['field']]=True
for gid in sorted({k[0] for k in groups}):
    raw=sources[gid];wr=whole_original(gid);w=json.loads(wr)['boxScoreTraditional']
    counts,_,cf=count_events(raw,wr)
    for side in ['homeTeam','awayTeam']:
        t=w[side]
        for p in t['players']:
            canon=core.loc[core.game_id.eq(int(gid))&core.team_id.eq(t['teamId'])&core.player_id.eq(p['personId'])]
            for f in ['fga','fta','tov','ast']:
                event=sum(v for (q,tid,pid,col),v in counts.items() if (tid,pid,col)==(t['teamId'],p['personId'],f))
                assert event==p['statistics'][FIELDS_BY_COLUMN[f]]
                assert len(canon)==1 and canon.iloc[0][f]==event or canon.empty and event==0
                full.append(dict(game_id=gid,team_id=t['teamId'],player_id=p['personId'],field=f,event=event,whole=event,canonical=event))
    facts=period_facts(raw,game_id=gid,final_teams={w[s]['teamId']:w[s]['statistics']['points'] for s in ['homeTeam','awayTeam']},score_snapshots=cf.get('score_metadata_evidence'))
    usg_qs={q for g,qs,f in groups if g==gid and f=='usg_pct' for q in qs}
    clock=clock_facts(raw,wr,period_report=facts,only_periods=usg_qs) if usg_qs else {}
    for g,qs,f in groups:
        if g!=gid:continue
        rows=frame.loc[frame.game_id.eq(int(gid))&frame.source_start_period.eq(qs[0])&frame.source_end_period.eq(qs[-1])]
        for _,r in rows.iterrows():
            tid,pid=int(r.team_id),int(r.player_id)
            for col in ['fga','fta','tov']+(['ast'] if f=='tov_pct' else []):
                expected=sum(counts[q,tid,pid,col] for q in qs)
                assert r[col]==expected
                windows.append(dict(game_id=g,periods=qs,field=f,team_id=tid,player_id=pid,input=col,value=expected))
            if f=='usg_pct':
                seconds=sum(clock[q][tid].get(pid,Fraction(0)) for q in qs)
                assert abs(seconds-Fraction(str(r.minutes))*60)<=2
                clocks.append(dict(game_id=g,periods=qs,team_id=tid,player_id=pid,event_seconds=str(seconds),canonical_minutes=str(r.minutes)))
        if f=='usg_pct':
            for tid in {w[s]['teamId'] for s in ['homeTeam','awayTeam']}:
                exposed={pid for q in qs for pid,sec in clock[q][tid].items() if sec>0}
                assert exposed==set(rows.loc[rows.team_id.eq(tid)&rows.minutes.gt(0),'player_id'])
result={'reviewed_revision':'c55a4a590fc1caee52be11b96595461cee59a9d8','whole_input_comparisons':len(full),'window_input_comparisons':len(windows),'clock_input_comparisons':len(clocks),'complete_positive_player_population_verified':True,'all_csv_tokens_checked':alltokens,'only_new110_tokens_changed':True,'prior701_entries_preserved':True,'other15datasets_identical':otherfiles,'whole_vectors':full,'window_vectors':windows,'clock_vectors':clocks,'tov_clock_dependency':'None: numerator/denominator depend on personal event counts and complete FT trips, no on-court clock/POSS divisor','reported_rate_or_poss_oracle':False}
Path('work/source-checker/complete-vectors-preservation.json').write_text(json.dumps(result,indent=2)+'\n')
print({k:v for k,v in result.items() if isinstance(v,(int,bool,str))})
