import copy,json
from pathlib import Path
from fractions import Fraction
import pandas as pd
import pytest
from tools.qualify_period_counts import retained_sources
from tools.qualify_period_rates import free_throw_facts
from tools.qualify_rollover_q1 import _local_stage

SOURCES=retained_sources()
def acts(g,q):return [a for a in json.loads(SOURCES[g])['game']['actions'] if a['period']==q]
TEAMS118={1610612758,1610612763}
TEAMS138={1610612745,1610612749}

@pytest.mark.parametrize('kind,desc',[('Shooting','S.FOUL'),('Personal','P.FOUL (P1.PN)'),('Unknown','Unknown'),('Away From Play','AWAY.FROM.PLAY'),('Defense 3 Second','D3SEC')])
def test_no_guess_when_another_foul_may_change_award(kind,desc):
    a=acts('0022600118',1);f=next(x for x in a if x['actionId']==9);f['subType']=kind;f['description']=desc
    with pytest.raises(ValueError,match='unique same-clock foul'):free_throw_facts(a,TEAMS118)

def test_wrong_team_is_rejected_after_selection():
    a=acts('0022600118',1);next(x for x in a if x['actionId']==10)['teamId']=1610612758
    with pytest.raises(ValueError,match='ownership differs'):free_throw_facts(a,TEAMS118)

def test_missing_selected_anchor_never_uses_nonpenalty_personal():
    a=acts('0022600118',1);a=[x for x in a if x['actionId']!=10]
    with pytest.raises(ValueError,match='unique same-clock foul'):free_throw_facts(a,TEAMS118)

def test_technical_ownership_and_competing_technical_rejected():
    a=acts('0022600138',3);next(x for x in a if x['actionId']==365)['teamId']=1610612749
    with pytest.raises(ValueError,match='ownership differs'):free_throw_facts(a,TEAMS138)
    a=acts('0022600138',3);f=copy.deepcopy(next(x for x in a if x['actionId']==365));f['actionId']=365.5;a.append(f)
    with pytest.raises(ValueError,match='unique same-clock foul'):free_throw_facts(a,TEAMS138)

def test_explicit_technical_defense3_rule_is_preserved():
    a=acts('0022600138',3)
    # This isolated typed-award control verifies the previously accepted branch.
    ft=copy.deepcopy(next(x for x in a if x['actionId']==366));f=copy.deepcopy(next(x for x in a if x['actionId']==365));f['subType']='Defense 3 Second'
    assert free_throw_facts([f,ft],TEAMS138)['credit']=={366:365}

@pytest.mark.parametrize('g,q,t,err',[('0022600091',3,{1610612745,1610612742},'Unsupported FT foul semantics'),('0022600091',4,{1610612745,1610612742},'Unsupported FT subtype'),('0022600118',4,TEAMS118,'Incomplete or conflicting FT trip'),('0022600121',2,{1610612738,1610612741},'Unsupported FT foul semantics'),('0022600121',4,{1610612738,1610612741},'Unsupported FT subtype')])
def test_retained_gaps_stay_unknown(g,q,t,err):
    with pytest.raises(ValueError,match=err):free_throw_facts(acts(g,q),t)

def test_actual_finder_new_fractions_and_unchanged_unknowns():
    from nbatools.commands.player_game_finder import build_result
    root=Path('work/rate-semantics/candidate/stage').resolve()
    evidence=[]
    with _local_stage(root):
        for kw,tov,usg in [(dict(quarter='1'),Fraction(1,4),Fraction(2,7)),(dict(half='first'),Fraction(2,9),Fraction(8,43))]:
            r=build_result(player='Domantas Sabonis',season='2026-27',start_date='2026-10-25',end_date='2026-10-25',**kw)
            assert r.result_status=='ok' and r.games.game_id.tolist()==[22600118]
            row=r.games.iloc[0];assert row.tov_pct==pytest.approx(float(tov));assert row.usg_pct==pytest.approx(float(usg))
            evidence.append(dict(player='Sabonis',window=kw,tov=str(tov),usg=str(usg),game_ids=r.games.game_id.tolist()))
        r=build_result(player='Nate Ament',season='2026-27',half='second',start_date='2026-10-28',end_date='2026-10-28')
        assert r.result_status=='ok' and r.games.game_id.tolist()==[22600138]
        row=r.games.iloc[0];assert row.tov_pct==pytest.approx(.1);assert pd.isna(row.usg_pct) and pd.isna(row.reb_pct)
        evidence.append(dict(player='Ament',window={'half':'second'},tov='1/10',usg_unknown=True,reb_unknown=True,game_ids=r.games.game_id.tolist()))
    Path('work/source-checker/finder-evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
