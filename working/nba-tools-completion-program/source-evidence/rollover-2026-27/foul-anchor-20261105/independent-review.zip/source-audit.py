"""Bounded independent audit of exact PR580 dependencies; no reported rate/POSS oracle."""
import hashlib,json,re
from pathlib import Path
from collections import Counter
from tools.qualify_period_counts import retained_sources
from tools.qualify_period_rates import whole_original
ROOT=Path('working/nba-tools-completion-program/source-evidence/rollover-2026-27/grouped-rates-20261105')
FT=re.compile(r'Free Throw ([123]) of ([123])')
sources=retained_sources()
ledger=json.loads((ROOT/'receipt.json').read_text())['unknown_dependencies']
assert len(ledger)==27 and sum(x['observations'] for x in ledger)==664

def classify(a):
    """Independent explanation set based on literal attempt and foul types."""
    explained=[]
    for r in a:
        if r['actionType']!='Free Throw':continue
        m=FT.fullmatch(r['subType'])
        if r['subType']!='Free Throw Technical' and not m:raise ValueError('Missing/unsupported FT ordinal subtype')
        raw=[f for f in a if f['actionType']=='Foul' and f['actionId']<r['actionId'] and f['clock']==r['clock']]
        if r['subType']=='Free Throw Technical':candidates=[f for f in raw if f['subType'] in {'Technical','Defense 3 Second'}]
        else:
            candidates=[]
            for f in raw:
                subtype=f['subType']
                if subtype=='Technical':continue
                if int(m[2])>1 and subtype=='Personal' and 'PN' not in f['description']:continue
                candidates.append(f)
        if len(candidates)!=1:raise ValueError('Nonunique admissible foul explanation')
        f=candidates[0]
        technical=r['subType']=='Free Throw Technical' or (m and m[1]==m[2]=='1' and f['subType']=='Defense 3 Second')
        if not technical:
            if f['subType'] not in {'Shooting','Personal','Loose Ball','Personal Take'}:raise ValueError('Unsupported retained-possession foul')
            if f['subType']!='Shooting' and 'PN' not in f['description']:raise ValueError('Nonshooting nonpenalty/retained-possession credit unknown')
            if f['subType']=='Personal Take' and int(m[2])==1:raise ValueError('Retained-possession credit unknown')
            trip=[x for x in a if x['actionType']=='Free Throw' and x['clock']==r['clock'] and x['teamId']==r['teamId'] and x['personId']==r['personId'] and FT.fullmatch(x['subType'])]
            if [FT.fullmatch(x['subType'])[1] for x in trip]!=[str(i) for i in range(1,int(m[2])+1)]:raise ValueError('Incomplete/canceled trip')
        if f['teamId'] not in {0} and f['teamId']==r['teamId']:raise ValueError('Foul charged to FT side')
        explained.append({'attempt':r['actionId'],'raw_foul_ids':[f['actionId'] for f in raw],'selected_foul':f['actionId'],'foul_type':f['subType'],'technical':bool(technical)})
    return explained

results=[]
for gid in ['0022600091','0022600118','0022600121','0022600138']:
    a=json.loads(sources[gid])['game']['actions']
    for q in range(1,5):
        try:proof=classify([r for r in a if r['period']==q]); result={'qualified_ft_semantics':True,'anchors':proof}
        except ValueError as e:result={'qualified_ft_semantics':False,'missing':str(e)}
        results.append(dict(game_id=gid,period=q,**result))
result={'population':ledger,'source_hashes':{g:hashlib.sha256(sources[g]).hexdigest() for g in ['0022600091','0022600118','0022600121','0022600138']},'ft_audit':results,'candidate_common_rules':['Technical attempt pairs only to technical/defensive-three-second foul','Ordinary numbered trip cannot be awarded by a technical foul','Nonpenalty personal foul cannot explain ordinary multi-attempt FT trip; retained-possession unknown types are never discarded'],'independent_definition_gaps':[{'games':['0022600091','0022600121'],'meaning':'Retained ball flow after take/flagrant is observed; statistical inclusion/exclusion in trip/use credit is not independently established','route':'Existing official source acquisition route for NBA statistical credit manual/definitions; no reported rates or possessions as oracle'},{'game':'0022600091','actions':[399,401,403,404],'meaning':'Three FTs lack ordinal/attempt kind; cannot uniquely partition penalties/trips','route':'Corrected detailed play-by-play/gamebook or synchronized video retaining same-game action attribution'},{'game':'0022600118','actions':[524,525,526],'meaning':'1of2 then lane-violation turnover without2of2; no independent rule for canceled trip and turnover joint credit','route':'Official statistical interpretation plus corrected detailed event/gamebook or video'}],'reported_rates_used':False,'reported_possessions_used':False,'new_source_requests':0,'production_writes':0}
Path('work/source-checker/source-audit.json').write_text(json.dumps(result,indent=2)+'\n')
for r in results:print(r['game_id'],r['period'],r.get('missing','supported'))
