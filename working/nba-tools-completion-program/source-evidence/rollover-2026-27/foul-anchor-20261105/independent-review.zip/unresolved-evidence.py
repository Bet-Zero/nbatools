"""Bounded source audit; preserves original event order and all unresolved values."""
import hashlib,json,zipfile
from pathlib import Path
from tools.qualify_period_counts import retained_sources
from tools.qualify_period_rates import whole_original
sources=retained_sources();root=Path('working/nba-tools-completion-program/source-evidence/rollover-2026-27')
raw=sources['0022600009'];a=json.loads(raw)['game']['actions'];whole=json.loads(whole_original('0022600009'))['boxScoreTraditional'];teams=[whole[s]['teamId'] for s in ['homeTeam','awayTeam']];score={t:0 for t in teams};mismatches=[]
for r in a:
    if r['actionType']=='Made Shot':score[r['teamId']]+=r['shotValue']
    elif r['actionType']=='Free Throw' and not r['description'].startswith('MISS '):score[r['teamId']]+=1
    literal={t:int(r[k]) for t,k in zip(teams,['scoreHome','scoreAway']) if r[k] not in ['',None]}
    if any(score[t]!=v for t,v in literal.items()):mismatches.append(dict(action_id=r['actionId'],period=r['period'],clock=r['clock'],kind=r['actionType'],event_prefix_score=dict(score),literal=literal))
assert len(mismatches)==13
r138=json.loads(sources['0022600138'])['game']['actions'];events138=[r for r in r138 if r['actionId'] in [432,481,482]]
assert events138[0]['personId']==events138[1]['personId']==1631131 and events138[2]['description']=='SUB: Tshiebwe FOR Sheppard'
assert events138[1]['clock']==events138[2]['clock']=='PT03M04.00S'
with zipfile.ZipFile(root/'technical-ft-20261104/independent-review.zip') as z:witness_raw=z.read('0142-obligation-ledger.json');witness=json.loads(witness_raw)
with zipfile.ZipFile(root/'count-credit-20261104/independent-review.zip') as z:minutes_raw=z.read('0142-minute-discriminator.json');minutes=json.loads(minutes_raw)
assert {r['hypothetical_outgoing_player_id'] for r in witness['counterfactual_witnesses']}=={1631204,1642258}
assert all(r['all_substitutions_and_on_floor_actors_consistent_under_hypothesis'] and not r['admitted'] for r in witness['counterfactual_witnesses'])
result={'0009':{'event_sha256':hashlib.sha256(raw).hexdigest(),'score_mismatches':mismatches,'missing':'Corrected complete scoring chronology at literal event clocks and score transitions; count-only equality cannot certify rate lineups','feasible_route':'Existing approved NBA source acquisition for corrected independent detailed event/gamebook; unchanged archived body is not new evidence','same_clock_replay_exception_applicable':False},'0138':{'event_sha256':hashlib.sha256(sources['0022600138']).hexdigest(),'events':events138,'missing':'Independent same-game on-court/substitution chronology proving whether rebound481 actor or entry482 timing/order is wrong, then complete positive-player clocks','feasible_route':'Qualified official same-game rotation or corrected gamebook/event/video aroundQ4 03:04; no verified distinguishing retained source','source_events_reordered':False},'0142':{'prior_witness_receipt_sha256':hashlib.sha256(witness_raw).hexdigest(),'prior_minutes_receipt_sha256':hashlib.sha256(minutes_raw).hexdigest(),'two_valid_witnesses_reused':True,'whole_minutes_do_not_uniquely_discriminate':True,'missing':'Independent same-game substitution atQ3 02:02/action368 choosing outgoing player, plus complete positive-player clocks/rates','specific_source_target':'Official same-game gamerotation0022600142 or corrected official gamebook/synchronized game video aroundQ3 02:02','obtainability':'Not established. Prior authenticated archive metadata has no2027gamerotation and season-lineup aggregates lack intervals. Do not retry unchanged sources without new reason.','blocked':True},'new_source_requests':0,'production_writes':0}
Path('work/source-checker/unresolved-evidence.json').write_text(json.dumps(result,indent=2)+'\n')
print('13scoremismatches;0138Q4identitycontradiction;0142priorwitnessesretained')
