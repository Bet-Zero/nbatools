"""Build/run a finite acquisition-only package with the laptop's existing nba_api.

Cloud usage: build_package(request, destination) embeds the reviewed request in
one standalone Python file. The generated file needs no NBA Tools checkout,
parameters, source selection, credentials or installation on the laptop.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import io
import json
import re
import time
import zipfile
import zlib
from datetime import UTC, datetime
from importlib.metadata import version
from pathlib import Path

# Replaced only by the cloud packaging function, never by laptop configuration.
EMBEDDED_REQUEST = json.loads(zlib.decompress(base64.b64decode(
    'eJzNnV1zG8eZhf8KC7crRtPdM8AMc+U42XWq4lixVEmlUinUABiSsEEMjQ9ZWpf/+w6GlNRO+nUj'
    'VQePNjcr8LMfHvB9n/ISfX6atIdD9/B42M8fu938u34xuXEvJot2383vum23aw/rfju5mbRv2/Wm'
    'Xaw368P760232PXb633X7of/89Zd+8JPXRHc5PlTH9rt+rbbH+b7+9ZX0+HzQzEL0yq0VVHPfFsu'
    'fbVYVLOwDItyWVRl0U274Iuyq4f3td1ttazKulv41e2t64rlbRi+8vJ46G9v58v7bvl9t5q3h+HL'
    'nr7xtXPXhX9TlDdhduPDb3zlZjP3X0VxUxTDp62O3fzpU+OPd+bH367fDV/9Xz6juB7h7tqHbr5e'
    '7Sc3/5gUhffTYvjf6R0fH/j4QYgflPGDKn4wjR/M4gd1/KCJHrj4C7j4C7j4C7j4C7j4C/gifhAj'
    '+BjBxwg+RqjjE9TxCer4BHV8gjo+QROfoIlP0MQnaOITNPEJmvgETXyCJj5BE5+giU7giiJ+4OIH'
    'Pn4Q4gdl/KCKH0zjB7P4QR0/iE/g4hO4+AQuPoGLT+DiE8TPAxc/D1z8PHDx88DFzwMXPw9c/Dxw'
    '8fPAxc8DFz8PnI9P4OMT+PgEPj6Bj08Q4hOE+AQhPkGITxDiE4T4BCE+QYhPEOIThPgEZXyCMj5B'
    'GZ+gjE9Qxico4xOU8QnK+ARlfIIyPkEVn6CKT1DFJ6jC5J8vJsOQPg2gnybddvXYr7enObjp2rtj'
    't2r394+b9n232x/aw374zMd2N4ysw/CGyc1Pky/7zaa764aPH971Zb+97Xbddvnx8XF72L1/evD7'
    '9tD9965/+PToTT/82xUvg3t5Gomnt67frvdP2+H0aNfeHl6tl99HD//etbunh/8znOL1sn/soofd'
    '3UM3Hn54w1fd+u7++d9/fP3m2+Esq8nN9rjZvJj8qd0f/nz6jIFhcvpB/WmE/ePvTw/Hx/3yw5oa'
    'Hn09bKXjrnvzfvxmX6zetgPi6vSOfnu4f/4S3zw+9tvhu7/p2ofTFyqGNx0Py/7h+YCvvnk+wvig'
    'XXZfrL477k8H/PPpDd3u6351+tDhX6eTPb1t3a+ev/yrMYQ/vBt26vrTT/jpra/6/frTaV9tjvuv'
    '19vj/vlLf9tuv3/+5+txvX5YQeNv09ObfvGTe3rTM+233d1x0+6unj91eO99f/hy0y+/H77uh+Bf'
    'H9rd8Iz43XCw+6e3fPgpjP/+sf9b+/ws+Ov+X58kf93/MvW/fczt5xeTfX/cLbv57Xpz+uinR/uX'
    'T0/I6/Y5iOvD/a4/3t1/dIbffHc66s8vfvF8XvTv9st+1x127Wr8abWbt+Hfns9/2K4+/Nj9i9Oj'
    'Z0pf10Xx9Cx7fpZEq3r8mKefl3v+YURfZHz8/GUKkyl5vPmnbzP/wf8q1ocfxv9Hpk9n+w+Azs4p'
    'KJiCLqcgyOnzMBk5/TrQ2TmVCqZSl1MpyOnzMBk5/ToQO/ecLKf7Xx/n4Nz7j5nSOWWA2N8n3dy7'
    'V+ynz8Nk5CTaT+4sJs/8Pvn5D4rfp8/DlMopCySeexkmle950vfUTEZOqO9lmFRzz5O+p2YyckJ9'
    'L8Ok8j1P+p6aycgJ9T1sP4G+x+wn1vewuQf6HjP3WN8LzO9TIH1PzZTKKQsknnsZJpXvBdL31ExG'
    'TqjvZZhUcy+QvqdmMnJCfS/DpPK9QPqemsnICfU9bD+BvsfsJ9b3sLkH+h4z91jfK5nfp5L0PTVT'
    'KqcskHjuZZhUvleSvqdmMnJCfS/DpJp7Jel7aiYjJ9T3Mkwq3ytJ31MzGTmhvoftJ9D3mP3E+h42'
    '90DfY+Ye63sV8/tUkb6nZkrllAUSz70Mk8r3KtL31ExGTqjvZZhUc68ifU/NZOSE+l6GSeV7Fel7'
    'aiYjJ9T3sP0E+h6zn1jfw+Ye6HvM3GN9b8r8Pk1J31MzpXLKAonnXoZJ5XtT0vfUTEZOqO9lmFRz'
    'b0r6nprJyAn1vQyTyvempO+pmYycUN/D9hPoe8x+Yn0Pm3ug7zFzj/W9GfP7NCN9T82UyikLJJ57'
    'GSaV781I31MzGTmhvpdhUs29Gel7aiYjJ9T3Mkwq35uRvqdmMnJCfQ/bT6DvMfuJ9T1s7oG+x8w9'
    '1vdq5vepJn1PzZTKKQsknnsZJpXv1aTvqZmMnFDfyzCp5l5N+p6aycgJ9b0Mk8r3atL31ExGTqjv'
    'YfsJ9D1mP7G+h8090PeYucf6XsP8PjWk76mZUjllgcRzL8Ok8r2G9D01k5ET6nsZJtXca0jfUzMZ'
    'OaG+l2FS+V5D+p6aycgJ9T1sP4G+x+wn1vewuQf6HjP3UN9zzN/DOvL1GnKmRE55IO3cyzGJfM+R'
    'r9eQMxk5kb6XYxLNPUe+XkPOZORE+l6OSeR7jny9hpzJyIn0PW4/cb4H7SfU97i5x/keNPdY32P+'
    'HtaRr9eQM6Vygl+vkWNS+R75eg05k5ET6nvM3y078vUaciYjJ9T3mNdrOPL1GnImIyfU97D9BPoe'
    's59Y38PmHuh7zNxjfY/5e1hHvl5DzpTKCX69Ro5J5Xvk6zXkTEZOqO8xf7fsyNdryJmMnFDfY16v'
    '4cjXa8iZjJxQ38P2E+h7zH5ifQ+be6DvMXOP9T3m72Ed+XoNOVMqJ/j1Gjkmle+Rr9eQMxk5ob7H'
    '/N2yI1+vIWcyckJ9j3m9hiNfryFnMnJCfQ/bT6DvMfuJ9T1s7oG+x8w91veYv4d15Os15EypnODX'
    'a+SYVL5Hvl5DzmTkhPoe83fLjny9hpzJyAn1Peb1Go58vYacycgJ9T1sP4G+x+wn1vewuQf6HjP3'
    'UN/zBfL75AvQ9+RMiZzyQNq5l2MS+d4JC/M9OZORE+l7OSbR3DthYb4nZzJyIn0vxyTyvRMW5nty'
    'JiMn0ve4/cT5HrSfUN/j5h7ne9DcY33PMb9PjvQ9NVMqpyyQeO5lmFS+50jfUzMZOaG+l2FSzT1H'
    '+p6aycgJ9b0Mk8r3HOl7aiYjJ9T3sP0E+h6zn1jfw+Ye6HvM3GN9zzO/T570PTVTKqcskHjuZZhU'
    'vudJ31MzGTmhvpdhUs09T/qemsnICfW9DJPK9zzpe2omIyfU97D9BPoes59Y38PmHuh7zNxjfS8w'
    'v0+B9D01UyqnLJB47mWYVL4XSN9TMxk5ob6XYVLNvUD6nprJyAn1vQyTyvcC6XtqJiMn1Pew/QT6'
    'HrOfWN/D5h7oe8zcY32vZH6fStL31EypnLJA4rmXYVL5Xkn6nprJyAn1vQyTau6VpO+pmYycUN/L'
    'MKl8ryR9T81k5IT6HrafQN9j9hPre9jcA32PmXuo79XM/eU12a8hZ0rklAfSzr0ck8j3arJfQ85k'
    '5ET6Xo5JNPdqsl9DzmTkRPpejknkezXZryFnMnIifY/bT5zvQfsJ9T1u7nG+B8091veY+8trsl9D'
    'zpTKCe7XyDGpfI/s15AzGTmhvsfcM1+T/RpyJiMn1PeYfo2a7NeQMxk5ob6H7SfQ95j9xPoeNvdA'
    '32PmHut7zP3lNdmvIWdK5QT3a+SYVL5H9mvImYycUN9j7pmvyX4NOZORE+p7TL9GTfZryJmMnFDf'
    'w/YT6HvMfmJ9D5t7oO8xc4/1Peb+8prs15AzpXKC+zVyTCrfI/s15ExGTqjvMffM12S/hpzJyAn1'
    'PaZfoyb7NeRMRk6o72H7CfQ9Zj+xvofNPdD3mLnH+h5zf3lN9mvImVI5wf0aOSaV75H9GnImIyfU'
    '95h75muyX0POZOSE+h7Tr1GT/RpyJiMn1Pew/QT6HrOfWN/D5h7oe8zcQ32vYe4vb8h+DTlTIqc8'
    'kHbu5ZhEvteQ/RpyJiMn0vdyTKK515D9GnImIyfS93JMIt9ryH4NOZORE+l73H7ifA/aT6jvcXOP'
    '8z1o7rG+x9xf3pD9GnKmVE5wv0aOSeV7ZL+GnMnICfU95p75huzXkDMZOaG+x/RrNGS/hpzJyAn1'
    'PWw/gb7H7CfW97C5B/oeM/dY32PuL2/Ifg05UyonuF8jx6TyPbJfQ85k5IT6HnPPfEP2a8iZjJxQ'
    '32P6NRqyX0POZOSE+h62n0DfY/YT63vY3AN9j5l7rO8x95c3ZL+GnCmVE9yvkWNS+R7ZryFnMnJC'
    'fY+5Z74h+zXkTEZOqO9lmFS+R/ZryJmMnFDfw/YT6HvMfmJ9D5t7oO8xc4/1Peb+8obs15AzpXKC'
    '+zVyTCrfI/s15ExGTqjvMffMN2S/hpzJyAn1PaZfoyH7NeRMRk6o72H7CfQ9Zj+xvofNPdD3mLnH'
    '+h5zf3lD9mvImVI5wf0aOSaV75H9GnImIyfU95h75huyX0POZOSE+h7Tr9GQ/RpyJiMn1Pew/QT6'
    'HrOfWN/D5h7oe8zcY32Pub+8Ifs15EypnOB+jRyTyvfIfg05k5ET6nvMPfMN2a8hZzJyQn2P6ddo'
    'yH4NOZORE+p72H4CfY/ZT6zvYXMP9D1m7rG+x9xf3pD9GnKmVE5wv0aOSeV7ZL+GnMnICfU95p75'
    'huzXkDMZOaG+x/RrNGS/hpzJyAn1PWw/gb7H7CfW97C5B/oeM/dY32PuL2/Ifg05UyonuF8jx6Ty'
    'PbJfQ85k5IT6HnPPfEP2a8iZjJxQ32P6NRqyX0POZOSE+h62n0DfY/YT63vY3AN9j5l7rO8x95c3'
    'ZL+GnCmVE9yvkWNS+R7ZryFnMnJCfY+5Z74h+zXkTEZOqO8x/RoN2a8hZzJyQn0P20+g7zH7ifU9'
    'bO6BvsfMPdL3XIHcXz58G8739Ez/ntMZQNK5l2XS+N6IRfmensnICfS9LJNm7o1YlO/pmYycQN/L'
    'Mml8b8SifE/PZOQE+h64nzDfo/YT6Xvg3MN8j5p7rO8h95cP34b0vcvfX34GkHjuIf0aIxbne5fv'
    '1zgDSOx7yD3zIxbne5e/Z/4MIPF+Qvo1RizO9y7fr3EGEDv3dPsJ9D1mP7G+h8090PeYucf6HnJ/'
    '+fBtSN+7/P3lZwCJ5x7SrzFicb53+X6NM4DEvofcMz9icb53+XvmzwAS7yekX2PE4nzv8v0aZwCx'
    'c0+3n0DfY/YT63vY3AN9j5l7rO8h95cP34b0vcvfX34GkHjuZZhUvgf2a+iZjJxQ30PumR+xON+7'
    '/D3zZwCJ91OGSeV7YL+GnsnICfU9bD+BvsfsJ9b3sLkH+h4z91jfQ+4vH74N6XuXv7/8DCDx3EP6'
    'NUYszvcu369xBpDY95B75kcszvcuf8/8GUDi/YT0a4xYnO9dvl/jDCB27un2E+h7zH5ifQ+be6Dv'
    'MXOP9T3k/vLh25C+d/n7y88AEs89pF9jxOJ87/L9GmcAiX0PuWd+xOJ87/L3zJ8BJN5PSL/GiMX5'
    '3uX7Nc4AYueebj+BvsfsJ9b3sLkH+h4z91jfQ+4vH74N6XuXv7/8DCDx3EP6NUYszvcu369xBpDY'
    '95B75kcszvcuf8/8GUDi/YT0a4xYnO9dvl/jDCB27un2E+h7zH5ifQ+be6DvMXOP9T3k/vLh25C+'
    'd/n7y88AEs89pF9jxOJ87/L9GmcAiX0PuWd+xOJ87/L3zJ8BJN5PSL/GiMX53uX7Nc4AYueebj+B'
    'vsfsJ9b3sLkH+h4z91jfQ+4vH74N6XuXv7/8DCDx3EP6NUYszvcu369xBpDY95B75kcszvcuf8/8'
    'GUDi/YT0a4xYnO9dvl/jDCB27un2E+h7zH5ifQ+be6DvMXOP9T3k/vLh25C+d/n7y88AEs89pF9j'
    'xOJ87/L9GmcAiX0PuWd+xOJ87/L3zJ8BJN5PSL/GiMX53uX7Nc4AYueebj+BvsfsJ9b3sLkH+h4z'
    '91Dfc8z95Y7s15AzJXLKA2nnXo5J5HuO7NeQMxk5kb6XYxLNPUf2a8iZjJxI38sxiXzPkf0aciYj'
    'J9L3uP3E+R60n1Df4+Ye53vQ3JP5ngSqkgXVHxTC93mg0klliMRmztw078gmFDlTKie4CSXHpDJz'
    'sglFzmTkhJo50wjgyCYUOZORE2rmTBOKI5tQ5ExGTqiZY/sJNHNmP7Fmjs090MyZucf+l1jmpnlH'
    'NqHImVI5wU0oOSaV75FNKHImIyfU95hGAEc2ociZjJxQ32OaUBzZhCJnMnJCfQ/bT6DvMfuJ9T1s'
    '7oG+x8w91veYm+Yd2YQiZ0rlBDeh5JhUvkc2ociZjJxQ32MaARzZhCJnMnJCfS/DpPI9sglFzmTk'
    'hPoetp9A32P2E+t72NwDfY+Ze6zvMTfNO7IJRc6UygluQskxqXyPbEKRMxk5ob7HNAI4sglFzmTk'
    'hPoe04TiyCYUOZORE+p72H4CfY/ZT6zvYXMP9D1m7rG+x9w078gmFDlTKie4CSXHpPI9sglFzmTk'
    'hPoe0wjgyCYUOZORE+p7TBOKI5tQ5ExGTqjvYfsJ9D1mP7G+h8090PeYucf6HnPTvCObUORMqZzg'
    'JpQck8r3yCYUOZORE+p7TCOAI5tQ5ExGTqjvMU0ojmxCkTMZOaG+h+0n0PeY/cT6Hjb3QN9j5h7r'
    'e8xN845sQpEzpXKCm1ByTCrfI5tQ5ExGTqjvMY0AjmxCkTMZOaG+xzShOLIJRc5k5IT6HrafQN9j'
    '9hPre9jcA32PmXus7zE3zTuyCUXOlMoJbkLJMal8j2xCkTMZOaG+xzQCOLIJRc5k5IT6HtOE4sgm'
    'FDmTkRPqe9h+An2P2U+s72FzD/Q9Zu6xvsfcNO/IJhQ5UyonuAklx6TyPbIJRc5k5IT6HtMI4Mgm'
    'FDmTkRPqe0wTiiObUORMRk6o72H7CfQ9Zj+xvofNPdD3mLmH+p5nbpr3ZBOKnCmRUx5IO/dyTCLf'
    '82QTipzJyIn0vRyTaO55sglFzmTkRPpejknke55sQpEzGTmRvsftJ873oP2E+h439zjfg+Ye24SS'
    'gxI1oXi0CUUOlU4KbULxzE3znmxCkTOlcoKbUHJMKjMnm1DkTEZOqJkzjQCebEKRMxk5oWbONKF4'
    'sglFzmTkhJo5tp9AM2f2E2vm2NwDzZyZe+x/iWVumvdkE4qcKZUT3ISSY1L5HtmEImcyckJ9j2kE'
    '8GQTipzJyAn1PaYJxZNNKHImIyfU97D9BPoes59Y38PmHuh7zNxjfY+5ad6TTShyplROcBNKjknl'
    'e2QTipzJyAn1PaYRwJNNKHImIyfU9zJMKt8jm1DkTEZOqO9h+wn0PWY/sb6HzT3Q95i5x/oec9O8'
    'J5tQ5EypnOAmlByTyvfIJhQ5k5ET6ntMI4Anm1DkTEZOqO8xTSiebEKRMxk5ob6H7SfQ95j9xPoe'
    'NvdA32PmHut7zE3znmxCkTOlcoKbUHJMKt8jm1DkTEZOqO8xjQCebEKRMxk5ob7HNKF4sglFzmTk'
    'hPoetp9A32P2E+t72NwDfY+Ze6zvMTfNe7IJRc6UygluQskxqXyPbEKRMxk5ob7HNAJ4sglFzmTk'
    'hPoe04TiySYUOZORE+p72H4CfY/ZT6zvYXMP9D1m7rG+x9w078kmFDlTKie4CSXHpPI9sglFzmTk'
    'hPoe0wjgySYUOZORE+p7TBOKJ5tQ5ExGTqjvYfsJ9D1mP7G+h8090PeYucf6HnPTvCebUORMqZzg'
    'JpQck8r3yCYUOZORE+p7TCOAJ5tQ5ExGTqjvMU0onmxCkTMZOaG+h+0n0PeY/cT6Hjb3QN9j5h7r'
    'e8xN855sQpEzpXKCm1ByTCrfI5tQ5ExGTqjvMY0AnmxCkTMZOaG+xzSheLIJRc5k5IT6HrafQN9j'
    '9hPre9jcA32PmXuo7wXmpvlANqHImRI55YG0cy/HJPK9QDahyJmMnEjfyzGJ5l4gm1DkTEZOpO/l'
    'mES+F8gmFDmTkRPpe9x+4nwP2k+o73Fzj/M9aO6xvsfcXx7Ifg05UyonuF8jx6TyPbJfQ85k5IT6'
    'HnPPfCD7NeRMRk6o7zH9GoHs15AzGTmhvoftJ9D3mP3E+h4290DfY+Ye63vM/eWB7NeQM6Vygvs1'
    'ckwq3yP7NeRMRk6o7zH3zAeyX0POZOSE+h7TrxHIfg05k5ET6nvYfgJ9j9lPrO9hcw/0PWbusb7H'
    '3F8eyH4NOVMqJ7hfI8ek8j2yX0POZOSE+h5zz3wg+zXkTEZOqO9lmFS+R/ZryJmMnFDfw/YT6HvM'
    'fmJ9D5t7oO8xc4/1Peb+8kD2a8iZUjnB/Ro5JpXvkf0aciYjJ9T3mHvmA9mvIWcyckJ9j+nXCGS/'
    'hpzJyAn1PWw/gb7H7CfW97C5B/oeM/dY32PuLw9kv4acKZUT3K+RY1L5HtmvIWcyckJ9j7lnPpD9'
    'GnImIyfU95h+jUD2a8iZjJxQ38P2E+h7zH5ifQ+be6DvMXOP9T3m/vJA9mvImVI5wf0aOSaV75H9'
    'GnImIyfU95h75gPZryFnMnJCfY/p1whkv4acycgJ9T1sP4G+x+wn1vewuQf6HjP3WN9j7i8PZL+G'
    'nCmVE9yvkWNS+R7ZryFnMnJCfY+5Zz6Q/RpyJiMn1PeYfo1A9mvImYycUN/D9hPoe8x+Yn0Pm3ug'
    '7zFzj/U95v7yQPZryJlSOcH9Gjkmle+R/RpyJiMn1PeYe+YD2a8hZzJyQn2P6dcIZL+GnMnICfU9'
    'bD+BvsfsJ9b3sLkH+h4z91jfY+4vD2S/hpwplRPcr5FjUvke2a8hZzJyQn2PuWc+kP0aciYjJ9T3'
    'mH6NQPZryJmMnFDfw/YT6HvMfmJ9D5t7oO8xcw/1vZK5v7wk+zXkTImc8kDauZdjEvleSfZryJmM'
    'nEjfyzGJ5l5J9mvImYycSN/LMYl8ryT7NeRMRk6k73H7ifM9aD+hvsfNPc73oLnH+h5zf3lJ9mvI'
    'mVI5wf0aOSaV75H9GnImIyfU95h75kuyX0POZOSE+h7Tr1GS/RpyJiMn1Pew/QT6HrOfWN/D5h7o'
    'e8zck/meBKqSBdUfFML3eaDSSWWIxGbO3DRfkk0ocqZUTnATSo5JZeZkE4qcycgJNXOmEaAkm1Dk'
    'TEZOqJkzTSgl2YQiZzJyQs0c20+gmTP7iTVzbO6BZs7MPfa/xDI3zZdkE4qcKZUT3ISSY1L5HtmE'
    'ImcyckJ9j2kEKMkmFDmTkRPqexkmle+RTShyJiMn1Pew/QT6HrOfWN/D5h7oe8zcY32PuWm+JJtQ'
    '5EypnOAmlByTyvfIJhQ5k5ET6ntMI0BJNqHImYycUN9jmlBKsglFzmTkhPoetp9A32P2E+t72NwD'
    'fY+Ze6zvMTfNl2QTipwplRPchJJjUvke2YQiZzJyQn2PaQQoySYUOZORE+p7TBNKSTahyJmMnFDf'
    'w/YT6HvMfmJ9D5t7oO8xc4/1Peam+ZJsQpEzpXKCm1ByTCrfI5tQ5ExGTqjvMY0AJdmEImcyckJ9'
    'j2lCKckmFDmTkRPqe9h+An2P2U+s72FzD/Q9Zu6xvsfcNF+STShyplROcBNKjknle2QTipzJyAn1'
    'PaYRoCSbUORMRk6o7zFNKCXZhCJnMnJCfQ/bT6DvMfuJ9T1s7oG+x8w91veYm+ZLsglFzpTKCW5C'
    'yTGpfI9sQpEzGTmhvsc0ApRkE4qcycgJ9T2mCaUkm1DkTEZOqO9h+wn0PWY/sb6HzT3Q95i5x/oe'
    'c9N8STahyJlSOcFNKDkmle+RTShyJiMn1PeYRoCSbEKRMxk5ob7HNKGUZBOKnMnICfU9bD+Bvsfs'
    'J9b3sLkH+h4z91Dfq5ib5iuyCUXOlMgpD6Sdezkmke9VZBOKnMnIifS9HJNo7lVkE4qcyciJ9L0c'
    'k8j3KrIJRc5k5ET6HrefON+D9hPqe9zc43wPmnus7zE3zVdkE4qcKZUT3ISSY1L5HtmEImcyckJ9'
    'j2kEqMgmFDmTkRPqe0wTSkU2ociZjJxQ38P2E+h7zH5ifQ+be6DvMXOP9T3m/vKK7NeQM6Vygvs1'
    'ckwq3yP7NeRMRk6o7zH3zFdkv4acycgJ9T2mX6Mi+zXkTEZOqO9h+wn0PWY/sb6HzT3Q95i5x/oe'
    'c395RfZryJlSOcH9Gjkmle+R/RpyJiMn1PeYe+Yrsl9DzmTkhPpehknle2S/hpzJyAn1PWw/gb7H'
    '7CfW97C5B/oeM/c+Av3zxeShfbd+OD7Mu037uO9W83237Ler4fRl8Kczfnj/rvvh2O0PwztcMR3O'
    '9bDejm8ffhbd7m27+fSJwzv7t93usH7o5ncD4Xx9eus/PkK60//T+sMDHz8o3WQ40eOuXx2XpyDm'
    'P+7Wh2745OEcu27/2G/33Xyzflgf5ov34zuGI57+d3r38XT6H9z8f9eP8/1966vp8PNoF9Opqxfl'
    'oli1zWq1Crd+6qtyVgc/c3VVlqtZuepmy1tfrqaz23Ixawq3XDRF7brbul4Nh9sv77vVcdN9+qJN'
    'E6bTVVc0i2YWpsu6Cl2zWHTTqp1NZ8Nby65dBhemxWrpV65adMW0aUPTOb+qKxeWz1/0oZ0PP6b9'
    'wDn+zIa8TpFP6vqqe9cuD1f9Yj/8ZLvV1e16eEruX66O3dXp57n/7dVqveuGj3hY7/fr7d3VX9z1'
    'X8qXX7mXX/mrdru6+ubN1Y/r7ar/cfjQfttd7YfPul4eD/3t7dXjpn3f7a6+eH5iXA1PrdPT8Gq/'
    'HfK/7w+/vdof2rvTV+23m/eno3bt6blyM/GFn1772cc3zQ/jc3TybXd33LS7q9dPHzi8+9AejkM4'
    'k2W/2XRPSZ6ePsOhH7rtYb7tD/PH42KzXrbj+9rHIfLhKTR86ulJ0x8Pn55Mofj5/wDcwMJK'
)))
EMBEDDED_SHA256 = '4a30c59cc6753fb060359b09d12b9b24c49e65851fb880d57e7154079959f1e0'
MAX_BODY = 2_000_000
MAX_EXPANDED = 100_000_000
MAX_ZIP = 20_000_000
MAX_JOBS = 1200
ENDPOINTS = {
    "boxscoretraditionalv3",
    "boxscoreadvancedv3",
    "leaguedashplayerstats",
    "leaguedashteamstats",
}


def _json(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def _sha(raw):
    return hashlib.sha256(raw).hexdigest()


def validate_request(request):
    if (
        request.get("status") != "collection_requirement_not_publication_approval"
        or request.get("season") != "2026-27"
        or request.get("season_type") != "Regular Season"
        or not request.get("base_generation")
        or not re.fullmatch(r"[a-f0-9]{64}", request.get("base_manifest_sha256", ""))
        or len(_json(request)) > 250_000
    ):
        raise ValueError("Invalid fixed collection requirement")
    jobs = request["jobs"]
    if (
        not 1 <= len(jobs) <= MAX_JOBS
        or request["maximum_requests"] != len(jobs)
        or request["attempts_per_job"] != 1
        or request["timeout_seconds"] != 30
        or request["response_limit_bytes"] != MAX_BODY
        or request["minimum_interval_seconds"] < 1
        or not 1 <= request["maximum_elapsed_seconds"] <= 43_200
    ):
        raise ValueError("Collection bounds differ from reviewed finite protocol")
    names = set()
    requests_seen = set()
    for job in jobs:
        name = job["source_file"]
        if (
            job["endpoint"] not in ENDPOINTS
            or not re.fullmatch(r"sources/[a-zA-Z0-9_-]+\.json", name)
            or name in names
            or not isinstance(job["parameters"], dict)
        ):
            raise ValueError("Invalid/duplicate fixed source job")
        names.add(name)
        params = job["parameters"]
        identity = (job["endpoint"], _json(params))
        if identity in requests_seen:
            raise ValueError("Duplicate source request")
        requests_seen.add(identity)
        if job["endpoint"].startswith("boxscore"):
            if (
                set(params)
                != {"GameID", "StartPeriod", "EndPeriod", "RangeType", "StartRange", "EndRange"}
                or not re.fullmatch(r"00226\d{5}", params["GameID"])
                or type(params["StartPeriod"]) is not int
                or type(params["EndPeriod"]) is not int
                or (params["StartPeriod"], params["EndPeriod"])
                not in {(1, 1), (2, 2), (3, 3), (4, 4), (1, 2), (3, 4), (5, 14)}
                or params["RangeType"] != 1
                or params["StartRange"] != 0
                or params["EndRange"] != 28800
            ):
                raise ValueError("Invalid fixed box-score window")
        elif (
            params.get("Season") != "2026-27"
            or params.get("SeasonType") != "Regular Season"
            or params.get("MeasureType") != "Advanced"
            or params.get("PerMode") != "PerGame"
            or not re.fullmatch(r"\d{2}/\d{2}/2026", params.get("DateTo", ""))
        ):
            raise ValueError("Advanced snapshot must retain its explicit cutoff/basis")
    return _sha(_json(request))


def _client(job):
    from nba_api.stats.endpoints import (
        BoxScoreAdvancedV3,
        BoxScoreTraditionalV3,
        LeagueDashPlayerStats,
        LeagueDashTeamStats,
    )
    from nba_api.stats.library.http import NBAStatsHTTP

    name, params = job["endpoint"], job["parameters"]
    if name.startswith("boxscore"):
        cls = BoxScoreTraditionalV3 if name == "boxscoretraditionalv3" else BoxScoreAdvancedV3
        endpoint = cls(
            game_id=params["GameID"],
            start_period=params["StartPeriod"],
            end_period=params["EndPeriod"],
            range_type=1,
            start_range=0,
            end_range=28800,
            get_request=False,
        )
    else:
        cls = LeagueDashPlayerStats if name == "leaguedashplayerstats" else LeagueDashTeamStats
        endpoint = cls(
            season="2026-27",
            season_type_all_star="Regular Season",
            measure_type_detailed_defense="Advanced",
            per_mode_detailed="PerGame",
            date_from_nullable=params.get("DateFrom", ""),
            date_to_nullable=params["DateTo"],
            get_request=False,
        )
    actual_parameters = endpoint.parameters.copy()
    planned_parameters = params.copy()
    # v1.12 adds only this optional default None to the player endpoint.
    # Requests omits None-valued query items; no statistical filter changes.
    if name == "leaguedashplayerstats":
        for parameters in [actual_parameters, planned_parameters]:
            if "ISTRound" in parameters:
                if parameters["ISTRound"] is not None:
                    raise ValueError("Unexpected tournament-round filter")
                parameters.pop("ISTRound")
    if endpoint.endpoint != name or actual_parameters != planned_parameters:
        raise ValueError("Installed SDK parameters differ from the fixed reviewed request")
    http = NBAStatsHTTP()
    url = http.base_url.format(endpoint=name)
    if url != f"https://stats.nba.com/stats/{name}":
        raise ValueError("Unexpected source transport host")
    return http, url


def _checkpoint(output, report):
    metadata = json.dumps(report, indent=2) + "\n"
    for name in ["acquisition.json", "sources/capture-attempt.json"]:
        temporary = output / "checkpoint.tmp"
        temporary.write_text(metadata)
        temporary.replace(output / name)


def _bundle(output, request, report):
    """Existing collection_bundle protocol; originals remain untouched on disk."""
    _checkpoint(output, report)
    paths = [output / "acquisition.json", *(output / "sources").glob("*.json")]
    files = {}
    total = 0
    for path in sorted(paths):
        if path.is_symlink():
            raise ValueError("Symlink not allowed")
        raw = path.read_bytes()
        total += len(raw)
        files[path.relative_to(output).as_posix()] = {"bytes": len(raw), "sha256": _sha(raw)}
    if len(files) > 2000 or total > MAX_EXPANDED:
        raise ValueError("Collection exceeds expanded data-only bound; loose originals preserved")
    manifest = dict(
        schema_version=1,
        classification="unvalidated_development_collection",
        request=request,
        request_sha256=_sha(_json(request)),
        files=files,
        production_writes=0,
    )
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for name in files:
            archive.write(output / name, name)
        archive.writestr("collection-manifest.json", json.dumps(manifest, indent=2) + "\n")
    payload = buffer.getvalue()
    if len(payload) > MAX_ZIP:
        raise ValueError("Collection exceeds ZIP bound; loose originals preserved")
    temporary = output / "collection.tmp"
    temporary.write_bytes(payload)
    temporary.replace(output / "collection.zip")


def _resume(output, request, request_sha):
    path = output / "acquisition.json"
    if not path.exists():
        output.mkdir(parents=True, exist_ok=False)
        (output / "sources").mkdir()
        return dict(
            classification="unvalidated_laptop_source_capture_not_publication",
            source="NBA Stats",
            captured_at=datetime.now(UTC).isoformat(),
            parameters="exact fixed per-job parameters in request and attempts",
            request=request,
            request_sha256=request_sha,
            nba_api_version=None,
            attempts=[],
            production_writes=0,
            canonical_period_accepted=False,
        )
    if output.is_symlink() or path.is_symlink() or (output / "sources").is_symlink():
        raise ValueError("Symlink not allowed")
    report = json.loads(path.read_bytes())
    if report["request"] != request or report["request_sha256"] != request_sha:
        raise ValueError("Existing output belongs to a different fixed package")
    attempts = report["attempts"]
    if len(attempts) > len(request["jobs"]):
        raise ValueError("Unexpected prior attempts")
    expected_names = {"capture-attempt.json"}
    for attempt, job in zip(attempts, request["jobs"], strict=False):
        if attempt["job"] != job:
            raise ValueError("Prior attempted request differs")
        if attempt.get("source_file"):
            if attempt["source_file"] != job["source_file"]:
                raise ValueError("Prior source path differs")
            source = output / attempt["source_file"]
            expected_names.add(source.name)
            if source.is_symlink():
                raise ValueError("Symlink not allowed")
            raw = source.read_bytes()
            if len(raw) != attempt["response_bytes"] or _sha(raw) != attempt["response_sha256"]:
                raise ValueError("Prior source bytes changed; no requests made")
    if {p.name for p in (output / "sources").iterdir()} != expected_names:
        raise ValueError("Unexpected source file; no requests made")
    return report


def collect(output: Path, request: dict):
    request_sha = validate_request(request)
    report = _resume(output, request, request_sha)
    attempts = report["attempts"]
    # A failure is never an implicit retry or permission to continue a batch.
    if any(not row.get("transport_complete", False) for row in attempts):
        report["stop_reason"] = "failure_return_output_do_not_retry"
        report["unattempted_jobs"] = request["jobs"][len(attempts) :]
        _bundle(output, request, report)
        return report
    started = time.monotonic()
    compressed_bytes = expanded_bytes = 0
    for row in attempts:
        if row.get("source_file"):
            raw = (output / row["source_file"]).read_bytes()
            compressed_bytes += len(zlib.compress(raw))
            expanded_bytes += len(raw)
    try:
        report["nba_api_version"] = version("nba_api")
        for job in request["jobs"][len(attempts) :]:
            # Reserve 2MB for next original and 4MB for bounded plan/diagnostics.
            if expanded_bytes > 94_000_000 or compressed_bytes > 14_000_000:
                report["stop_reason"] = "collection_size_limit"
                break
            if time.monotonic() - started + 31 > request["maximum_elapsed_seconds"]:
                report["stop_reason"] = "elapsed_limit"
                break
            if attempts:
                time.sleep(request["minimum_interval_seconds"])
            http, url = _client(job)
            attempt = dict(
                job=job,
                endpoint=job["endpoint"],
                url=url,
                parameters=job["parameters"],
                started_at=datetime.now(UTC).isoformat(),
                attempts=1,
                timeout_seconds=30,
                http_status=None,
                response_complete=False,
                transport_complete=False,
            )
            attempts.append(attempt)
            # Record intent before transport; interruption never causes a retry.
            _checkpoint(output, report)
            raw = bytearray()
            try:
                with http.get_session().get(
                    url=url,
                    params=sorted(job["parameters"].items()),
                    headers=http.headers,
                    timeout=30,
                    stream=True,
                    allow_redirects=False,
                ) as response:
                    attempt["http_status"] = response.status_code
                    for chunk in response.iter_content(65536):
                        remaining = MAX_BODY - len(raw)
                        raw.extend(chunk[:remaining])
                        if len(chunk) > remaining:
                            attempt["response_truncated"] = True
                            raise ValueError("Response exceeds2MB retained bound")
                        if time.monotonic() - started > request["maximum_elapsed_seconds"]:
                            raise TimeoutError("Fixed collection elapsed limit reached")
                    attempt["response_complete"] = True
                    response.raise_for_status()
                    if response.status_code != 200:
                        raise ValueError("Source transport did not return HTTP200")
                document = json.loads(raw)
                if not isinstance(document, dict):
                    raise ValueError("Expected JSON source object")
                attempt["transport_complete"] = True
            except BaseException as exc:
                attempt["error_type"] = type(exc).__name__
                raise
            finally:
                if raw:
                    destination = output / job["source_file"]
                    with destination.open("xb") as handle:
                        handle.write(raw)
                attempt.update(
                    finished_at=datetime.now(UTC).isoformat(),
                    response_bytes=len(raw),
                    response_sha256=_sha(raw),
                    source_file=job["source_file"] if raw else None,
                )
                compressed_bytes += len(zlib.compress(raw))
                expanded_bytes += len(raw)
                _checkpoint(output, report)
            print(
                f"Captured {len(attempts)}/{len(request['jobs'])}; originals retained.", flush=True
            )
    except BaseException as exc:
        report["error_type"] = type(exc).__name__
        report["stop_reason"] = "failure_return_output_do_not_retry"
    finally:
        report.update(
            finished_at=datetime.now(UTC).isoformat(),
            unattempted_jobs=request["jobs"][len(attempts) :],
            transport_finished=len(attempts) == len(request["jobs"])
            and all(row.get("transport_complete", False) for row in attempts),
        )
        _bundle(output, request, report)
    return report


def _package_source(request):
    request_sha = validate_request(request)
    source = Path(__file__).read_text()
    encoded = base64.b64encode(zlib.compress(_json(request))).decode()
    chunks = "\n".join(f"    {encoded[i : i + 76]!r}" for i in range(0, len(encoded), 76))
    replacement = (
        "EMBEDDED_REQUEST = json.loads(zlib.decompress(base64.b64decode(\n" + chunks + "\n)))"
    )
    source = source.replace("EMBEDDED_REQUEST = None", replacement, 1)
    source = source.replace("EMBEDDED_SHA256 = None", f"EMBEDDED_SHA256 = {request_sha!r}", 1)
    return source, {"request_sha256": request_sha, "package_sha256": _sha(source.encode())}


def build_package(request: dict, destination: Path):
    """Cloud-only builder; generated file has no repository imports or inputs."""
    source, binding = _package_source(request)
    with Path(destination).open("x") as handle:
        handle.write(source)
    return binding


def build_owner_bundle(request: dict, destination: Path):
    """One ZIP containing executable and existing-Python desktop launchers."""
    source, binding = _package_source(request)
    mac = """#!/bin/sh
cd -- "$(dirname -- "$0")" || exit 1
found=0
for runtime in python3 python; do
    if "$runtime" -c 'import nba_api' >/dev/null 2>&1; then
        "$runtime" run_capture.py
        found=1
        break
    fi
done
if [ "$found" -eq 0 ]; then
    python3 run_capture.py
fi
printf '\nReturn readiness-capture/collection.zip, including after a failure.\n'
printf 'Press Return to close.'
read -r ignored
"""
    windows = r"""@echo off
cd /d "%~dp0"
for %%P in (python python3) do (
    %%P -c "import nba_api" >nul 2>&1
    if not errorlevel 1 (
        %%P run_capture.py
        goto done
    )
)
py -3 -c "import nba_api" >nul 2>&1
if not errorlevel 1 (
    py -3 run_capture.py
    goto done
)
python run_capture.py
:done
echo.
echo Return readiness-capture\collection.zip, including after a failure.
pause
"""
    instructions = (
        "Unzip this package in a new folder. Open Run Capture.command on Mac "
        "or Run Capture.bat on Windows. Keep this folder open until it finishes.\n"
        "The launcher uses Python and nba_api already installed. It installs nothing.\n"
        f"Scope: {len(request['jobs'])} fixed requests; one attempt per request; "
        f"30-second timeout, {request['minimum_interval_seconds']}s minimum spacing, "
        f"finite {request['maximum_elapsed_seconds']}s ceiling.\n"
        "Return readiness-capture/collection.zip through the existing handoff, "
        "even if capture stops or fails. Keep the whole output folder until Codex "
        "confirms receipt. Do not delete it or restart to troubleshoot a failure.\n"
        "Every captured original and the exact request are preserved. "
        "The collection makes no production change and accepts no dataset.\n"
    )
    with Path(destination).open("xb") as output:
        with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("run_capture.py", source)
            command = zipfile.ZipInfo("Run Capture.command")
            command.create_system = 3
            command.external_attr = 0o100755 << 16
            archive.writestr(command, mac)
            archive.writestr("Run Capture.bat", windows.replace("\n", "\r\n"))
            archive.writestr("READ ME.txt", instructions)
    binding["owner_bundle_sha256"] = _sha(Path(destination).read_bytes())
    return binding


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=Path(__file__).resolve().with_name("readiness-capture")
    )
    args = parser.parse_args()
    if EMBEDDED_REQUEST is None or validate_request(EMBEDDED_REQUEST) != EMBEDDED_SHA256:
        parser.error("Run the cloud-prepared standalone package; no request is embedded here")
    try:
        report = collect(args.output, EMBEDDED_REQUEST)
    except Exception as exc:
        print(f"Stopped safely ({type(exc).__name__}); preserve the output directory for Codex.")
        return 1
    print(
        f"Return {args.output / 'collection.zip'} to Codex, including after failure. "
        "No data published."
    )
    return 0 if report.get("transport_finished") else 1


if __name__ == "__main__":
    raise SystemExit(main())
