"""Separate checker derivation: no author rate functions, no reported denominators."""
import csv
import io
import json
import re
import zipfile
from collections import Counter
from fractions import Fraction
from pathlib import Path

from tools.qualify_period_counts import retained_sources, count_events
from tools.stage_current_season import CURRENT, SUFFIX, _whole_original
from tools.period_event_evidence import clock_facts, period_facts

BASE = CURRENT.parent / 'count-credit-20261104'

def whole(gid):
    if gid in {'0022600138','0022600142'}:
        with zipfile.ZipFile(CURRENT.parent / 'stats-sources.zip') as z:
            return z.read(f'representative-sources/traditional_{gid}.json')
    return _whole_original(gid)

def inspect():
    with zipfile.ZipFile(BASE/'qualification-evidence.zip') as z:
        report=json.loads(z.read('qualification.json'))
        rows=list(csv.DictReader(io.StringIO(z.read(f'stage/data/raw/player_game_period_stats/{SUFFIX}').decode())))
    sources=retained_sources()
    derived=[]; failures={}
    for gid in sorted({str(rows[x['row']]['game_id']).zfill(10) for x in report['explicit_rate_invalidations']}):
        raw=sources[gid]; wr=whole(gid)
        counts, _, facts=count_events(raw,wr)
        trace=[]
        try:
            if facts.get('strict_score_validation') is False: raise ValueError('Strict score qualification failed')
            facts=period_facts(raw,game_id=gid,final_teams={json.loads(wr)['boxScoreTraditional'][side]['teamId']:json.loads(wr)['boxScoreTraditional'][side]['statistics']['points'] for side in ['homeTeam','awayTeam']},score_snapshots=facts.get('score_metadata_evidence'))
            clocks=clock_facts(raw,wr,period_report=facts,trace=trace)
        except (ValueError, KeyError) as e:
            failures[gid]=str(e); continue
        lineups={x['action_id']:x['lineups'] for x in trace}
        ast_den=Counter(); reb_den=Counter(); trips=Counter()
        acts=json.loads(raw)['game']['actions']
        for a in acts:
            q,tid,pid=a['period'],a['teamId'],a['personId']
            if a['actionType']=='Made Shot':
                for p in lineups[a['actionId']][tid]:
                    ast_den[q,tid,p]+=p!=pid
            if a['actionType']=='Rebound':
                # Nonterminal misses are deadball bookkeeping, not chances.
                prior=acts[a['actionId']-2] if a['actionId']>1 else None
                m=re.fullmatch(r'Free Throw ([123]) of ([123])',prior['subType']) if prior else None
                if prior and prior['actionType']=='Free Throw':
                    fouls=[x for x in acts[:a['actionId']-1] if x['period']==q and x['clock']==a['clock'] and x['actionType']=='Foul']
                    technical=prior['subType']=='Free Throw Technical' or (m and m[1]==m[2]=='1' and len(fouls)==1 and fouls[0]['subType']=='Defense 3 Second')
                    if technical or (m and m[1]!=m[2]): continue
                if a['teamId']==0 and a['clock']=='PT00M00.00S': continue
                for t,ps in lineups[a['actionId']].items():
                    for p in ps: reb_den[q,t,p]+=1
            if a['actionType']=='Free Throw':
                m=re.fullmatch(r'Free Throw ([123]) of ([123])',a['subType'])
                if m and m[1]=='1' and m[2]!='1': trips[q,tid,pid]+=1
        for inv in report['explicit_rate_invalidations']:
            r=rows[inv['row']]
            if str(r['game_id']).zfill(10)!=gid: continue
            tid,pid=int(r['team_id']),int(r['player_id'])
            qs=range(int(r['source_start_period']),int(r['source_end_period'])+1)
            total=lambda f:sum(counts[q,tid,pid,f] for q in qs)
            f=inv['field']
            if f=='ast_pct': n=total('ast');d=sum(ast_den[q,tid,pid] for q in qs)
            elif f=='reb_pct': n=total('reb');d=sum(reb_den[q,tid,pid] for q in qs)
            elif f=='tov_pct': n=total('tov');d=total('fga')+total('tov')+total('ast')+sum(trips[q,tid,pid] for q in qs)
            else: continue
            derived.append(dict(row=inv['row'],field=f,numerator=n,denominator=d,exact=str(Fraction(n,d) if d else Fraction(0)),old=inv['before'],game_id=gid,player_id=pid))
    result=dict(derived=derived,failures=failures)
    Path('work/rate-checker/simple-oracle.json').write_text(json.dumps(result,indent=2)+'\n')
    print(Counter(x['field'] for x in derived));print(failures)
    print('old-rate differences (secondary diagnostics)',Counter(x['field'] for x in derived if abs(float(Fraction(x['exact']))-x['old'])>(.05 if x['field']=='tov_pct' else .0005)))
    return result

if __name__=='__main__': inspect()
