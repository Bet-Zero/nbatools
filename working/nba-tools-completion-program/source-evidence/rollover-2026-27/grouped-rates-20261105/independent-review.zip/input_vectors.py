"""Independent complete rate-input full-game comparisons against retained whole source."""
import json
import zipfile
from pathlib import Path
from tools.qualify_period_counts import CURRENT,retained_sources,count_events,FIELDS_BY_COLUMN
from .oracle import whole

def verify():
    with zipfile.ZipFile(CURRENT.parent/'count-credit-20261104/qualification-evidence.zip') as z:
        prior=json.loads(z.read('qualification.json'))
    sources=retained_sources();fields=['ast','fgm','fga','fta','tov','reb'];evidence=[]
    for gid in sorted({r['game_id'] for r in prior['count_changes']}):
        wr=whole(gid);counts,_,_=count_events(sources[gid],wr);doc=json.loads(wr)['boxScoreTraditional']
        for side in ['homeTeam','awayTeam']:
            team=doc[side]
            for p in team['players']:
                for field in fields:
                    event=sum(v for (q,tid,pid,f),v in counts.items() if (tid,pid,f)==(team['teamId'],p['personId'],field))
                    direct=p['statistics'][FIELDS_BY_COLUMN[field]]
                    assert event==direct
                    evidence.append(dict(game_id=gid,team_id=team['teamId'],player_id=p['personId'],field=field,event=event,independent_whole=direct))
    assert len(evidence)==3510
    Path('work/rate-checker/full-rate-input-vectors.json').write_text(json.dumps(dict(checked=len(evidence),fields=fields,disagreements=[],vectors=evidence),indent=2)+'\n')
    print('Verified3510complete independent whole rate-input comparisons')

if __name__=='__main__':verify()
