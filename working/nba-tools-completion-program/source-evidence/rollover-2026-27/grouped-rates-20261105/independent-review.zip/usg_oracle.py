"""Independent interval-overlap oracle for promoted USG groups; no author functions."""
import json
import re
from collections import Counter, defaultdict
from fractions import Fraction
from pathlib import Path
from tools.period_event_evidence import clock_facts, period_facts, event_clock, _alias
from tools.qualify_period_counts import retained_sources,count_events
from .oracle import whole

FT=re.compile(r'Free Throw ([123]) of ([123])')

def derive(raw, wr, q):
    doc=json.loads(wr)['boxScoreTraditional']; teams={doc[s]['teamId']:doc[s] for s in ['homeTeam','awayTeam']}
    counts,_,cf=count_events(raw,wr)
    facts=period_facts(raw,game_id=doc['gameId'],final_teams={t:x['statistics']['points'] for t,x in teams.items()},score_snapshots=cf.get('score_metadata_evidence'))
    trace=[];clock_facts(raw,wr,period_report=facts,only_periods={q},trace=trace)
    observed={x['action_id']:x['lineups'] for x in trace}
    acts=[a for a in json.loads(raw)['game']['actions'] if a['period']==q]
    duration=720 if q<=4 else 300
    elapsed=lambda r:Fraction(duration)-event_clock(r['clock'])
    names={}
    for tid,team in teams.items():
        names[tid]=defaultdict(set)
        for p in team['players']:
            family=re.sub(r'\s+Jr\.?$','',p['familyName'])
            for fam in {family,p['familyName']}:
                for n in range(len(p['firstName'])+1):
                    name=(p['firstName'][:n]+' '+fam) if n else fam
                    names[tid][_alias(name)].add(p['personId'])
    # Build maximal player on-court intervals using only substitution clocks.
    active={tid:set(ps) for tid,ps in observed[acts[0]['actionId']].items()}
    starts={p:Fraction(0) for ps in active.values() for p in ps}; intervals=defaultdict(list); lineups={}
    for a in acts:
        aid,tid,pid=a['actionId'],a['teamId'],a['personId']
        lineups[aid]={t:set(ps) for t,ps in active.items()}
        if a['actionType']=='Substitution':
            m=re.fullmatch(r'SUB: (.+) FOR (.+)',a['description']); choice=names[tid][_alias(m[1])];assert len(choice)==1
            entering=next(iter(choice));assert pid in active[tid] and entering not in active[tid]
            intervals[pid].append((starts.pop(pid),elapsed(a)))
            active[tid].remove(pid);active[tid].add(entering);starts[entering]=elapsed(a)
        else: assert {t:sorted(ps) for t,ps in active.items()}==observed[aid]
    for p,start in starts.items(): intervals[p].append((start,Fraction(duration)))
    dead=set(); andones=set(); credits={}; trips=Counter(); technical=set()
    for a in acts:
        if a['actionType']!='Free Throw':continue
        aid,tid,pid=a['actionId'],a['teamId'],a['personId'];m=FT.fullmatch(a['subType']);assert m
        fouls=[f for f in acts if f['actionId']<aid and f['clock']==a['clock'] and f['actionType']=='Foul'];assert len(fouls)==1
        f=fouls[0]
        if f['subType']=='Defense 3 Second':
            assert m[1]==m[2]=='1';technical.add(aid);credits[aid]=lineups[f['actionId']][tid]
            if a['description'].startswith('MISS '): dead.add(aid+1)
            continue
        assert f['subType'] in {'Shooting','Personal','Loose Ball'}
        credits[aid]=lineups[f['actionId']][tid]
        group=[x for x in acts if x['actionType']=='Free Throw' and x['clock']==a['clock'] and x['personId']==pid]
        assert [FT.fullmatch(x['subType'])[1] for x in group]==[str(i) for i in range(1,int(m[2])+1)]
        if m[1]=='1':
            if m[2]=='1':
                made=[x for x in acts if x['actionType']=='Made Shot' and x['personId']==pid and x['clock']==a['clock'] and x['actionId']<f['actionId']];assert len(made)==1
                andones.add(made[0]['actionId'])
            else:trips[pid]+=1
        if m[1]!=m[2] and a['description'].startswith('MISS '):dead.add(aid+1)
    # Determine play time ranges independently of player intervals; intersect later.
    first=next(a for a in acts if a['actionType'] in {'Made Shot','Missed Shot','Turnover','Free Throw'})
    owner=first['teamId'] or first['personId'];start=Fraction(0); scoring=set();plays=[]
    def close(a):
        end=elapsed(a)
        exposed={p for p,spans in intervals.items() if any(max(start,s)<min(end,e) for s,e in spans)}
        # Player IDs from opponent intervals must be excluded.
        own={p['personId'] for p in teams[owner]['players']}
        players=(exposed&own)|scoring
        if players:plays.append(dict(team_id=owner,start=str(start),end=str(end),end_action=a['actionId'],players=sorted(players)))
    for a in acts:
        kind,aid,tid=a['actionType'],a['actionId'],a['teamId'] or a['personId']
        if kind in {'Made Shot','Free Throw'} and not a['description'].startswith('MISS ') and (aid not in technical or tid==owner):
            scoring|=credits[aid] if kind=='Free Throw' else lineups[aid][tid]
        m=FT.fullmatch(a['subType']) if kind=='Free Throw' else None
        end=kind in {'Made Shot','Missed Shot','Turnover','Heave'} or bool(m and m[1]==m[2])
        if aid in andones or aid in technical:end=False
        if end:
            assert owner in teams and (tid==owner or kind=='Heave')
            close(a)
            made=kind=='Made Shot' or kind=='Free Throw' and not a['description'].startswith('MISS ')
            owner=next(t for t in teams if t!=owner) if made or kind=='Turnover' else None
            start=elapsed(a);scoring=set()
        elif kind=='Rebound' and aid not in dead:
            assert owner is None
            owner=tid;start=elapsed(a)
        elif kind=='period' and a['subType']=='end' and owner is not None:close(a)
    denominators=Counter(p for x in plays for p in x['players'])
    numerators={p['personId']:counts[q,tid,p['personId'],'fga']+counts[q,tid,p['personId'],'tov']+trips[p['personId']] for tid,t in teams.items() for p in t['players']}
    return dict(numerators=numerators,denominators=denominators,plays=plays)

def verify(path):
    report=json.loads(Path(path).read_text());sources=retained_sources();cache={}; checked=[]
    for c in report['changes']:
        if c['field']!='usg_pct':continue
        gid,pid=c['game_id'],c['player_id']
        n=d=0
        for q in c['periods']:
            key=gid,q
            if key not in cache:cache[key]=derive(sources[gid],whole(gid),q)
            n+=cache[key]['numerators'][pid];d+=cache[key]['denominators'][pid]
        assert c['numerator']==n and c['denominator']==d,(c,n,d)
        assert Fraction(c['exact'])==(Fraction(n,d) if d else Fraction(0))
        checked.append(dict(row=c['row'],numerator=n,denominator=d,exact=c['exact']))
    result=dict(checked=len(checked),cases=checked,periods={str(k):v['plays'] for k,v in cache.items()})
    Path('work/rate-checker/usg-independent.json').write_text(json.dumps(result,indent=2)+'\n')
    print('Independent USG interval overlap verified',len(checked),'observations',len(cache),'periods')

if __name__=='__main__':
    import sys
    verify(sys.argv[1])
