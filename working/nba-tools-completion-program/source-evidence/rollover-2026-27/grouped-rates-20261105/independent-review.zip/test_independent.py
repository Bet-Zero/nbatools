import copy
import csv
import importlib
import io
import json
import zipfile
from fractions import Fraction
from pathlib import Path

import pytest

from tools.qualify_period_counts import CURRENT, retained_sources
from tools.qualify_period_rates import free_throw_facts, play_exposure

ROOT=Path('work/rate-checker')
OUTPUT=Path('work/rates-final')

@pytest.fixture(scope='module')
def candidate(): return json.loads((OUTPUT/'qualification.json').read_text())

def test_complete_disjoint_population(candidate):
    with zipfile.ZipFile(CURRENT.parent/'count-credit-20261104/qualification-evidence.zip') as z:
        prior=json.loads(z.read('qualification.json'))
    key=lambda x:(x['dataset'],x['row'],x['field'])
    expected={key(x) for x in prior['explicit_rate_invalidations']}
    promoted={key(x) for x in candidate['changes']};unknown={key(x) for x in candidate['unknown']}
    assert len(expected)==1365 and not(promoted&unknown) and promoted|unknown==expected
    assert candidate['production_writes']==0 and not candidate['production_ready']

def test_all_other_tokens_and_files_preserved(candidate):
    changes={(x['row']+1,x['field']):x for x in candidate['changes']}
    with zipfile.ZipFile(CURRENT.parent/'count-credit-20261104/qualification-evidence.zip') as z:
        for n in z.namelist():
            if not n.startswith('stage/data/'):continue
            before=z.read(n);after=(OUTPUT/n).read_bytes()
            if '/raw/player_game_period_stats/' not in n:assert before==after;continue
            old=list(csv.reader(io.StringIO(before.decode())));new=list(csv.reader(io.StringIO(after.decode())))
            assert len(old)==len(new)
            for i,(l,r) in enumerate(zip(old,new,strict=True)):
                assert len(l)==len(r)
                for j,(a,b) in enumerate(zip(l,r,strict=True)):
                    assert a==b or (i,old[0][j]) in changes
            for x in candidate['changes']:
                assert Fraction(new[x['row']+1][old[0].index(x['field'])])==Fraction(str(x['after']))
            for x in candidate['unknown']:
                assert new[x['row']+1][old[0].index(x['field'])]==''

def test_every_promoted_simple_rate_independently_agrees(candidate):
    oracle=json.loads((ROOT/'simple-oracle.json').read_text())
    expected={(x['row'],x['field']):Fraction(x['exact']) for x in oracle['derived']}
    extra=json.loads((ROOT/'0138-q4-tov-oracle.json').read_text())['checked_rows']
    checked=0
    for c in candidate['changes']:
        if c['field']=='usg_pct':continue
        if c['row'] in extra and c['field']=='tov_pct':continue
        assert Fraction(c['exact'])==expected[c['row'],c['field']]
        checked+=1
    assert checked>=589

def test_all_promoted_usg_independent_interval_overlap(candidate):
    oracle=importlib.import_module('work.rate-checker.usg_oracle')
    oracle.verify(OUTPUT/'qualification.json')
    result=json.loads((ROOT/'usg-independent.json').read_text())
    assert result['checked']==sum(c['field']=='usg_pct' for c in candidate['changes'])==86

@pytest.mark.parametrize('mutation',['flagrant','unknown_owner','technical_conflict','incomplete_trip'])
def test_hostile_ft_semantics_rejected(mutation):
    acts=[a for a in json.loads(retained_sources()['0022600102'])['game']['actions'] if a['period']==3]
    teams={a['teamId'] for a in acts if a['teamId']>0}
    foul=next(a for a in acts if a['actionId']==281)
    # Find the literal foul linked to firstFT282 rather than assume its index.
    ft=next(a for a in acts if a['actionId']==282)
    foul=next(a for a in acts if a['actionType']=='Foul' and a['clock']==ft['clock'])
    if mutation=='flagrant':foul['subType']='Flagrant1'
    elif mutation=='unknown_owner':foul['teamId']=0
    elif mutation=='technical_conflict':ft['subType']='Free Throw Technical'
    else:acts=[a for a in acts if a['actionId']!=283]
    with pytest.raises(ValueError):free_throw_facts(acts,teams)

def test_team_turnover_first_play_owner_is_literal_team():
    common=dict(period=1,teamId=0,personId=0,subType='',description='')
    acts=[dict(common,actionId=1,clock='PT12M00S',actionType='period',subType='start'),dict(common,actionId=2,clock='PT11M50S',actionType='Turnover',personId=1),dict(common,actionId=3,clock='PT00M00S',actionType='period',subType='end')]
    lineups={i:{1:[11,12,13,14,15],2:[21,22,23,24,25]} for i in [1,2,3]}
    ft=dict(credit={},andones={},dead=set())
    result=play_exposure(acts,{1,2},lineups,ft,{1:{},2:{}})
    assert [x['team_id'] for x in result]==[1,2]

