from pathlib import Path
from fractions import Fraction as F
from collections import Counter,defaultdict
from zipfile import ZipFile
import re,json,hashlib,unicodedata,sys,io
import pandas as pd
sys.path.insert(0,str(Path.cwd()))
from tools.qualify_period_rates import whole_original
root=Path('work/official-evidence-20261105/methods-lane');gid='0022600009'
original=(root/gid/'original-events.json').read_bytes();canonical=(root/gid/'conditional-canonical-events.json').read_bytes();rows=json.loads(canonical)['game']['actions'];old=json.loads(original)['game']['actions']
assert hashlib.sha256(original).hexdigest()=='4a19d25d9894a456a8cff5fb30e49ce402cf4c31a2d78fca2d7fc4241e3d13b6'
whole=json.loads(whole_original(gid))['boxScoreTraditional'];teams={whole[s]['teamId']:whole[s]for s in['awayTeam','homeTeam']}
def norm(s):return re.sub('[^a-z0-9]','',unicodedata.normalize('NFKD',s).encode('ascii','ignore').decode().lower())
def second(s):
 m=re.fullmatch(r'PT(\d+)M(\d+(?:\.\d+)?)S',s);assert m
 return F(m[1])*60+F(m[2])
alias={}
for tid,t in teams.items():
 idx=defaultdict(set)
 for p in t['players']:
  for n in range(len(p['firstName'])+1):idx[norm(p['firstName'][:n]+p['familyName'])].add(p['personId'])
 alias[tid]=idx
source=Path('work/official-evidence-20261105/capture/acquired_data/official-gamebooks-20261105')/gid
clocks={};lineups={};substitutions={}
for q,page in[(1,8),(2,11)]:
 current={}
 for tid,label in[(1610612759,'SPURS Starters:'),(1610612745,'Rockets Starters:')]:
  current[tid]=set()
  for name in next(s for s in(source/f'page-{page:02d}.txt').read_text().splitlines()if s.startswith(label)).split(':',1)[1].split():
   choices=alias[tid][norm(name)];assert len(choices)==1;current[tid]|=choices
  assert len(current[tid])==5
 elapsed=F(0);duration=Counter();observed=[]
 for r in[x for x in rows if x['period']==q]:
  now=720-second(r['clock']);assert now>=elapsed
  for tid,ps in current.items():
   assert len(ps)==5
   for pid in ps:duration[tid,pid]+=now-elapsed
  lineups[r['actionId']]={t:set(ps)for t,ps in current.items()}
  if r['actionType']=='Substitution':
   inc,out=re.fullmatch('SUB: (.+) FOR (.+)',r['description']).groups();tid=r['teamId'];pid=r['personId'];choice=alias[tid][norm(inc)];assert len(choice)==1
   assert pid in current[tid] and pid in alias[tid][norm(out)],r
   incoming=next(iter(choice));assert incoming not in current[tid];current[tid].remove(pid);current[tid].add(incoming)
   observed.append((second(r['clock']),tid,incoming,pid))
  elif r['actionType']in['Made Shot','Missed Shot','Free Throw','Rebound','Turnover']and r['teamId']in teams:
   assert r['personId']in current[r['teamId']],r
  elapsed=now
 assert elapsed==720 and all(sum(s for(t,p),s in duration.items()if t==tid)==3600 for tid in teams)
 clocks[q]=duration;substitutions[q]=observed
 # Literal PDF substitution sequence is separate from author's operation list.
 pdfsubs=[]
 for n in ([8,9]if q==1 else[11,12,13]):
  for line in(source/f'page-{n:02d}.txt').read_text().splitlines():
   m=re.match(r'^\s*(\d+):([0-5]\d(?:\.\d+)?)\s+(.+)$',line)
   if not m:continue
   sub=re.search(r'SUB: (.+?) FOR (.+?)\s*$',m[3])
   if not sub:continue
   found=[]
   for tid in teams:
    a,b=alias[tid][norm(sub[1])],alias[tid][norm(sub[2])]
    if len(a)==len(b)==1:found.append((tid,next(iter(a)),next(iter(b))))
   assert len(found)==1,(sub.groups(),found)
   pdfsubs.append((F(m[1])*60+F(m[2]),*found[0]))
 assert sorted(observed,key=lambda x:(-x[0],x[1]))==sorted(pdfsubs,key=lambda x:(-x[0],x[1])),(q,observed,pdfsubs)
# Independent score snapshots and credited assist/FGM vectors.
score={t:0 for t in teams};counts=Counter()
for r in rows:
 q,tid,pid=r['period'],r['teamId'],r['personId'];kind=r['actionType']
 if kind=='Made Shot':
  score[tid]+=r['shotValue'];counts[q,tid,pid,'fgm']+=1
  m=re.search(r'\(([^()]+) \d+ AST\)',r['description'])
  if m:
   choices=alias[tid][norm(m[1])];assert len(choices)==1;counts[q,tid,next(iter(choices)),'ast']+=1
 if kind=='Free Throw'and not r['description'].startswith('MISS '):score[tid]+=1
 for t,key in[(whole['homeTeam']['teamId'],'scoreHome'),(whole['awayTeam']['teamId'],'scoreAway')]:
  if r[key]not in['',None]:assert int(r[key])==score[t],(r['actionId'],key,r[key],score)
assert all(score[t]==team['statistics']['points']for t,team in teams.items())
# Whole expected count corrections derive from source, not a reported-rate fit.
whole_ast=[]
for tid,team in teams.items():
 for person in team['players']:
  pid=person['personId']
  for field,stat in[('fgm','fieldGoalsMade'),('ast','assists')]:
   value=sum(v for(q,t,p,f),v in counts.items()if(t,p,f)==(tid,pid,field))
   expected=5 if(pid,field)==(201142,'ast')else person['statistics'][stat]
   assert value==expected,(pid,field,value,expected)
  if pid==201142:whole_ast.append({'player_id':pid,'ast':value})
base=Path('working/nba-tools-completion-program/source-evidence/rollover-2026-27/foul-anchor-20261105/qualification-evidence.zip')
with ZipFile(base)as z:
 report=json.loads(z.read('qualification.json'));frame=pd.read_csv(io.BytesIO(z.read('stage/data/raw/player_game_period_stats/2026-27_regular_season.csv')),float_precision='round_trip')
targets=[r for r in report['unknown']if r['game_id']==gid];assert len(targets)==38 and all(r['field']=='ast_pct'for r in targets)
expected=[]
for target in targets:
 row=frame.iloc[target['row']];tid,pid=int(row.team_id),int(row.player_id);qs=target['periods'];n=sum(counts[q,tid,pid,'ast']for q in qs)
 d=sum(pid!=r['personId']and pid in lineups[r['actionId']][tid]for r in rows if r['period']in qs and r['teamId']==tid and r['actionType']=='Made Shot')
 assert 0<=n<=d
 expected.append({'row':target['row'],'periods':qs,'field':'ast_pct','team_id':tid,'player_id':pid,'numerator':n,'denominator':d,'exact':str(F(n,d)if d else F(0))})
nameids={norm(p['firstName']+p['familyName']):(t,p['personId'])for t,team in teams.items()for p in team['players']}
clockchecks=[]
for qs,page in[([1],1),([2],2),([1,2],3)]:
 checked=0
 for line in(source/f'page-{page:02d}.txt').read_text().splitlines():
  m=re.match(r'^\s*\d+\s+(.+?)\s+(?:(?:F|C|G)\s+)?(\d+):(\d\d)\s+((?:-?\d+\s+){15}-?\d+)\s*$',line)
  if not m:continue
  tid,pid=nameids[norm(m[1])];sec=int(m[2])*60+int(m[3]);actual=sum(clocks[q][tid,pid]for q in qs);assert abs(actual-sec)<=1,(page,pid,sec,actual)
  vals=list(map(int,m[4].split()));assert sum(counts[q,tid,pid,'ast']for q in qs)==vals[9] and sum(counts[q,tid,pid,'fgm']for q in qs)==vals[0],(page,pid)
  checked+=1
 clockchecks.append({'page':page,'periods':qs,'count_clock_player_vectors':checked})
Path('/tmp/source_checker_0009-results.json').write_text(json.dumps(expected,indent=2)+'\n')
print(json.dumps({'conditional_AST_expectations':len(expected),'PDF_direct_clock_and_AST_FGM_vectors':clockchecks,'PDF_all_substitution_sequences_exact':True,'canonical_sha256':hashlib.sha256(canonical).hexdigest(),'Durant':[r for r in expected if r['player_id']==201142]},indent=2))
