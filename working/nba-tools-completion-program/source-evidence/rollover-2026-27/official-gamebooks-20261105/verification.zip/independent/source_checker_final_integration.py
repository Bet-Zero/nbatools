from pathlib import Path
import json,csv,io,hashlib
from fractions import Fraction as F
from collections import Counter
from zipfile import ZipFile
import sys
import pandas as pd
sys.path.insert(0,str(Path.cwd()))
work=Path('work/official-evidence-20261105');final=work/'integrated';suffix='2026-27_regular_season.csv'
base=Path('working/nba-tools-completion-program/source-evidence/rollover-2026-27/foul-anchor-20261105/qualification-evidence.zip')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
assert sha((work/'integrate.py').read_bytes())=='e99342c8f26f94cfc19b0db8ff84ed0b2555a00f69b7d465be9246029037edac'
assert sha((final/'qualification.json').read_bytes())=='22f827d6106a0898d804b15d6ad904cb2c3a83714e081272e992196c6ff52162'
report=json.loads((final/'qualification.json').read_text())
with ZipFile(base)as z:
 before={n:z.read(n)for n in z.namelist()if n.startswith('stage/data/')and n.endswith('.csv')};prior=json.loads(z.read('qualification.json'))
assert len(before)==16
# Raw old-token identity is independently compared against the exact reviewed guarded delta.
patchrecord=json.loads((work/'methods-lane/csv-cell-patches.json').read_text());assert sha((work/'methods-lane/csv-cell-patches.json').read_bytes())=='d36645abd6f5e24312ed95fb487ea748053fa559a1e0543c4f8ff5e1050ee0bc'
expectedchanges={(p['path'],p['row']+1,p['field']):(p['before_literal'],p['after_literal'])for p in patchrecord['patches']}
periodpath=f'stage/data/raw/player_game_period_stats/{suffix}'
baseperiod=list(csv.reader(io.StringIO(before[periodpath].decode())))
h=baseperiod[0]
pos={(int(r[h.index('game_id')]),int(r[h.index('team_id')]),int(r[h.index('player_id')]),int(r[h.index('source_start_period')]),int(r[h.index('source_end_period')])):i for i,r in enumerate(baseperiod[1:])}
def locate(c,gid):
 i=pos[int(gid),c['team_id'],c['player_id'],c['periods'][0],c['periods'][-1]]
 if 'row'in c:assert i==c['row']
 return i
for c in json.loads(Path('/tmp/source_checker_0138-results.json').read_text()):
 c['row']=locate(c,22600138)
 r=baseperiod[c['row']+1];j=baseperiod[0].index(c['field']);expectedchanges[periodpath,c['row']+1,c['field']]=(r[j],str(float(F(c['exact']))))
corepath=f'stage/data/raw/player_game_stats/{suffix}';bc=list(csv.reader(io.StringIO(before[corepath].decode())));h=bc[0]
for i,r in enumerate(bc[1:],1):
 if int(r[h.index('game_id')])==22600142:
  pid=int(r[h.index('player_id')])
  if pid in[1631204,1628997]:expectedchanges[corepath,i,'plus_minus']=(r[h.index('plus_minus')],'11'if pid==1631204 else'8')
actualchanges={};checked=0
for name,raw in before.items():
 if '/raw/'not in name:continue
 a=list(csv.reader(io.StringIO(raw.decode())));b=list(csv.reader(io.StringIO((final/name).read_text())));assert a[0]==b[0]
 assert len(b)==len(a)+(48 if name==periodpath else 4 if '/team_game_period_stats/'in name else 0)
 for i,r in enumerate(a):
  assert len(r)==len(b[i])
  for j,x in enumerate(r):
   checked+=1
   if x!=b[i][j]:actualchanges[name,i,a[0][j]]=(x,b[i][j])
assert actualchanges==expectedchanges and len(actualchanges)==240
# Newly appended rows are exact reviewed0142rawsuffixes, including192complete row-rate cells.
for name in[periodpath,f'stage/data/raw/team_game_period_stats/{suffix}']:
 qualified=(work/'0142-qualified'/name).read_bytes();assert qualified.startswith(before[name]);tail=qualified[len(before[name]):]
 assert(final/name).read_bytes().endswith(tail)
frame=pd.read_csv(final/periodpath,float_precision='round_trip')
for p in prior['changes']:assert frame.iloc[p['row']][p['field']]==p['after']
# All280legacygain+newwindowfractions are bound to independent exact arithmetic results.
ratecount=0
for n in['0138','0009','0142']:
 for c in json.loads(Path(f'/tmp/source_checker_{n}-results.json').read_text()):
  if n=='0142':
   row=frame.loc[frame.game_id.eq(22600142)&frame.team_id.eq(c['team_id'])&frame.player_id.eq(c['player_id'])&frame.source_start_period.eq(c['periods'][0])&frame.source_end_period.eq(c['periods'][-1])];assert len(row)==1;v=row.iloc[0][c['field']]
  else:v=frame.iloc[locate(c,22600138 if n=='0138'else 22600009)][c['field']]
  assert v==float(F(c['exact']));ratecount+=1
assert ratecount==318
legacygain={(locate(c,22600138 if n=='0138'else 22600009),c['field'])for n in['0138','0009']for c in json.loads(Path(f'/tmp/source_checker_{n}-results.json').read_text())}
remaining=[c for c in prior['unknown']if(c['row'],c['field'])not in legacygain];assert len(remaining)==412
newunknown=patchrecord['new_unknown_outside_original1365'];assert len(newunknown)==72
keys={(c['row'],c['field'])for c in remaining+newunknown};assert len(keys)==484
for row,field in keys:assert pd.isna(frame.iloc[row][field])
actualreported={(c['row'],c['field'])for c in report['remaining_unknown_keys']};assert keys==actualreported
# Match immutable inventory and16actual required structural records to final files.
for v in report['dataset_inventory']:
 name='stage/'+v['path'];assert sha(before[name])==v['before_sha256']and sha((final/name).read_bytes())==v['after_sha256']
required=[d for d in report['dataset_assessment']['datasets']if d['required']];assert len(required)==16
assert report['dataset_assessment']['validation_state']=='passed'and not report['dataset_assessment']['validation_errors']
for d in required:
 assert d['validation']['state']=='passed'and not d['validation']['errors'];assert sha(Path(d['path']).read_bytes())==d['file_sha256']
assert len(report['builders'])==5 and all(b['state']=='passed'for b in report['builders'])
# Independent scalar history calculation checks every affected derived field without invoking a builder.
featurespath=f'stage/data/processed/player_game_features/{suffix}'
oldfeatures=pd.read_csv(io.BytesIO(before[featurespath]),float_precision='round_trip');features=pd.read_csv(final/featurespath,float_precision='round_trip')
assert len(features)==len(oldfeatures)and list(features.columns)==list(oldfeatures.columns)
for c in features:
 if c not in['minutes_last_5','minutes_last_10','ast_last_5']:assert features[c].equals(oldfeatures[c]),c
core=pd.read_csv(final/corepath,float_precision='round_trip');lookup={(int(r.player_id),int(r.game_id),int(r.team_id)):r for _,r in features.iterrows()};derived=0
for pid,group in core.groupby('player_id'):
 history=[]
 for _,r in group.sort_values(['game_date','game_id']).iterrows():
  f=lookup[int(pid),int(r.game_id),int(r.team_id)]
  for col,field,window in[('minutes_last_5','minutes',5),('minutes_last_10','minutes',10),('ast_last_5','ast',5)]:
   values=[F(str(x[field]))for x in history[-window:]]
   if not values:assert pd.isna(f[col])
   else:assert abs(f[col]-float(sum(values,F(0))/len(values)))<1e-12,(pid,r.game_id,col,f[col],values)
   derived+=1
  history.append(r)
# Actual alternate consumers use canonicaldatasets only, no historical correction knowledge.
from tools.qualify_rollover_q1 import _local_stage
from nbatools.commands.player_game_finder import build_result
controls=[]
with _local_stage((final/'stage').resolve()):
 for player,gid,window,expected in[('Marcus Sasser',22600142,{'half':'second'},{'ast_pct':float(F(2,7)),'tov_pct':float(F(1,6))}),('Oscar Tshiebwe',22600138,{'half':'second'},{'reb_pct':float(F(1,7)),'usg_pct':float(F(1,9))})]:
  ans=build_result(player=player,season='2026-27',**window);assert ans.result_status=='ok';r=ans.games.loc[ans.games.game_id.eq(gid)];assert len(r)==1
  for field,value in expected.items():assert abs(r.iloc[0][field]-value)<1e-12
  controls.append({'player':player,'window':window,'game_id':gid,'expected':expected})
review={'reviewer':'Codex /root/source_checker','verdict':'final_integrated_source_and_numerical_stage_approved_pending_packaging_exactheadCI_and_merge','integrator_sha256':sha((work/'integrate.py').read_bytes()),'qualification_sha256':sha((final/'qualification.json').read_bytes()),'changed_original_raw_tokens':240,'independently_compared_original_raw_tokens':checked,'all811prior_rates_exact':True,'independent_exact_fractions_matched_in_final':318,'legacy_rates_restored':142,'new0142source_listed_rates':176,'original_unknown':412,'new_unknown':72,'total_unknown':484,'accepted_windows':647,'all16required_structural_records_pass':True,'declared_source14_counts_and_PF_plusminus_preserved':True,'0142whole_plusminus_corrections_verified_by150PDF_and_independent_foultimecredits':True,'new_player_rows':48,'new_team_rows':4,'all5normalbuilders_pass':True,'independent_scalar_derived_cells':derived,'independent_alternate_consumers':controls,'portable_architecture':'Standalonesourcecapture; originalPDFandJSONseparatefromcorrectedcanonicalrecords; ordinaryCSVdatasets; unchangedapplicationcalculations and pure normalizers; no per-game runtimeexceptions. Historicreplays are evidence, not routine acquisition.','data_contract_doc_sha256':'60b477fb11a13fcaa3a7484015299d2ed6d6a885ecc039c55609ac7272dbb420','contract_review':'Completeaffectedidentity/count/clock/rate-input checks and independent review remain mandatory. Hosting is explicitly not generation independence. Invalidated rates remain null until full gates pass; no fabricated V3source and no weakenedvalidator.','upstream_source_generation_independence':'unestablished; acceptedfacts are field-scoped officialscorer evidence with separatelyreconstructednumerics, not a secondobserver claim','fullreadiness':False,'production_writes':0,'remaining_gates':'Exactfinalarchive/inventorycustody, finalheadCI/reviewand authorizedsafe merge. Source/statistical blockers remain exact in ledger; historical107gamecutoff is not currentfreshness.'}
Path('/tmp/source_checker_final-review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps(review,indent=2))
