exec(open('/tmp/source_checker_0142.py').read())
source_root=Path('work/official-evidence-20261105/capture/acquired_data/official-gamebooks-20261105/0022600142')
nameids={norm(p['firstName']+p['familyName']):(t,p['personId'])for t,team in teams.items()for p in team['players']}
columns=['fgm','fga','fg3m','fg3a','ftm','fta','oreb','dreb','reb','ast','pf','stl','tov','blk','plus_minus','pts']
teamframe=pd.read_csv(root/'stage/data/raw/team_game_period_stats/2026-27_regular_season.csv',float_precision='round_trip')
summary=[]
for periods,page in [([3],4),([4],6),([3,4],7)]:
 doc=(source_root/f'page-{page:02d}.txt').read_text();rows_checked=0;clock_residuals=[];parsed={};teamtotals={};team=None
 for line in doc.splitlines():
  if line.startswith('VISITOR:'):team=1610612760
  elif line.startswith('HOME:'):team=1610612742
  m=re.match(r'^\s*(\d+\s+.+?\s+)?(?:(?:F|C|G)\s+)?(\d+):(\d\d)\s+((?:-?\d+\s+){15}-?\d+)\s*$',line)
  if not m:continue
  vals=list(map(int,m[4].split()));assert len(vals)==16
  seconds=int(m[2])*60+int(m[3])
  if m[1]is None:teamtotals[team]=dict(zip(columns,vals));assert seconds==3600*len(periods);continue
  prefix=re.sub(r'\s+[FCG]\s*$','',m[1].strip());name=re.sub(r'^\d+\s+','',prefix)
  tid,pid=nameids[norm(name)];assert tid==team
  assert(tid,pid)not in parsed;parsed[tid,pid]=dict(zip(columns,vals))
  actual=sum((clocks[q][tid,pid]for q in periods),F(0));assert abs(actual-seconds)<=1,(page,pid,actual,seconds)
  if actual!=seconds:clock_residuals.append((pid,str(actual-seconds)))
  if periods in [[3],[3,4]]:
   saved=newframe.loc[newframe.game_id.eq(int(gid))&newframe.source_start_period.eq(periods[0])&newframe.source_end_period.eq(periods[-1])&newframe.team_id.eq(tid)&newframe.player_id.eq(pid)];assert len(saved)==1
   for f,v in parsed[tid,pid].items():assert saved.iloc[0][f]==v,(page,pid,f,v,saved.iloc[0][f])
  rows_checked+=1
 for tid in teams:
  positive={p for q in periods for(t,p),s in clocks[q].items()if t==tid and s>0}
  assert positive=={p for(t,p)in parsed if t==tid and any(clocks[q][tid,p]>0 for q in periods)}
  for f in columns:
   value=sum(v[f]for(t,p),v in parsed.items()if t==tid)
   assert value==teamtotals[tid][f]*(5 if f=='plus_minus'else 1),(page,tid,f,value,teamtotals[tid][f])
  if periods in [[3],[3,4]]:
   tf=teamframe.loc[teamframe.game_id.eq(int(gid))&teamframe.source_start_period.eq(periods[0])&teamframe.source_end_period.eq(periods[-1])&teamframe.team_id.eq(tid)];assert len(tf)==1
   for f,v in teamtotals[tid].items():assert tf.iloc[0][f]==v,(page,tid,f,v,tf.iloc[0][f])
 summary.append({'page_index':page,'periods':periods,'player_rows':rows_checked,'clock_residuals':clock_residuals,'all16literalcount_columns_match_appended_rows':periods!=[4]})
print(json.dumps({'source_table_checks':summary},indent=2))
Path('/tmp/source_checker_0142-tables.json').write_text(json.dumps(summary,indent=2)+'\n')
