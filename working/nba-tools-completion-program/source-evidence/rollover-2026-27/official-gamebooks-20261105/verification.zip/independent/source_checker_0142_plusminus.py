exec(open('/tmp/source_checker_0142.py').read())
pdfroot=Path('work/official-evidence-20261105/capture/acquired_data/official-gamebooks-20261105/0022600142')
# Full-game lineup snapshots from each official PBP quarter's explicit starters.
for q,page in[(1,8),(2,10)]:
 current={}
 for tid,label in[(1610612742,'MAVERICKS Starters:'),(1610612760,'Thunder Starters:')]:
  names=next(s for s in(pdfroot/f'page-{page:02d}.txt').read_text().splitlines()if s.startswith(label)).split(':',1)[1].split();current[tid]=set()
  for name in names:
   choices=alias[tid][norm(name)];assert len(choices)==1;current[tid]|=choices
 for r in[x for x in rows if x['period']==q]:
  lineups[r['actionId']]={t:set(ps)for t,ps in current.items()}
  if r['actionType']=='Substitution':
   inc,out=re.fullmatch('SUB: (.+) FOR (.+)',r['description']).groups();tid=r['teamId'];choices=alias[tid][norm(inc)];assert len(choices)==1;current[tid].remove(r['personId']);current[tid].add(next(iter(choices)))
pm=Counter();anchors=[]
for i,r in enumerate(rows):
 if r['actionType']=='Made Shot':value=r['shotValue'];credit=r['actionId']
 elif r['actionType']=='Free Throw'and not r['description'].startswith('MISS '):
  value=1;technical=r['subType']=='Free Throw Technical';match=re.fullmatch('Free Throw ([123]) of ([123])',r['subType']);assert technical or match
  fouls=[a for a in rows[:i]if a['period']==r['period']and a['clock']==r['clock']and a['actionType']=='Foul']
  if technical:fouls=[a for a in fouls if a['subType']in['Technical','Defense 3 Second']]
  else:fouls=[a for a in fouls if a['subType']!='Technical'and not(int(match[2])>1 and a['subType']=='Personal'and 'PN'not in a['description'])]
  assert len(fouls)==1,(r,fouls);credit=fouls[0]['actionId'];anchors.append((r['actionId'],credit))
 else:continue
 for tid,ps in lineups[credit].items():
  for pid in ps:pm[r['period'],tid,pid]+=value*(1 if tid==r['teamId']else-1)
nameids={norm(p['firstName']+p['familyName']):(t,p['personId'])for t,team in teams.items()for p in team['players']}
checked=[];mismatches=[]
for qs,page in[([1],1),([2],2),([1,2],3),([3],4),([4],6),([3,4],7),([1,2,3,4],0)]:
 for line in(pdfroot/f'page-{page:02d}.txt').read_text().splitlines():
  m=re.match(r'^\s*\d+\s+(.+?)\s+(?:(?:F|C|G)\s+)?(\d+):(\d\d)\s+((?:-?\d+\s+){15}-?\d+)\s*$',line)
  if not m:continue
  tid,pid=nameids[norm(m[1])];vals=list(map(int,m[4].split()));expected=vals[-2];actual=sum(pm[q,tid,pid]for q in qs)
  checked.append({'page':page,'periods':qs,'team_id':tid,'player_id':pid,'exact':actual,'pdf_literal':expected})
  if actual!=expected:mismatches.append(checked[-1])
print(json.dumps({'plusminus_vectors_checked':len(checked),'mismatches':mismatches,'sasser':[r for r in checked if r['player_id']==1631204],'martin':[r for r in checked if r['player_id']==1628997]},indent=2))
assert not mismatches
Path('/tmp/source_checker_0142-plusminus-results.json').write_text(json.dumps(checked,indent=2)+'\n')
