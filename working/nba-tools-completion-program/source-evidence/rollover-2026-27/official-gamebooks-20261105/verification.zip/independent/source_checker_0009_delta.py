exec(open('/tmp/source_checker_0009.py').read())
record=json.loads((root/'csv-cell-patches.json').read_text());assert hashlib.sha256((root/'csv-cell-patches.json').read_bytes()).hexdigest()=='d36645abd6f5e24312ed95fb487ea748053fa559a1e0543c4f8ff5e1050ee0bc'
import csv
patches=record['patches'];assert len(patches)==134
with ZipFile(base)as z:originals={n:z.read(n)for n in z.namelist()if n.startswith('stage/data/')and n.endswith('.csv')}
actual=[]
for dataset in['player_game_stats','team_game_stats','player_game_period_stats','team_game_period_stats']:
 name=f'stage/data/raw/{dataset}/2026-27_regular_season.csv';before=list(csv.reader(io.StringIO(originals[name].decode())));after=list(csv.reader(io.StringIO((root/'0009-stage'/name).read_text())))
 assert len(before)==len(after)and before[0]==after[0]
 for i,(a,b)in enumerate(zip(before[1:],after[1:])):
  for j,(x,y)in enumerate(zip(a,b)):
   if x!=y:actual.append((dataset,i,before[0][j],x,y))
expectedpatches={(p['dataset'],p['row'],p['field'],p['before_literal'],p['after_literal'])for p in patches}
assert len(actual)==len(expectedpatches)==134 and set(actual)==expectedpatches
for p in patches:
 source_raw=originals[p['path']];assert hashlib.sha256(source_raw).hexdigest()==p['baseline_sha256']
 table=list(csv.reader(io.StringIO(source_raw.decode())));header=table[0];r=table[p['row']+1]
 assert {k:r[header.index(k)]for k in p['key']}==p['key'] and r[header.index(p['field'])]==p['before_literal']
assert Counter(p['field']for p in patches if p['field']in['ast_pct','tov_pct','usg_pct'])=={'ast_pct':38,'tov_pct':36,'usg_pct':36}
bykey={(v['row'],v['field']):v for v in expected}
for p in patches:
 if p['field']=='ast_pct':
  e=bykey[p['row'],p['field']];assert(p['numerator'],p['denominator'],p['exact_fraction'])==(e['numerator'],e['denominator'],e['exact']);assert float(p['after_literal'])==float(F(e['exact']))
positive=set();zeros=set()
for qs in[[1],[1,2]]:
 selected=frame.loc[frame.game_id.eq(int(gid))&frame.source_start_period.eq(qs[0])&frame.source_end_period.eq(qs[-1])]
 for index,r in selected.iterrows():
  for field in['tov_pct','usg_pct']:
   if r.minutes>0:positive.add((int(index),field))
   else:assert r[field]==0;zeros.add((int(index),field))
invalid={(p['row'],p['field'])for p in patches if p['field']in['tov_pct','usg_pct']};assert invalid==positive and len(invalid)==72 and len(zeros)==4
legacy={(p['row'],p['field'])for p in report['changes']}|{(p['row'],p['field'])for p in report['unknown']};assert not invalid&legacy
for c in report['changes']:assert not(c['row'],c['field'])in{(p['row'],p['field'])for p in patches if p['dataset']=='player_game_period_stats'}
# Independently verify the existing38REB values against the corrected full lineups.
rebcounts=Counter((r['period'],r['teamId'],r['personId'])for r in rows if r['actionType']=='Rebound'and r['teamId']in teams)
rebchances={}
for q in[1,2]:
 acts=[r for r in rows if r['period']==q];dead=set();chance=Counter()
 for i,r in enumerate(acts):
  if r['actionType']=='Free Throw':
   match=re.fullmatch(r'Free Throw ([123]) of ([123])',r['subType']);technical=r['subType']=='Free Throw Technical'
   if match and match[1]==match[2]=='1':technical|=any(a['actionType']=='Foul'and a['subType']=='Defense 3 Second'and a['clock']==r['clock']for a in acts[:i])
   if r['description'].startswith('MISS ')and(technical or match and match[1]!=match[2]):
    nxt=acts[i+1];assert nxt['actionType']=='Rebound'and nxt['teamId']==0 and nxt['personId']==r['teamId'];dead.add(nxt['actionId'])
  if r['actionType']=='Rebound'and r['teamId']==0 and second(r['clock'])==0:dead.add(r['actionId'])
 for r in acts:
  if r['actionType']=='Rebound'and r['actionId']not in dead:
   for ps in lineups[r['actionId']].values():chance.update(ps)
 rebchances[q]=chance
for r in record['reb_rechecks']:
 qs,tid,pid=r['periods'],r['team_id'],r['player_id'];n=sum(rebcounts[q,tid,pid]for q in qs);d=sum(rebchances[q][pid]for q in qs)
 assert(n,d,str(F(n,d)if d else F(0)))==(r['numerator'],r['denominator'],r['exact']);assert abs(float(F(n,d)if d else F(0))-r['preserved_value'])<=0.000501
assert len(record['reb_rechecks'])==38
# Three changed whole-count facts checked against standalone credited event rows.
steals=Counter((r['teamId'],r['personId'])for r in rows if re.fullmatch(r'.+ STEAL \(\d+ STL\)',r['description']))
assert steals[1610612745,1631095]==2 and steals[1610612745,203500]==0
assert not any(r['game_id']==gid for r in report['changes'])
summary={'reviewer':'Codex /root/source_checker','scope':'0009 field-scoped official-scorer corrections,38ASTrestorations and72necessarynewunknowns','verdict':'source_and_numerical_delta_approved_pending_finalintegration','patch_sha256':hashlib.sha256((root/'csv-cell-patches.json').read_bytes()).hexdigest(),'event_sha256':hashlib.sha256(canonical).hexdigest(),'changed_csv_tokens':134,'count_clock_tokens':24,'independent_AST_fractions':38,'complete_PDF_clock_AST_FGM_vectors':55,'independent_existing_REB_rechecks':38,'new_TOV_USG_unknowns':72,'unaffected_zero_duration_cells':4,'newunknowns_outside_original1365':True,'prior811unaffected':True,'whole_team_AST25_to24_supported':True,'source_substitutions_match':'perteamsequence at exactclocks; opposite-team same-clock subordering with no intervening actor credit is equivalent','upstream_source_generation_independence':'unestablished','original_sources_unchanged':True,'oracle_files':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in['/tmp/source_checker_0009.py','/tmp/source_checker_0009-results.json']},'remaining_external_dependency':'EasonFG2:15 vs loneFT1of1at2:06; missing qualified completeawardassociation/credit prevents Q1/H1TOV_USG; no inferred time adjustment','remaining_acceptance':'Final integrated tokenpreservation, normaldependentbuilders, importer/consumer/requiredCI/merge. No fullreadiness or production approval.'}
Path('/tmp/source_checker_0009-review.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
