from pathlib import Path
from fractions import Fraction as F
from collections import Counter,defaultdict
import hashlib,json,re,unicodedata,sys,io
from zipfile import ZipFile
sys.path.insert(0,str(Path.cwd()))
from tools.qualify_period_rates import whole_original
root=Path('work/official-evidence-20261105/methods-lane');gid='0022600138'
source=(root/gid/'original-events.json').read_bytes();canonical=(root/gid/'conditional-canonical-events.json').read_bytes()
assert hashlib.sha256(source).hexdigest()=='cd687bbb69eb2bf273f18a47c33f53a3a66d24952ffd0156d125076d5afd92b7'
old=json.loads(source)['game']['actions'];rows=json.loads(canonical)['game']['actions'];identity=json.loads((root/gid/'identity-map.json').read_text())
assert len(rows)==len(old)==506
changes=[]
for row,ids in zip(rows,identity):
 original=old[ids['source_action_id']-1]
 assert ids['canonical_action_id']==row['actionId'] and ids['source_action_number']==row['actionNumber']==original['actionNumber']
 a={k:v for k,v in row.items() if k!='actionId'};b={k:v for k,v in original.items() if k!='actionId'}
 dif={k:(b[k],a[k]) for k in b if a[k]!=b[k]}
 if dif:changes.append((ids['source_action_id'],dif))
assert changes==[(481,{'clock':('PT03M04.00S','PT03M03.00S')})],changes
assert [i['source_action_id'] for i in identity[479:483]]==[480,482,481,483]
whole=json.loads(whole_original(gid))['boxScoreTraditional'];teams={whole[s]['teamId']:whole[s] for s in ['awayTeam','homeTeam']}
def norm(s):return re.sub('[^a-z0-9]','',unicodedata.normalize('NFKD',s).encode('ascii','ignore').decode().lower())
alias={}
for tid,t in teams.items():
 m=defaultdict(set)
 for p in t['players']:
  family=p['familyName'];first=p['firstName'];pid=p['personId']
  for n in range(len(first)+1):m[norm(first[:n]+family)].add(pid)
  m[norm(first+family)].add(pid)
 alias[tid]=m

def sec(s):
 m=re.fullmatch(r'PT(\d+)M(\d+(?:\.\d+)?)S',s);assert m,s
 return F(m[1])*60+F(m[2])
starters={3:{1610612749:{1626167,1629639,1631157,1628398,1631170},1610612745:{1641708,1627832,201142,1631095,1631106}},4:{1610612749:{1630579,1631172,1631260,1643415,1643417},1610612745:{1641708,201142,1631131,1642263,1631106}}}
clocks={};lineups={};intervals={};rebch={};plays={};tripcount={};counts=Counter()
for row in rows:
 kind=row['actionType'];pid=row['personId'];tid=row['teamId'];q=row['period']
 if tid in teams and any(p['personId']==pid for p in teams[tid]['players']):
  if kind=='Rebound':counts[q,tid,pid,'reb']+=1
  if kind in ['Made Shot','Missed Shot']:counts[q,tid,pid,'fga']+=1
  if kind=='Free Throw':counts[q,tid,pid,'fta']+=1
  if kind=='Turnover':counts[q,tid,pid,'tov']+=1
for q in [3,4]:
 acts=[r for r in rows if r['period']==q];current={t:set(ps) for t,ps in starters[q].items()};previous=F(0);clock=Counter();segments=defaultdict(list)
 for r in acts:
  at=720-sec(r['clock']);assert at>=previous
  for tid,ps in current.items():
   assert len(ps)==5
   for p in ps:
    clock[tid,p]+=at-previous
    if at>previous:segments[tid,p].append((previous,at))
  lineups[r['actionId']]={t:set(ps) for t,ps in current.items()}
  if r['actionType']=='Substitution':
   inc,out=re.fullmatch('SUB: (.+) FOR (.+)',r['description']).groups();tid=r['teamId'];pid=r['personId'];poss=alias[tid][norm(inc)];assert len(poss)==1
   assert pid in current[tid] and pid in alias[tid][norm(out)]
   incoming=next(iter(poss));assert incoming not in current[tid];current[tid].remove(pid);current[tid].add(incoming)
  elif r['actionType'] in ['Made Shot','Missed Shot','Free Throw','Rebound','Turnover','Jump Ball'] and r['teamId'] in teams and r['personId']>0:
   assert r['personId'] in current[r['teamId']],r
  previous=at
 assert previous==720
 assert all(sum(s for (t,p),s in clock.items() if t==tid)==3600 for tid in teams)
 clocks[q]=clock;intervals[q]=segments
 ft={};trips=Counter();dead=set();andones=set()
 for i,r in enumerate(acts):
  if r['actionType']!='Free Throw':continue
  technical=r['subType']=='Free Throw Technical';m=re.fullmatch('Free Throw ([123]) of ([123])',r['subType']);assert technical or m,r
  candidates=[x for x in acts[:i] if x['actionType']=='Foul' and x['clock']==r['clock']]
  if technical:candidates=[x for x in candidates if x['subType'] in ['Technical','Defense 3 Second']]
  else:candidates=[x for x in candidates if x['subType']!='Technical' and not(int(m[2])>1 and x['subType']=='Personal' and 'PN' not in x['description'])]
  assert len(candidates)==1,(q,r,candidates)
  foul=candidates[0]
  if not technical and m[1]==m[2]=='1' and foul['subType']=='Defense 3 Second':technical=True
  ft[r['actionId']]=(technical,foul['actionId'],m)
  if not technical:
   assert foul['subType'] in ['Shooting','Personal','Loose Ball','Personal Take']
   if m[1]=='1':
    if m[2]=='1':
     matched=[a for a in acts[:i] if a['actionType']=='Made Shot' and a['clock']==r['clock'] and a['personId']==r['personId'] and a['teamId']==r['teamId']];assert len(matched)==1;andones.add(matched[0]['actionId'])
    else:trips[r['personId']]+=1
  if r['description'].startswith('MISS ') and (technical or m[1]!=m[2]):
   nxt=acts[i+1];assert nxt['actionType']=='Rebound' and nxt['teamId']==0 and nxt['personId']==r['teamId'] and nxt['clock']==r['clock'];dead.add(nxt['actionId'])
 # Live rebound chances come from literal rebound events after exclusion of dead-ball awards/buzzer shells.
 chances=Counter()
 for r in acts:
  if r['actionType']=='Rebound' and r['actionId'] not in dead:
   if r['teamId']==0 and sec(r['clock'])==0:dead.add(r['actionId']);continue
   for ps in lineups[r['actionId']].values():chances.update(ps)
 rebch[q]=chances;tripcount[q]=trips
 first=next(r for r in acts if r['actionType'] in ['Made Shot','Missed Shot','Turnover','Free Throw']);owner=first['teamId'] or first['personId'];assert owner in teams
 start=F(0);pending=False;credits=set();playlist=[]
 def finish(now,aid):
  exposed={p for (t,p),spans in segments.items() if t==owner and any(min(now,b)>max(start,a) for a,b in spans)}|credits
  if exposed:playlist.append({'team':owner,'start':str(start),'end':str(now),'players':sorted(exposed),'action_id':aid})
 for r in acts:
  aid=r['actionId'];kind=r['actionType'];tid=r['teamId'];now=720-sec(r['clock'])
  if kind=='Turnover' and tid==0:tid=r['personId']
  if kind=='Substitution':continue
  if kind=='Free Throw':
   technical,anchor,m=ft[aid]
   if not r['description'].startswith('MISS ') and owner==tid:credits|=lineups[anchor][tid]
   if technical:continue
  if kind=='Made Shot':credits|=lineups[aid][tid]
  if kind in ['Made Shot','Missed Shot','Turnover','Free Throw']:assert owner==tid,(q,r,owner)
  terminal=kind in ['Made Shot','Missed Shot','Turnover','Heave'] or(kind=='Free Throw' and m[1]==m[2])
  if aid in andones:terminal=False
  if terminal:
   assert owner in teams;finish(now,aid)
   if kind in ['Made Shot','Turnover'] or(kind=='Free Throw' and not r['description'].startswith('MISS ')):
    owner=next(t for t in teams if t!=owner);pending=False
   else:owner=None;pending=True
   start=now;credits=set()
  elif kind=='Rebound' and aid not in dead:
   assert owner is None and pending;owner=r['teamId'] or r['personId'];assert owner in teams;start=now;pending=False
  elif kind=='period' and r['subType']=='end' and owner is not None:
   finish(now,aid);owner=None
 plays[q]=playlist

import pandas as pd
zpath=Path('working/nba-tools-completion-program/source-evidence/rollover-2026-27/foul-anchor-20261105/qualification-evidence.zip')
with ZipFile(zpath) as z:
 report=json.loads(z.read('qualification.json'));frame=pd.read_csv(io.BytesIO(z.read('stage/data/raw/player_game_period_stats/2026-27_regular_season.csv')),float_precision='round_trip');core=pd.read_csv(io.BytesIO(z.read('stage/data/raw/player_game_stats/2026-27_regular_season.csv')),float_precision='round_trip')
for tid,t in teams.items():
 for p in t['players']:
  pid=p['personId'];base=core.loc[core.game_id.eq(int(gid))&core.team_id.eq(tid)&core.player_id.eq(pid)]
  for f,stat in [('fga','fieldGoalsAttempted'),('fta','freeThrowsAttempted'),('tov','turnovers'),('reb','reboundsTotal')]:
   v=sum(n for (q0,t0,p0,f0),n in counts.items() if(t0,p0,f0)==(tid,pid,f));assert v==p['statistics'][stat],(pid,f,v,p['statistics'][stat]);assert (len(base)==1 and base.iloc[0][f]==v)or(base.empty and v==0)
diag=json.loads((root/'diagnostics.json').read_text())['games'][gid]['groups'];verified=[]
for group in diag:
 periods=group['periods'];field=group['field'];selected=frame.loc[frame.game_id.eq(int(gid))&frame.source_start_period.eq(periods[0])&frame.source_end_period.eq(periods[-1])]
 for tid in teams:
  exposed={p for q in periods for(t,p),s in clocks[q].items() if t==tid and s>0};assert exposed==set(selected.loc[selected.team_id.eq(tid)&selected.minutes.gt(0),'player_id'])
 for _,r in selected.iterrows():
  tid,pid=int(r.team_id),int(r.player_id);s=sum((clocks[q][tid,pid] for q in periods),F(0));assert abs(s-F(str(r.minutes))*60)<=2
  for f in (['reb']if field=='reb_pct' else ['fga','fta','tov']):assert r[f]==sum(counts[q,tid,pid,f]for q in periods)
 for expected in group['conditional_exact_fractions']:
  tid,pid=expected['team_id'],expected['player_id']
  if field=='reb_pct':n=sum(counts[q,tid,pid,'reb']for q in periods);d=sum(rebch[q][pid]for q in periods)
  else:n=sum(counts[q,tid,pid,'fga']+counts[q,tid,pid,'tov']+tripcount[q][pid]for q in periods);d=sum(pid in p['players']for q in periods for p in plays[q]if p['team']==tid)
  assert(n,d,str(F(n,d)if d else F(0)))==(expected['numerator'],expected['denominator'],expected['exact']),(periods,field,pid,n,d,expected)
  verified.append({'periods':periods,'field':field,'player_id':pid,'team_id':tid,'numerator':n,'denominator':d,'exact':str(F(n,d)if d else F(0))})
print(json.dumps({'game':gid,'verified_rates':len(verified),'groups':len(diag),'source_delta':changes,'canonical_sha256':hashlib.sha256(canonical).hexdigest(),'independent_starters_from_pdf':{str(q):{str(t):sorted(ps)for t,ps in v.items()}for q,v in starters.items()},'quarter_play_counts':{str(q):Counter(str(p['team'])for p in v)for q,v in plays.items()},'example_tshiebwe':[v for v in verified if v['player_id']==1631131]},indent=2))
Path('/tmp/source_checker_0138-results.json').write_text(json.dumps(verified,indent=2)+'\n')
