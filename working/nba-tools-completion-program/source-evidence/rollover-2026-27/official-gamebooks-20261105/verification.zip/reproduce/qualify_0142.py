"""Finite offline evidence replay; no acquisition and no consumer correction logic."""
import copy
import csv
import hashlib
import io
import json
import re
from collections import Counter
from fractions import Fraction
from pathlib import Path
from zipfile import ZipFile

import pandas as pd
from pypdf import PdfReader
from nbatools.commands.data_utils import add_advanced_pct_columns
from nbatools.commands.pipeline import pull_game_period_stats as importer
from nbatools.commands.pipeline.validate_raw import validate_player_game_period_stats_df, validate_team_game_period_stats_df
from tools.qualify_period_counts import retained_sources, COUNT_FIELDS, FIELDS_BY_COLUMN
from tools.qualify_period_rates import whole_original, game_basis
from tools.period_event_evidence import _alias, period_facts, clock_facts
from tools.stage_current_season import SUFFIX

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
CAPTURE = WORK/'capture/acquired_data/official-gamebooks-20261105/0022600142'
BASE = ROOT/'working/nba-tools-completion-program/source-evidence/rollover-2026-27/foul-anchor-20261105/qualification-evidence.zip'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
GID='0022600142'
PDF_SHA='0c56c290a0225b4fefce424932c8960e37db2f5ba5637578f1ec2de00c00b629'
PDF_COLUMNS=['fgm','fga','fg3m','fg3a','ftm','fta','oreb','dreb','reb','ast','pf','stl','tov','blk','plus_minus','pts']

def clock(sec):
    value=sec*100
    assert value.denominator==1
    value=int(value)
    return f'{value//6000}:{value%6000//100:02d}.{value%100:02d}'

def add_shooting_pct_columns(frame):
    frame=frame.copy()
    for field,n,d in [('fg_pct','fgm','fga'),('fg3_pct','fg3m','fg3a'),('ft_pct','ftm','fta')]:
        frame[field]=[float(Fraction(a,b)) if b else 0.0 for a,b in zip(frame[n],frame[d],strict=True)]
    return frame

def run():
    out=WORK/'0142-qualified';out.mkdir(exist_ok=False)
    receipt=json.loads((CAPTURE/'capture.json').read_text());pdf=(CAPTURE/receipt['raw_file']).read_bytes()
    assert sha(pdf)==PDF_SHA and len(pdf)==receipt['size_bytes']==150218
    reader=PdfReader(io.BytesIO(pdf),strict=True)
    assert len(reader.pages)==18
    texts=[p.extract_text(extraction_mode='layout') for p in reader.pages]
    assert 'SUB: C.Martin FOR M.Sasser' in texts[14]
    assert 'Technical Free Throw 1 of 1' in texts[17]
    original=retained_sources()[GID];doc=json.loads(original);rows=doc['game']['actions']
    edits=[]
    for aid,changes,page in [
        (368,dict(personId=1631204,playerName='Sasser',playerNameI='M. Sasser',description='SUB: Martin FOR Sasser'),14),
        (476,dict(subType='Technical'),17),
        (477,dict(subType='Free Throw Technical',description='MISS Stirtz Technical Free Throw 1 of 1'),17),
    ]:
        r=rows[aid-1];assert r['actionId']==aid
        before={k:r[k] for k in changes}
        edits.append(dict(action_id=aid,before=before,after=changes,evidence=dict(pdf_sha256=PDF_SHA,page_zero_index=page)))
        r.update(changes)
    canonical=(json.dumps(doc,ensure_ascii=False,separators=(',',':'))+'\n').encode()
    (out/'original-events.json').write_bytes(original);(out/'canonical-events.json').write_bytes(canonical)
    (out/'correction-record.json').write_text(json.dumps(dict(schema_version=1,game_id=GID,original_sha256=sha(original),canonical_sha256=sha(canonical),original_event_order_preserved=True,source_generation_independence='unestablished',source_url=receipt['source_url'],source_sha256=PDF_SHA,edits=edits),indent=2)+'\n')
    whole_raw=whole_original(GID);counts,actions,whole,basis=game_basis(canonical,whole_raw,[3,4])
    assert all(not b['errors'] for b in basis.values())
    teams={whole[s]['teamId']:whole[s] for s in ['homeTeam','awayTeam']}
    # Complete whole-game count vector, not a single-player or fitted-rate check.
    for tid,t in teams.items():
        for p in t['players']:
            for f in COUNT_FIELDS:
                value=sum(v for (q,t2,pid,col),v in counts.items() if (t2,pid,col)==(tid,p['personId'],f))
                assert value==p['statistics'][FIELDS_BY_COLUMN[f]], (p['nameI'],f)
    # Parse complete literal scorer tables against exact whole-game identities.
    def table(page):
        current=None;result={};totals={}
        for line in texts[page].splitlines():
            if line.startswith('VISITOR:'):current=whole['awayTeam']['teamId']
            if line.startswith('HOME:'):current=whole['homeTeam']['teamId']
            m=re.search(r'\b(\d+:\d\d)\b',line)
            if not m or current is None:continue
            tail=line[m.end():].split()
            if len(tail)!=len(PDF_COLUMNS) or not all(re.fullmatch(r'-?\d+',v) for v in tail):continue
            values=dict(zip(PDF_COLUMNS,map(int,tail),strict=True));mm,ss=map(int,m[1].split(':'))
            prefix=line[:m.start()].strip()
            if not prefix:
                assert current not in totals
                totals[current]=dict(values,seconds=mm*60+ss);continue
            name=re.sub(r'^\d+\s+','',prefix);name=re.sub(r'\s+[FCG]$','',name)
            matches=[p for p in teams[current]['players'] if _alias(p['firstName']+' '+p['familyName'])==_alias(name)]
            assert len(matches)==1,(page,name)
            key=(current,matches[0]['personId']);assert key not in result
            result[key]=dict(values,seconds=mm*60+ss)
        assert len(totals)==2 and result
        return result,totals
    parsed={page:table(page) for page in [0,4,6,7]}
    facts=period_facts(canonical,game_id=GID,final_teams={tid:t['statistics']['points'] for tid,t in teams.items()})
    all_clocks=clock_facts(canonical,whole_raw,period_report=facts)
    for (tid,pid),values in parsed[0][0].items():
        person=next(p for p in teams[tid]['players'] if p['personId']==pid)
        assert abs(sum(all_clocks[q][tid].get(pid,Fraction(0)) for q in all_clocks)-values['seconds'])<=1
        for f in COUNT_FIELDS:
            assert values[f]==person['statistics'][FIELDS_BY_COLUMN[f]]
    for side in ['homeTeam','awayTeam']:
        tid=whole[side]['teamId']
        assert parsed[0][1][tid]['pts']==whole[side]['statistics']['points']
    for page in [4,6,7]:
        qs=[3] if page==4 else [4] if page==6 else [3,4]
        ps,ts=parsed[page]
        for tid,t in teams.items():
            exposed={pid for q in qs for pid,s in basis[q]['clocks'][tid].items() if s>0}
            assert exposed=={pid for (team,pid),v in ps.items() if team==tid and v['seconds']>0}, (page,tid,exposed,ps)
            assert sum(sum(basis[q]['clocks'][tid].values()) for q in qs)==ts[tid]['seconds']==3600*len(qs)
            for pid in exposed:
                observed=ps[tid,pid]
                sec=sum(basis[q]['clocks'][tid].get(pid,Fraction(0)) for q in qs)
                assert abs(sec-observed['seconds'])<=1,(page,pid,sec,observed['seconds'])
                for f in COUNT_FIELDS:
                    assert sum(counts[q,tid,pid,f] for q in qs)==observed[f],(page,pid,f)
            for f in COUNT_FIELDS:
                assert sum(ps[tid,pid][f] for pid in exposed)==ts[tid][f],(page,tid,f)
    with ZipFile(BASE) as z:
        assert hashlib.sha1(f'blob {len(BASE.read_bytes())}\0'.encode()+BASE.read_bytes()).hexdigest()=='27c8cfb2f8232dfd6cfe633cc6d6971535a3d652'
        prior={n:z.read(n) for n in z.namelist() if n.startswith('stage/data/') and n.endswith('.csv')}
        old_report=json.loads(z.read('qualification.json'))
    for name,raw in prior.items():
        p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
    stage=out/'stage'
    core=pd.read_csv(stage/f'data/raw/player_game_stats/{SUFFIX}')
    tc=pd.read_csv(stage/f'data/raw/team_game_stats/{SUFFIX}')
    pc=core.merge(tc[['game_id','team_id','wl']],on=['game_id','team_id'],validate='many_to_one')
    pc=pc[pc.game_id.eq(int(GID))];tc=tc[tc.game_id.eq(int(GID))]
    oracle=[];admissions=[]
    for page,qs in [(4,[3]),(7,[3,4])]:
        window=next(w for w in importer.PERIOD_WINDOWS if (w.start_period,w.end_period)==(qs[0],qs[-1]))
        source_players,source_teams=parsed[page];prows=[];trows=[]
        for (tid,pid),stats in source_players.items():
            sec=sum(basis[q]['clocks'][tid].get(pid,Fraction(0)) for q in qs)
            source=dict(stats);source.pop('seconds')
            prows.append(dict(game_id=int(GID),team_id=tid,player_id=pid,minutes=clock(sec),comment='',**source))
        for tid,stats in source_teams.items():
            source=dict(stats);sec=source.pop('seconds')
            trows.append(dict(game_id=int(GID),team_id=tid,minutes=clock(Fraction(sec)),**source))
        # General pure normalizers consume actual scorer rows, not fabricated V3 observations.
        pf=importer.normalize_boxscore_player_period_rows(add_shooting_pct_columns(pd.DataFrame(prows)),season='2026-27',season_type='Regular Season',period_window=window,player_context=pc)
        tf=importer.normalize_boxscore_team_period_rows(add_shooting_pct_columns(pd.DataFrame(trows)),season='2026-27',season_type='Regular Season',period_window=window,team_context=tc)
        for i,r in pf.iterrows():
            tid,pid=int(r.team_id),int(r.player_id)
            trips=sum(basis[q]['trips'][pid] for q in qs)
            involvement=sum(counts[q,tid,pid,'fga']+counts[q,tid,pid,'tov'] for q in qs)+trips
            pairs={'ast_pct':(int(r.ast),sum(basis[q]['teammate_fgm'][pid] for q in qs)),
                   'reb_pct':(int(r.reb),sum(basis[q]['rebound_chances'][pid] for q in qs)),
                   'tov_pct':(int(r.tov),involvement+int(r.ast)),
                   'usg_pct':(involvement,sum(pid in play['players'] for q in qs for play in basis[q]['plays'] if play['team_id']==tid))}
            for f,(n,d) in pairs.items():
                assert 0<=n<=d and (d>0 or n==0)
                exact=Fraction(n,d) if d else Fraction(0);pf.loc[i,f]=float(exact)
                oracle.append(dict(periods=qs,team_id=tid,player_id=pid,field=f,numerator=n,denominator=d,exact=str(exact)))
        pf=add_advanced_pct_columns(pf)
        pf=importer._complete_player_standard_window_keys(pf,pc,period_windows=(window,))
        pf=validate_player_game_period_stats_df(pf[list(importer.PLAYER_PERIOD_OUTPUT_COLUMNS)])
        tf=validate_team_game_period_stats_df(add_advanced_pct_columns(tf)[list(importer.TEAM_PERIOD_OUTPUT_COLUMNS)])
        assert len(pf)==len(pc) and len(tf)==2
        for kind,frame in [('player',pf),('team',tf)]:
            target=stage/f'data/raw/{kind}_game_period_stats/{SUFFIX}'
            previous=pd.read_csv(target)
            assert not ((previous.game_id.eq(int(GID)))&(previous.period_family.eq(window.period_family))&(previous.period_value.astype(str).eq(window.period_value))).any()
            with target.open('ab') as handle:handle.write(frame[list(previous.columns)].to_csv(index=False,header=False).encode())
        admissions.append(dict(periods=qs,player_rows=len(pf),team_rows=len(tf),scorer_page_zero_index=page))
    # Original16-file inventory: only append two windows to the2period files.
    preserved=[]
    for name,raw in prior.items():
        after=(out/name).read_bytes()
        if '_game_period_stats/' in name:assert after.startswith(raw)
        else:assert after==raw
        preserved.append(dict(path=name,old_sha256=sha(raw),new_sha256=sha(after)))
    before=pd.read_csv(io.BytesIO(prior[f'stage/data/raw/player_game_period_stats/{SUFFIX}']),float_precision='round_trip')
    after=pd.read_csv(stage/f'data/raw/player_game_period_stats/{SUFFIX}',float_precision='round_trip')
    assert after.iloc[:len(before)].equals(before)
    report=dict(classification='offline_scorer_derived_windows_pending_independent_acceptance',game_id=GID,source_pdf_sha256=PDF_SHA,original_events_sha256=sha(original),canonical_events_sha256=sha(canonical),admissions=admissions,rate_oracle=oracle,original_inventory=preserved,prior811preserved=True,existing554unknown_preserved=True,full_readiness=False,production_writes=0,source_generation_independence='unestablished')
    (out/'qualification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'admissions':admissions,'exact_rate_count':len(oracle),'old_rows':len(before),'new_rows':len(after)},indent=2))
    return out
if __name__=='__main__':run()
