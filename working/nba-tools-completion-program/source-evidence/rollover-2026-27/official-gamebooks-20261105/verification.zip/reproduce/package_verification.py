import hashlib,json
from pathlib import Path
from zipfile import ZipFile,ZipInfo,ZIP_DEFLATED
from tools.qualify_period_rates import whole_original
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
OUT=ROOT/'working/nba-tools-completion-program/source-evidence/rollover-2026-27/official-gamebooks-20261105'
sha=lambda b:hashlib.sha256(b).hexdigest()
files={}
review=json.loads(Path('/tmp/source_checker_review_files.json').read_text())
assert len(review)==20
for item in review:
 p=Path(item['path']);raw=p.read_bytes();assert sha(raw)==item['sha256'] and len(raw)==item['size_bytes'];files['independent/'+p.name]=raw
files['independent/review-files.json']=Path('/tmp/source_checker_review_files.json').read_bytes()
for name in ['qualify_0142.py','integrate.py','package.py','package_verification.py']:
 files['reproduce/'+name]=(HERE/name).read_bytes()
for p in (HERE/'methods-lane').glob('*.py'):files['reproduce/methods-lane/'+p.name]=p.read_bytes()
for name in ['qualification.json','whole-correction-records.json','0009-cell-patches.json']:
 files['integrated/'+name]=(HERE/'integrated'/name).read_bytes()
for name in ['qualification.json','correction-record.json','original-events.json']:
 files['0142/'+name]=(HERE/'0142-qualified'/name).read_bytes()
for p in (HERE/'methods-lane').glob('*.json'):files['methods-lane/'+p.name]=p.read_bytes()
for gid in ['0022600009','0022600138']:
 for p in (HERE/'methods-lane'/gid).glob('*.json'):files['methods-lane/'+gid+'/'+p.name]=p.read_bytes()
for gid in ['0022600009','0022600138','0022600142']:
 files[f'original-whole/{gid}.json']=whole_original(gid)
files['source-capture-test-summary.json']=(HERE/'capture/summary.json').read_bytes()
files['verification-inventory.json']=(json.dumps([dict(path=n,sha256=sha(b),size_bytes=len(b)) for n,b in sorted(files.items())],indent=2)+'\n').encode()
with ZipFile(OUT/'verification.zip','w',ZIP_DEFLATED) as z:
 for n,b in sorted(files.items()):
  info=ZipInfo(n,date_time=(2026,11,5,0,0,0));info.compress_type=ZIP_DEFLATED;z.writestr(info,b)
report=json.loads((HERE/'integrated/qualification.json').read_text())
receipt=dict(classification='qualified_offline_source_data_not_full_readiness',source_revision='cd47ab9d4ff3edb00e17c1a21b414213fc0076ad',branch='codex/official-evidence-20261105',pull_request=582,acquisition_run=42025941403,acquisition_candidate='1b86c6f7167d3cfb957450bf28670c578a7ad0ba',acquisition_request='d7445941a3233dfeb9fc257aa12c3e1368f9cbc1',acquisition_required_counts=dict(selected=1,executed=1,passed=1,skipped=0,failed=0,errors=0),independent_review=dict(reviewer='Codex /root/source_checker',verdict='approved_bounded_offline_source_data',receipt_sha256='bb2c97b3400092ca38b342b96954aad827fd0aa51e6312fc87df2afc27769c11',exact_fractions=318,preserved_prior_fractions=811),game0142_resolved=True,observed_required_windows=647,original_withheld=1365,original_population_qualified=953,original_population_unknown=412,newly_unknown=72,total_unknown=484,unknown_groups=20,required_structural_passes=16,full_numerical_readiness=False,current_freshness_accepted=False,production_writes=0,validation_cutoff_utc='2026-11-05T06:59:31.715470Z',exact_due_game_ids=report['due_population']['due_game_ids'],archives={p.name:dict(size_bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in [OUT/'original-capture.zip',OUT/'normalized-snapshot.zip',OUT/'verification.zip']},final_head_ci='Required; final exact-head and landing receipts in PR582',source_generation_independence='unestablished')
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt['archives'],indent=2))
