"""Read captured scorer tables and audit old data; write only lane evidence."""

import hashlib
import io
import json
from pathlib import Path
import re
import sys
import unicodedata
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT))
import pandas as pd
from tools.qualify_period_rates import whole_original,game_basis

HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent/'capture/acquired_data/official-gamebooks-20261105/0022600009'
BASE=ROOT/'working/nba-tools-completion-program/source-evidence/rollover-2026-27/foul-anchor-20261105/qualification-evidence.zip'
FIELDS=['fgm','fga','fg3m','fg3a','ftm','fta','oreb','dreb','reb','ast','pf','stl','tov','blk','plus_minus','pts']


def norm(value):
    return re.sub('[^a-z0-9]','',unicodedata.normalize('NFKD',value).encode('ascii','ignore').decode().lower())


def main():
    assert hashlib.sha256(BASE.read_bytes()).hexdigest()=='3981e4e459daedee069a30ac49dc84c69078ddb2efb244f07d57b3aa596e076c'
    whole=json.loads(whole_original('0022600009'))['boxScoreTraditional']
    lookup={(side,norm(p['firstName']+' '+p['familyName'])):p['personId'] for side in ['awayTeam','homeTeam'] for p in whole[side]['players']}
    with ZipFile(BASE) as z:
        report=json.loads(z.read('qualification.json'))
        period=pd.read_csv(io.BytesIO(z.read('stage/data/raw/player_game_period_stats/2026-27_regular_season.csv')),float_precision='round_trip')
        core=pd.read_csv(io.BytesIO(z.read('stage/data/raw/player_game_stats/2026-27_regular_season.csv')),float_precision='round_trip')
    tables={};team_tables={};conflicts=[]
    for page,start,end in [(0,1,4),(1,1,1),(2,2,2),(3,1,2)]:
        side='awayTeam';rows=[];teams=[]
        for line in (SOURCE/f'page-{page:02}.txt').read_text().splitlines():
            if line.startswith('HOME:'):side='homeTeam'
            total=re.fullmatch(r'\s*(\d+:\d\d)\s+((?:-?\d+\s+){15}-?\d+)\s*',line)
            if total:
                minutes,seconds=map(int,total[1].split(':'))
                teams.append(dict(game_id='0022600009',team_id=whole[side]['teamId'],seconds=minutes*60+seconds,pdf_page_index=page,source_start_period=start,source_end_period=end,**dict(zip(FIELDS,map(int,total[2].split())))))
            match=re.fullmatch(r'\s*(\d+)\s+(.+?)\s+(?:[FCG]\s+)?(\d+:\d\d)\s+((?:-?\d+\s+){15}-?\d+)\s*',line)
            if not match:continue
            name=match[2].strip();pid=lookup[side,norm(name)]
            seconds=int(match[3].split(':')[0])*60+int(match[3].split(':')[1])
            values=list(map(int,match[4].split()));assert len(values)==16
            row=dict(game_id='0022600009',team_id=whole[side]['teamId'],player_id=pid,player_name=name,seconds=seconds,pdf_page_index=page,source_start_period=start,source_end_period=end,**dict(zip(FIELDS,values)))
            rows.append(row)
            old=core.loc[core.game_id.eq(22600009)&core.player_id.eq(pid)] if page==0 else period.loc[period.game_id.eq(22600009)&period.player_id.eq(pid)&period.source_start_period.eq(start)&period.source_end_period.eq(end)]
            assert len(old)==1
            for field in FIELDS:
                if old.iloc[0][field]!=row[field]:conflicts.append(dict(scope='whole' if page==0 else [start,end],player_id=pid,team_id=row['team_id'],field=field,before=float(old.iloc[0][field]),document_value=row[field],pdf_page_index=page))
            if abs(old.iloc[0]['minutes']*60-seconds)>1:
                conflicts.append(dict(scope='whole' if page==0 else [start,end],player_id=pid,team_id=row['team_id'],field='seconds',before=float(old.iloc[0]['minutes']*60),document_value=seconds,pdf_page_index=page))
        assert len({(r['team_id'],r['player_id']) for r in rows})==len(rows)
        for side in ['awayTeam','homeTeam']:
            assert sum(r['seconds'] for r in rows if r['team_id']==whole[side]['teamId'])==5*720*(end-start+1)
        tables[str(page)]=rows
        assert len(teams)==2
        for team in teams:
            people=[r for r in rows if r['team_id']==team['team_id']]
            for field in ['seconds',*FIELDS]:
                if field=='plus_minus':continue
                assert sum(r[field] for r in people)==team[field],('team sum',page,team['team_id'],field)
            other=next(t for t in teams if t['team_id']!=team['team_id'])
            assert team['plus_minus']==team['pts']-other['pts']
        team_tables[str(page)]=teams
    for half in tables['3']:
        quarters=[r for page in ['1','2'] for r in tables[page] if r['player_id']==half['player_id']]
        for field in ['seconds',*FIELDS]:assert sum(r[field] for r in quarters)==half[field],(half['player_id'],field)
    raw=(HERE/'0022600009/conditional-canonical-events.json').read_bytes()
    counts,actions,context,basis=game_basis(raw,whole_original('0022600009'),{1,2})
    document_consistency=[]
    for page,periods in [('1',[1]),('2',[2]),('3',[1,2])]:
        for row in tables[page]:
            tid,pid=row['team_id'],row['player_id']
            actual=sum(basis[q]['clocks'][tid].get(pid,0) for q in periods)
            assert actual==row['seconds'],(page,pid,'clock',actual,row['seconds'])
            for field in ['fgm','fga','fg3m','fg3a','ftm','fta','oreb','dreb','reb','ast','stl','tov','blk','pts']:
                observed=sum(counts[q,tid,pid,field] for q in periods)
                assert observed==row[field],(page,pid,field,observed,row[field])
        document_consistency.append(dict(page_index=int(page),positive_players=len(tables[page]),complete_clock_and_event_input_vectors_match=True))
    prior0009=[c for c in report['changes'] if c['game_id']=='0022600009']
    assert not prior0009
    out=dict(classification='documentary_data_records_and_prior_authority_conflicts_not_acceptance',pdf_sha256='7eae719b5ce5dc4d9f1fb2aba7c87b3e1799d7ea672f5e91c74d7c19fd464335',source_generation_independence='unestablished',scorer_tables=tables,scorer_team_tables=team_tables,half_equals_quarters_all_fields=True,team_equals_player_sums_all_fields_except_margin=True,canonical_event_document_consistency=document_consistency,old_canonical_conflicts=conflicts,previous_811_qualified0009_entries=0,scope_note='All 811 changed rates are outside 0009. This is distinct from unmodified source-reported rates and from count authority. New PDF conflicts must be adjudicated before claiming the conflicting old counts are still numerically accepted.',next='Source qualification and independent review of explicit official-scorer count authority, then keyed preparation changes and dependent invalidations/requalification. No additional missing first-half source record is identified by this assessment.',canonical_writes=0,production_writes=0)
    path=HERE/'0009-scorer-audit.json';path.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print(json.dumps(dict(sha256=hashlib.sha256(path.read_bytes()).hexdigest(),tables={p:len(rows) for p,rows in tables.items()},document_consistency=document_consistency,conflicts=len(conflicts),prior811affected=0),indent=2))


if __name__=='__main__':main()
