"""Historical keyed cell delta for independent review; no shared data writes."""

import copy
import csv
import hashlib
import io
import json
from fractions import Fraction
from pathlib import Path
from zipfile import ZipFile

import pandas as pd
from replay import BASE,BASE_SHA256,HERE,diagnose,game_basis,whole_original
from tools.season_rollover_core_bridge import _literal_clock_seconds

PDF_SHA='7eae719b5ce5dc4d9f1fb2aba7c87b3e1799d7ea672f5e91c74d7c19fd464335'
SUFFIX='2026-27_regular_season.csv'


def sha(raw):return hashlib.sha256(raw).hexdigest()


def save(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')


def main():
    baseline=BASE.read_bytes();assert sha(baseline)==BASE_SHA256
    audit=json.loads((HERE/'0009-scorer-audit.json').read_text())
    with ZipFile(io.BytesIO(baseline)) as z:
        originals={n:z.read(n) for n in z.namelist() if n.startswith('stage/data/') and n.endswith('.csv')}
        prior=json.loads(z.read('qualification.json'))
    assert not [c for c in prior['changes'] if c['game_id']=='0022600009']
    paths={key:f'stage/data/raw/{key}/{SUFFIX}' for key in ['player_game_stats','team_game_stats','player_game_period_stats','team_game_period_stats']}
    tables={key:list(csv.reader(io.StringIO(originals[path].decode()))) for key,path in paths.items()}
    patches=[]

    def select(dataset,tid,pid=None,start=None,end=None):
        rows=tables[dataset];head=rows[0];matches=[]
        for index,row in enumerate(rows[1:]):
            if int(row[head.index('game_id')])!=22600009 or int(row[head.index('team_id')])!=tid:continue
            if pid is not None and int(row[head.index('player_id')])!=pid:continue
            if start is not None and (int(row[head.index('source_start_period')]),int(row[head.index('source_end_period')]))!=(start,end):continue
            matches.append((index,row))
        assert len(matches)==1,(dataset,tid,pid,start,end,len(matches))
        return matches[0]

    def patch(dataset,index,field,value,page,reason,**evidence):
        table=tables[dataset];head=table[0];row=table[index+1];col=head.index(field)
        before=row[col];after='' if value is None else str(value)
        if before==after:return
        key={k:row[head.index(k)] for k in ['game_id','team_id','player_id','period_family','period_value'] if k in head}
        assert not any(p['dataset']==dataset and p['row']==index and p['field']==field for p in patches)
        patches.append(dict(dataset=dataset,path=paths[dataset],baseline_sha256=sha(originals[paths[dataset]]),row=index,key=key,field=field,before_literal=before,after_literal=after,source_pdf_sha256=PDF_SHA,pdf_page_index=page,reason=reason,**evidence))
        row[col]=after

    for page,source_rows in audit['scorer_tables'].items():
        pi=int(page);dataset='player_game_stats' if pi==0 else 'player_game_period_stats'
        for source in source_rows:
            index,row=select(dataset,source['team_id'],source['player_id'],None if pi==0 else source['source_start_period'],None if pi==0 else source['source_end_period'])
            head=tables[dataset][0]
            for field in ['fgm','fga','fg3m','fg3a','ftm','fta','oreb','dreb','reb','ast','pf','stl','tov','blk','plus_minus','pts']:
                if Fraction(row[head.index(field)])!=source[field]:patch(dataset,index,field,source[field],pi,'Official scorer count, corroborated by explicit canonical event actor/credit where changed.')
            if abs(Fraction(row[head.index('minutes')])*60-source['seconds'])>1:
                patch(dataset,index,'minutes',float(Fraction(source['seconds'],60)),pi,'Official whole scorer clock; equals original whole clock plus independently reconstructed Q1 clock delta.',exact_seconds=source['seconds'])
    for page,source_rows in audit['scorer_team_tables'].items():
        pi=int(page);dataset='team_game_stats' if pi==0 else 'team_game_period_stats'
        for source in source_rows:
            index,row=select(dataset,source['team_id'],None,None if pi==0 else source['source_start_period'],None if pi==0 else source['source_end_period'])
            head=tables[dataset][0]
            for field in ['fgm','fga','fg3m','fg3a','ftm','fta','oreb','dreb','reb','ast','pf','stl','tov','blk','plus_minus','pts']:
                if field in head and Fraction(row[head.index(field)])!=source[field]:patch(dataset,index,field,source[field],pi,'Official team scorer count; complete same-scope player sum independently agrees.')

    def dataframe(dataset):
        out=io.StringIO();csv.writer(out,lineterminator='\n').writerows(tables[dataset]);return pd.read_csv(io.StringIO(out.getvalue()),float_precision='round_trip')

    whole_before=whole_original('0022600009');whole_doc=json.loads(whole_before);whole_ops=[]
    fieldmap={'ast':'assists','stl':'steals'}
    for person in audit['scorer_tables']['0']:
        team=next(whole_doc['boxScoreTraditional'][side] for side in ['homeTeam','awayTeam'] if whole_doc['boxScoreTraditional'][side]['teamId']==person['team_id'])
        p=next(p for p in team['players'] if p['personId']==person['player_id'])
        for field,sourcefield in fieldmap.items():
            if p['statistics'][sourcefield]!=person[field]:
                whole_ops.append(dict(team_id=person['team_id'],player_id=person['player_id'],field=sourcefield,before=p['statistics'][sourcefield],after=person[field],pdf_page_index=0))
                p['statistics'][sourcefield]=person[field]
        old=p['statistics']['minutes'];seconds=_literal_clock_seconds(old);new=f"{person['seconds']//60:02}:{person['seconds']%60:02}"
        if seconds!=person['seconds']:
            whole_ops.append(dict(team_id=person['team_id'],player_id=person['player_id'],field='minutes',before=old,after=new,pdf_page_index=0))
            p['statistics']['minutes']=new
    for person in audit['scorer_team_tables']['0']:
        team=next(whole_doc['boxScoreTraditional'][side] for side in ['homeTeam','awayTeam'] if whole_doc['boxScoreTraditional'][side]['teamId']==person['team_id'])
        if team['statistics']['assists']!=person['ast']:
            whole_ops.append(dict(team_id=person['team_id'],player_id=None,field='assists',before=team['statistics']['assists'],after=person['ast'],pdf_page_index=0))
            team['statistics']['assists']=person['ast']
    whole_after=(json.dumps(whole_doc,indent=2)+'\n').encode()
    (HERE/'0022600009/conditional-canonical-whole.json').write_bytes(whole_after)
    event_after=(HERE/'0022600009/conditional-canonical-events.json').read_bytes()
    core,frame=dataframe('player_game_stats'),dataframe('player_game_period_stats')
    groups=diagnose('0022600009',event_after,prior,frame,core,whole_override=whole_after)
    assert all(g['numerical_gates_passed'] for g in groups)
    assert sum(len(g['conditional_exact_fractions']) for g in groups)==38
    for group in groups:
        for value in group['conditional_exact_fractions']:
            patch('player_game_period_stats',value['row'],'ast_pct',float(Fraction(value['exact'])),1 if len(group['periods'])==1 else 3,'Complete source-qualified input, lineup and clock vectors; exact AST fraction.',numerator=value['numerator'],denominator=value['denominator'],exact_fraction=value['exact'])

    counts,actions,whole,basis=game_basis(event_after,whole_after,{1,2})
    invalidations=[];reb_rechecks=[]
    for periods in [(1,),(1,2)]:
        selected=frame.loc[frame.game_id.eq(22600009)&frame.source_start_period.eq(periods[0])&frame.source_end_period.eq(periods[-1])]
        for index,row in selected.iterrows():
            pid,tid=int(row.player_id),int(row.team_id)
            n=sum(counts[q,tid,pid,'reb'] for q in periods);d=sum(basis[q]['rebound_chances'][pid] for q in periods)
            exact=Fraction(n,d) if d else Fraction(0)
            assert abs(float(exact)-row.reb_pct)<=0.000501
            reb_rechecks.append(dict(row=int(index),periods=periods,player_id=pid,team_id=tid,numerator=n,denominator=d,exact=str(exact),preserved_value=float(row.reb_pct),agrees_with_original_rounding=True))
            for field in ['tov_pct','usg_pct']:
                assert any(field in basis[q]['errors'] for q in periods)
                if row.minutes==0:
                    assert row[field]==0
                    continue
                if not pd.isna(row[field]):
                    patch('player_game_period_stats',int(index),field,None,9,'Newly unqualified outside original 1365: complete-trip group gate fails because made Eason FG2:15 and FT1of1 at2:06 lack a unique same-clock and-one anchor.',periods=periods,original_1365_member=False)
                    invalidations.append(dict(row=int(index),field=field,periods=periods,player_id=pid,team_id=tid,before=float(row[field]),after=None,original_1365_member=False))
    assert len(invalidations)==72
    finalframe=dataframe('player_game_period_stats')
    for c in prior['changes']:assert finalframe.iloc[c['row']][c['field']]==c['after']
    assert BASE.read_bytes()==baseline
    for name,table in tables.items():
        # Only lane copies are written. Original shared baseline remains immutable.
        folder=HERE/'0009-stage'/Path(paths[name]).parent;folder.mkdir(parents=True,exist_ok=True)
        with (folder/Path(paths[name]).name).open('w',newline='') as f:csv.writer(f,lineterminator='\n').writerows(table)
    record=dict(schema_version=1,classification='historical_guarded_data_delta_pending_independent_review',game_id='0022600009',source_pdf_sha256=PDF_SHA,baseline_archive_sha256=BASE_SHA256,patches=patches,canonical_whole_operations=whole_ops,original_whole_sha256=sha(whole_before),canonical_whole_sha256=sha(whole_after),canonical_event_sha256=sha(event_after),ast_groups=groups,restored_original_population_ast_values=38,new_unknown_outside_original1365=invalidations,preserved_zero_duration_tov_usg_cells=4,reb_rechecks=reb_rechecks,previous_811_preserved_and_unaffected=True,statistical_dependency='Official PDF retains Eason made field goal2:15 and foul/one-shot FT2:06; an authoritative complete award association/credit record is missing. Do not guess clock or trip semantics.',source_generation_independence='unestablished; field-scoped authoritative scorer correction is distinct',canonical_shared_writes=0,production_writes=0)
    path=HERE/'csv-cell-patches.json';save(path,record)
    print(json.dumps(dict(patch_sha256=sha(path.read_bytes()),patches=len(patches),by_dataset={k:sum(p['dataset']==k for p in patches) for k in tables},count_clock_patches=sum(p['field'] not in ['ast_pct','tov_pct','usg_pct'] for p in patches),restored_ast=38,new_unknown=72,unchanged_reb_checked=len(reb_rechecks),whole_operations=len(whole_ops)),indent=2))


if __name__=='__main__':main()
