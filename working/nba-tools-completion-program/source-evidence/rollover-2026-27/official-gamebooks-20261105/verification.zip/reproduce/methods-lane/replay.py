"""Historical documentary diagnostics only; no qualification or publication.

JSON records preserve guarded original event fields and explicit canonical order.
This investigation imports existing validators; routine acquisition is unchanged.
"""

from collections import Counter
from fractions import Fraction
from hashlib import sha256
from io import BytesIO
import copy
import json
from pathlib import Path
import sys
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
import pandas as pd
from tools.qualify_period_counts import FIELDS_BY_COLUMN, retained_sources
from tools.qualify_period_rates import INPUTS, game_basis, whole_original

HERE = Path(__file__).resolve().parent
CAPTURE = HERE.parent / 'capture/acquired_data/official-gamebooks-20261105'
BASE = ROOT / 'working/nba-tools-completion-program/source-evidence/rollover-2026-27/foul-anchor-20261105/qualification-evidence.zip'
BASE_SHA256 = '3981e4e459daedee069a30ac49dc84c69078ddb2efb244f07d57b3aa596e076c'
EXPECTED = {
    '0022600009': ('4a19d25d9894a456a8cff5fb30e49ce402cf4c31a2d78fca2d7fc4241e3d13b6', '7eae719b5ce5dc4d9f1fb2aba7c87b3e1799d7ea672f5e91c74d7c19fd464335'),
    '0022600138': ('cd687bbb69eb2bf273f18a47c33f53a3a66d24952ffd0156d125076d5afd92b7', '1f8ffdff0a2bdeb67ee8acf8cb8b6083ff2ee717982ef7f11fc3e146d54f4389'),
}


def digest(raw):
    return sha256(raw).hexdigest()


def write(path, obj):
    path.write_text(json.dumps(obj, indent=2, sort_keys=True) + '\n')


def build_records(sources):
    records = []
    score_readings = {91:(22,25),98:(22,27),100:(22,28),108:(24,28),110:(24,29),111:(24,30),115:(24,32),116:(27,32),121:(27,32),122:(27,32),124:(27,34),129:(27,35),130:(27,36)}
    for gid, (source_hash, pdf_hash) in EXPECTED.items():
        raw = sources[gid]
        assert digest(raw) == source_hash
        receipt = json.loads((CAPTURE / gid / 'capture.json').read_text())
        assert receipt['sha256'] == pdf_hash
        assert digest((CAPTURE / gid / receipt['raw_file']).read_bytes()) == pdf_hash
        rows = json.loads(raw)['game']['actions']
        by_id = {r['actionId']: r for r in rows}
        operations = []
        if gid.endswith('0009'):
            for aid, (home, away) in score_readings.items():
                fields = ['scoreHome', 'scoreAway', 'pointsTotal']
                operations.append(dict(op='replace_fields', source_action_id=aid, source_action_number=by_id[aid]['actionNumber'], before={k:by_id[aid][k] for k in fields}, after=dict(scoreHome=str(home),scoreAway=str(away),pointsTotal=home+away), evidence_page_index=9 if aid < 122 else 11))
            def replacement(aid, after, page):
                operations.append(dict(op='replace_fields',source_action_id=aid,source_action_number=by_id[aid]['actionNumber'],before={k:by_id[aid][k] for k in after},after=after,evidence_page_index=page))
            replacement(49,dict(description='SUB: Johnson FOR Castle'),8)
            replacement(53,dict(description='SUB: Eason FOR Sengun'),8)
            replacement(54,dict(description='SUB: Smart FOR Thompson'),8)
            for aid in [51,85]:
                operations.append(dict(op='remove_event',source_action_id=aid,source_action_number=by_id[aid]['actionNumber'],before=by_id[aid],evidence_page_index=8 if aid==51 else 9,reason='Not in complete PDF substitution sequence; retaining would contradict its player minutes/identity sequence. Original remains separately retained.'))
            for key,outgoing,family,display,incoming in [
                ('pdf:p08:q1:0454:fox-for-harper',1642844,'Harper','D. Harper','Fox'),
                ('pdf:p08:q1:0454:bryant-for-vassell',1630170,'Vassell','D. Vassell','Bryant'),
            ]:
                newrow=copy.deepcopy(by_id[49])
                newrow.update(actionId=None,actionNumber=None,clock='PT04M54.00S',personId=outgoing,playerName=family,playerNameI=display,description=f'SUB: {incoming} FOR {family}')
                operations.append(dict(op='insert_before',source_event_key=key,before_source_action_id=60,row=newrow,evidence_page_index=8,reason='Explicit PDF substitution absent from retained event original. No original NBA actionNumber is invented.'))
            replacement(86,dict(clock='PT03M04.00S',personId=1628436,playerName='Kornet',playerNameI='L. Kornet',description='SUB: Wembanyama FOR Kornet'),9)
            replacement(87,dict(clock='PT03M04.00S',personId=1642868,playerName='Bryant',playerNameI='C. Bryant',description='SUB: Castle FOR Bryant'),9)
            replacement(88,dict(clock='PT03M04.00S'),9)
            for aid in [89,90]:replacement(aid,dict(clock='PT02M56.00S'),9)
            for aid,clock in [(101,'PT02M31.00S'),(102,'PT02M31.00S'),(103,'PT02M30.00S')]:
                replacement(aid,dict(clock=clock),9)
                operations.append(dict(op='move_before',source_action_id=aid,source_action_number=by_id[aid]['actionNumber'],before_source_action_id=96,evidence_page_index=9))
            replacement(97,dict(personId=1631095,playerName='Smith Jr.',playerNameI='J. Smith Jr.',description='Smith Jr. STEAL (1 STL)'),9)
            replacement(55,dict(description=by_id[55]['description'].replace(' (Durant 1 AST)','')),8)
            limits = ['Full PDF first-quarter substitution, scoring and specified actor interpretation. This contradicts prior count authority: Durant Q1/H1 AST 3 versus PDF 2, whole AST 6 versus PDF 5; Smith/Adams steal attribution also differs.', 'No canonical count is silently replaced. Complete input gates against the old accepted count basis must fail until the source-authority conflict is independently adjudicated. Source-generation independence is unestablished.']
        else:
            operations.append(dict(op='replace_fields',source_action_id=481,source_action_number=by_id[481]['actionNumber'],before=dict(clock=by_id[481]['clock']),after=dict(clock='PT03M03.00S'),evidence_page_index=18))
            operations.append(dict(op='move_before',source_action_id=482,source_action_number=by_id[482]['actionNumber'],before_source_action_id=481,guard_original_neighbor_order=[480,481,482,483],evidence_page_index=18))
            limits = ['The PDF distinguishes substitution at03:04 before rebound at03:03; source generation independence is unestablished.', 'Canonical actionId resequencing is explicit; original actionId/actionNumber remain retained in originals and the identity map.']
        records.append(dict(schema_version=1,game_id=gid,state='document_supported_conditional_unaccepted',original_event_sha256=source_hash,whole_source_sha256=digest(whole_original(gid)),source=dict(url=receipt['source_url'],sha256=pdf_hash,capture_receipt=receipt),operations=operations,canonical_sequence_field='actionId',preserve_original_identifiers_in='identity-map.json',limitations=limits,accepted_source_qualification=False,canonical_promotion=False))
    return records


def materialize(record, raw):
    assert digest(raw) == record['original_event_sha256']
    doc = json.loads(raw)
    rows = copy.deepcopy(doc['game']['actions'])
    original_ids = {id(row):row['actionId'] for row in rows}
    for op in record['operations']:
        if op['op']=='insert_before':
            row=copy.deepcopy(op['row'])
            original_ids[id(row)]=op['source_event_key']
            before=next(r for r in rows if original_ids[id(r)]==op['before_source_action_id'])
            rows.insert(rows.index(before),row)
            continue
        row = next(r for r in rows if original_ids[id(r)] == op['source_action_id'])
        assert row['actionNumber'] == op['source_action_number']
        if op['op'] == 'replace_fields':
            assert {k:row[k] for k in op['before']} == op['before']
            row.update(op['after'])
        elif op['op'] == 'move_before':
            if 'guard_original_neighbor_order' in op:
                guard = op['guard_original_neighbor_order']
                ids = [original_ids[id(r)] for r in rows]
                at = ids.index(guard[0])
                assert ids[at:at+len(guard)] == guard
            rows.remove(row)
            before = next(r for r in rows if original_ids[id(r)] == op['before_source_action_id'])
            rows.insert(rows.index(before), row)
        elif op['op']=='remove_event':
            assert row==op['before']
            rows.remove(row)
        else:
            raise AssertionError('Unknown operation')
    identity = []
    for seq, row in enumerate(rows, 1):
        key=original_ids[id(row)]
        identity.append(dict(source_action_id=key if isinstance(key,int) else None,source_event_key=key,source_action_number=row['actionNumber'],canonical_action_id=seq))
        row['actionId'] = seq
    deleted={op['source_action_id'] for op in record['operations'] if op['op']=='remove_event'}
    inserted=[op for op in record['operations'] if op['op']=='insert_before']
    assert len(rows)==len(doc['game']['actions'])-len(deleted)+len(inserted)
    assert {i['source_action_id'] for i in identity if i['source_action_id'] is not None}|deleted==set(range(1,len(doc['game']['actions'])+1))
    doc['game']['actions'] = rows
    return (json.dumps(doc,indent=2)+'\n').encode(), identity


def diagnose(gid, raw, report, frame, core, whole_override=None):
    targets = [r for r in report['unknown'] if r['game_id']==gid]
    groups = sorted({(tuple(r['periods']),r['field']) for r in targets})
    counts, actions, whole, basis = game_basis(raw,whole_override or whole_original(gid),{p for ps,_ in groups for p in ps})
    results = []
    for periods, field in groups:
        errors = [dict(period=q,reason=basis[q]['errors'][field]) for q in periods if field in basis[q]['errors']]
        whole_errors,window_errors,clock_errors,population_errors = [],[],[],[]
        for side in ['homeTeam','awayTeam']:
            team = whole[side]; tid=team['teamId']
            for player in team['players']:
                pid=player['personId']; baseline=core.loc[core.game_id.eq(int(gid)) & core.team_id.eq(tid) & core.player_id.eq(pid)]
                for f in INPUTS[field]:
                    total=sum(v for (q,t,p,col),v in counts.items() if (t,p,col)==(tid,pid,f))
                    if total != player['statistics'][FIELDS_BY_COLUMN[f]] or not ((len(baseline)==1 and total==baseline.iloc[0][f]) or (baseline.empty and total==0)):
                        whole_errors.append(dict(team_id=tid,player_id=pid,field=f,event_count=total))
        selected=frame.loc[frame.game_id.eq(int(gid)) & frame.source_start_period.eq(periods[0]) & frame.source_end_period.eq(periods[-1])]
        if not errors:
            for side in ['homeTeam','awayTeam']:
                tid=whole[side]['teamId']; exposed={p for q in periods for p,sec in basis[q]['clocks'][tid].items() if sec>0}
                actual=set(selected.loc[selected.team_id.eq(tid) & selected.minutes.gt(0),'player_id'])
                if exposed != actual: population_errors.append(dict(team_id=tid,event_players=sorted(exposed),baseline_players=sorted(actual)))
            for _,row in selected.iterrows():
                seconds=sum((basis[q]['clocks'][int(row.team_id)].get(int(row.player_id),Fraction(0)) for q in periods),Fraction(0))
                if abs(seconds-Fraction(str(row.minutes))*60)>2:
                    clock_errors.append(dict(player_id=int(row.player_id),team_id=int(row.team_id),event_seconds=str(seconds),baseline_seconds=str(Fraction(str(row.minutes))*60)))
                for f in INPUTS[field]:
                    expected=sum(counts[q,row.team_id,row.player_id,f] for q in periods)
                    if row[f] != expected: window_errors.append(dict(player_id=int(row.player_id),team_id=int(row.team_id),field=f,event_count=expected,baseline=float(row[f])))
        passed=not any([errors,whole_errors,window_errors,clock_errors,population_errors])
        fractions=[]
        if passed:
            for target in targets:
                if (tuple(target['periods']),target['field']) != (periods,field):continue
                row=frame.iloc[target['row']];pid,tid=int(row.player_id),int(row.team_id)
                trips=sum(basis[q].get('trips',Counter())[pid] for q in periods)
                involvement=sum(counts[q,tid,pid,'fga']+counts[q,tid,pid,'tov'] for q in periods)+trips
                if field=='ast_pct':n=sum(counts[q,tid,pid,'ast'] for q in periods);d=sum(basis[q]['teammate_fgm'][pid] for q in periods)
                elif field=='reb_pct':n=sum(counts[q,tid,pid,'reb'] for q in periods);d=sum(basis[q]['rebound_chances'][pid] for q in periods)
                else:n=involvement;d=sum(pid in play['players'] for q in periods for play in basis[q]['plays'] if play['team_id']==tid)
                assert 0<=n<=d
                fractions.append(dict(row=target['row'],player_id=pid,team_id=tid,numerator=n,denominator=d,exact=str(Fraction(n,d) if d else Fraction(0))))
        results.append(dict(periods=periods,field=field,target_observations=sum((tuple(r['periods']),r['field'])==(periods,field) for r in targets),basis_errors=errors,whole_input_errors=whole_errors,window_input_errors=window_errors,clock_errors=clock_errors,population_errors=population_errors,numerical_gates_passed=passed,conditional_exact_fractions=fractions))
    return results


def main():
    baseline_raw=BASE.read_bytes(); sources=retained_sources()
    assert digest(baseline_raw) == BASE_SHA256
    records=build_records(sources)
    write(HERE/'correction-records.json',records)
    with ZipFile(BytesIO(baseline_raw)) as z:
        report=json.loads(z.read('qualification.json'))
        csvs={n:z.read(n) for n in z.namelist() if n.endswith('.csv')}
        frame=pd.read_csv(BytesIO(csvs['stage/data/raw/player_game_period_stats/2026-27_regular_season.csv']),float_precision='round_trip')
        core=pd.read_csv(BytesIO(csvs['stage/data/raw/player_game_stats/2026-27_regular_season.csv']),float_precision='round_trip')
    assert report['qualified']==811 and report['unresolved']==554
    assert len(report['changes'])==811
    for c in report['changes']:
        assert frame.iloc[c['row']][c['field']]==c['after']
    results={}
    for record in records:
        gid=record['game_id']; folder=HERE/gid;folder.mkdir(exist_ok=True)
        (folder/'original-events.json').write_bytes(sources[gid])
        raw,identity=materialize(record,sources[gid])
        (folder/'conditional-canonical-events.json').write_bytes(raw)
        write(folder/'identity-map.json',identity)
        results[gid]=dict(canonical_event_sha256=digest(raw),original_event_sha256=digest(sources[gid]),groups=diagnose(gid,raw,report,frame,core))
    assert BASE.read_bytes()==baseline_raw
    summary=dict(state='conditional_diagnostics_not_source_or_numerical_acceptance',baseline_archive_sha256=digest(baseline_raw),baseline_811_rates_verified_unchanged=True,baseline_dataset_sha256={n:digest(v) for n,v in csvs.items()},accepted_rate_gain=0,accepted_window_gain=0,canonical_dataset_writes=0,production_writes=0,correction_records_sha256=digest((HERE/'correction-records.json').read_bytes()),games=results)
    write(HERE/'diagnostics.json',summary)
    print(json.dumps(dict(record_sha256=summary['correction_records_sha256'],diagnostics_sha256=digest((HERE/'diagnostics.json').read_bytes()),groups={gid:[dict(periods=g['periods'],field=g['field'],passed=g['numerical_gates_passed'],clock_errors=len(g['clock_errors']),window_errors=len(g['window_input_errors']),whole_errors=len(g['whole_input_errors']),basis_errors=g['basis_errors'],population_errors=len(g['population_errors'])) for g in v['groups']] for gid,v in results.items()}),indent=2))


if __name__=='__main__':main()
