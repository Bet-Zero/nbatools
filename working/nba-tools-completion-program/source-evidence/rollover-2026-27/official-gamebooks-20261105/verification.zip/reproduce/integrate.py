"""Integrate only independently supported data deltas; never acquire/publish."""
import csv
import hashlib
import io
import json
import shutil
from datetime import datetime
from fractions import Fraction
from pathlib import Path
from zipfile import ZipFile
import pandas as pd
from tools.qualify_rollover_q1 import _local_stage
from tools.qualify_period_rates import fresh_schedule_due
from nbatools.commands.validation_control import build_slice_manifest
from nbatools.commands.player_game_finder import build_result

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
SUFFIX='2026-27_regular_season.csv'
BASE=ROOT/'working/nba-tools-completion-program/source-evidence/rollover-2026-27/foul-anchor-20261105/qualification-evidence.zip'
sha=lambda b:hashlib.sha256(b).hexdigest()

def run():
    out=HERE/'integrated';out.mkdir(exist_ok=False)
    shutil.copytree(HERE/'0142-qualified/stage',out/'stage')
    stage=out/'stage'
    methods=json.loads((HERE/'methods-lane/diagnostics.json').read_text())
    groups=methods['games']['0022600138']['groups']
    assert len(groups)==4 and all(g['numerical_gates_passed'] for g in groups)
    with ZipFile(BASE) as z:
        baseline={n:z.read(n) for n in z.namelist() if n.startswith('stage/data/') and n.endswith('.csv')}
        old_report=json.loads(z.read('qualification.json'))
    key=f'stage/data/raw/player_game_period_stats/{SUFFIX}'
    before=list(csv.reader(io.StringIO(baseline[key].decode())))
    raw=(out/key).read_bytes();lines=raw.decode().splitlines(keepends=True)
    changed={};entries=[]
    for group in groups:
        for c in group['conditional_exact_fractions']:
            row=c['row'];field=group['field'];col=before[0].index(field)
            assert before[row+1][col]==''
            value=float(Fraction(c['exact']))
            changed.setdefault(row,list(before[row+1]))[col]=str(value)
            entries.append(dict(c,field=field,periods=group['periods'],after=value))
    assert len(entries)==104
    for row,values in changed.items():
        stream=io.StringIO();csv.writer(stream,lineterminator='\n').writerow(values);lines[row+1]=stream.getvalue()
    (out/key).write_text(''.join(lines))
    observed=list(csv.reader(io.StringIO((out/key).read_text())))
    declared={(c['row']+1,before[0].index(c['field'])) for c in entries}
    checked_tokens=0
    for i,row in enumerate(before):
        assert len(row)==len(observed[i])
        for j,v in enumerate(row):
            if (i,j) not in declared:assert observed[i][j]==v,(i,j)
            checked_tokens+=1
    # All811old fractions preserved exactly, not only approximately/rounding.
    frame=pd.read_csv(out/key,float_precision='round_trip')
    for c in old_report['changes']:assert frame.iloc[c['row']][c['field']]==c['after']
    remaining=[c for c in old_report['unknown'] if (c['row']+1,before[0].index(c['field'])) not in declared]
    assert len(remaining)==450 and len({(c['game_id'],tuple(c['periods']),c['field']) for c in remaining})==18
    for c in remaining:assert pd.isna(frame.iloc[c['row']][c['field']])
    inventory=[]
    for name,raw in baseline.items():
        current=(out/name).read_bytes()
        if name==key:pass
        elif '_game_period_stats/' in name:assert current.startswith(raw)
        else:assert current==raw
        inventory.append(dict(path=name.removeprefix('stage/'),before_sha256=sha(raw),after_sha256=sha(current),changed=current!=raw))
    # Two whole-game +/- corrections are independently corroborated by all
    # scorer quarter/half totals and separate foul-time scoring-credit replay.
    core_path=stage/f'data/raw/player_game_stats/{SUFFIX}'
    core_records=list(csv.reader(io.StringIO(core_path.read_text())))
    core_lines=core_path.read_text().splitlines(keepends=True)
    head=core_records[0];core_changes=[]
    for pid,before_value,after_value in [(1631204,13,11),(1628997,6,8)]:
        matches=[i for i,r in enumerate(core_records[1:],1) if int(r[head.index('game_id')])==22600142 and int(r[head.index('player_id')])==pid]
        assert len(matches)==1
        i=matches[0];row=core_records[i];col=head.index('plus_minus')
        assert Fraction(row[col])==before_value
        core_changes.append(dict(game_id='0022600142',player_id=pid,field='plus_minus',before_literal=row[col],after_literal=str(after_value),source_pdf_sha256='0c56c290a0225b4fefce424932c8960e37db2f5ba5637578f1ec2de00c00b629',scorer_pages_zero_index=[0,1,2,3,4,6,7]))
        row[col]=str(after_value);buffer=io.StringIO();csv.writer(buffer,lineterminator='\n').writerow(row);core_lines[i]=buffer.getvalue()
    for pid,before_seconds,after_seconds in [(1629023,1472,Fraction(7968,5)),(1631204,1439,Fraction(1317))]:
        matches=[i for i,r in enumerate(core_records[1:],1) if int(r[head.index('game_id')])==22600142 and int(r[head.index('player_id')])==pid]
        assert len(matches)==1
        i=matches[0];row=core_records[i];col=head.index('minutes')
        assert abs(Fraction(row[col])*60-before_seconds)<Fraction(1,100000000)
        after_literal=str(float(after_seconds/60))
        core_changes.append(dict(game_id='0022600142',player_id=pid,field='minutes',before_literal=row[col],after_literal=after_literal,exact_seconds=str(after_seconds),source_pdf_sha256='0c56c290a0225b4fefce424932c8960e37db2f5ba5637578f1ec2de00c00b629',scorer_pages_zero_index=[0,1,2,3,4,6,7],basis='All corrected exact quarter clocks and official full-game scorer minutes agree within original whole-second display resolution.'))
        row[col]=after_literal;buffer=io.StringIO();csv.writer(buffer,lineterminator='\n').writerow(row);core_lines[i]=buffer.getvalue()
    core_path.write_text(''.join(core_lines))
    (out/'whole-correction-records.json').write_text(json.dumps(core_changes,indent=2)+'\n')
    # General guarded cell patches from the separately qualified0009 record.
    delta=json.loads((HERE/'methods-lane/csv-cell-patches.json').read_text())
    assert len(delta['patches'])==134
    by_path={}
    for patch in delta['patches']:by_path.setdefault(patch['path'],[]).append(patch)
    restored0009=[]
    for name,patches in by_path.items():
        target_path=out/name
        records=list(csv.reader(io.StringIO(target_path.read_text())))
        current_lines=target_path.read_text().splitlines(keepends=True)
        h=records[0];touched=set()
        for patch in patches:
            assert sha(baseline[name])==patch['baseline_sha256']
            i=patch['row']+1;j=h.index(patch['field'])
            assert records[i][j]==patch['before_literal'],(name,i,j)
            for field,value in patch['key'].items():
                actual=records[i][h.index(field)]
                assert (int(actual)==int(value)) if field.endswith('_id') else actual==value
            records[i][j]=patch['after_literal'];touched.add(i)
            if name==key:
                declared.add((i,j))
                if patch['field']=='ast_pct':restored0009.append(dict(row=i-1,field='ast_pct',periods=[1] if patch['key']['period_family']=='quarter' else [1,2],after=float(patch['after_literal']),game_id='0022600009'))
        for i in touched:
            buffer=io.StringIO();csv.writer(buffer,lineterminator='\n').writerow(records[i]);current_lines[i]=buffer.getvalue()
        target_path.write_text(''.join(current_lines))
    assert len(restored0009)==38
    entries.extend(restored0009)
    frame=pd.read_csv(out/key,float_precision='round_trip')
    remaining=[c for c in old_report['unknown'] if (c['row']+1,before[0].index(c['field'])) not in declared]
    assert len(remaining)==412
    newly_unknown=delta['new_unknown_outside_original1365']
    assert len(newly_unknown)==72
    for c in remaining+newly_unknown:assert pd.isna(frame.iloc[c['row']][c['field']])
    for c in old_report['changes']:assert frame.iloc[c['row']][c['field']]==c['after']
    # Literal preservation across every original raw cell, except declared ones.
    raw_checked=0
    for name,raw in baseline.items():
        if '/raw/' not in name:continue
        original_rows=list(csv.reader(io.StringIO(raw.decode())))
        new_rows=list(csv.reader(io.StringIO((out/name).read_text())))
        h=original_rows[0]
        allowed={(r['row']+1,h.index(r['field'])) for r in delta['patches'] if r['path']==name}
        if name==key:allowed|={(c['row']+1,h.index(c['field'])) for c in entries}
        if name.endswith('/player_game_stats/'+SUFFIX):
            allowed|={(i,h.index(c['field'])) for c in core_changes for i,r in enumerate(original_rows[1:],1) if int(r[h.index('game_id')])==22600142 and int(r[h.index('player_id')])==c['player_id']}
        for i,row in enumerate(original_rows):
            for j,value in enumerate(row):
                if (i,j) not in allowed:assert new_rows[i][j]==value,(name,i,j)
                raw_checked+=1
    (out/'0009-cell-patches.json').write_bytes((HERE/'methods-lane/csv-cell-patches.json').read_bytes())
    from nbatools.commands.pipeline import build_team_game_features, build_game_features, build_schedule_context_features, build_player_game_features, build_league_season_stats
    builders=[]
    with _local_stage(stage):
        for builder in [build_team_game_features,build_game_features,build_schedule_context_features,build_player_game_features,build_league_season_stats]:
            builder.run('2026-27','Regular Season')
            builders.append(dict(builder=builder.__name__,state='passed'))
    # Preserve all undeclared original cells; builder byte changes are disclosed.
    core_before=list(csv.reader(io.StringIO(baseline[f'stage/data/raw/player_game_stats/{SUFFIX}'].decode())))
    core_after=list(csv.reader(io.StringIO(core_path.read_text())))
    changed_core={(i,j) for i,r in enumerate(core_before) for j,v in enumerate(r) if core_after[i][j]!=v}
    assert len(changed_core)==19
    inventory=[dict(path=name.removeprefix('stage/'),before_sha256=sha(raw),after_sha256=sha((out/name).read_bytes()),changed=(out/name).read_bytes()!=raw) for name,raw in baseline.items()]
    checked_at=datetime.fromisoformat('2026-11-05T06:59:31.715470+00:00')
    with _local_stage(stage):
        assessment=build_slice_manifest('2026-27','Regular Season',data_root=stage/'data',generation_id='unpublished-official-gamebooks-v1-20261105')
        due=fresh_schedule_due(stage,checked_at)
        consumers=[]
        for player,window,expected in [
            ('Caleb Martin',dict(quarter='3'),dict(pts=2,fgm=1,fga=1)),
            ('Caleb Martin',dict(half='second'),dict(pts=7,fgm=3,fga=4)),
            ('Marcus Sasser',dict(quarter='3'),dict(pts=0,minutes=1.7)),
            ('Oscar Tshiebwe',dict(quarter='4'),dict(reb_pct=float(Fraction(1,7)),usg_pct=float(Fraction(1,9)))),
            ('Kevin Durant',dict(quarter='1'),dict(ast=2,ast_pct=float(Fraction(2,9)))),
            ('Kevin Durant',dict(half='first'),dict(ast=2,ast_pct=float(Fraction(2,15)))),
        ]:
            answer=build_result(player=player,season='2026-27',**window)
            assert answer.result_status=='ok',(player,answer.result_status)
            target=None
            gid=22600009 if player=='Kevin Durant' else 22600138 if player=='Oscar Tshiebwe' else 22600142
            selected=answer.games.loc[answer.games.game_id.eq(gid)]
            assert len(selected)==1,(player,len(selected))
            row=selected.iloc[0]
            for f,v in expected.items():assert abs(row[f]-v)<1e-12,(player,f,row[f],v)
            consumers.append(dict(player=player,window=window,game_id=gid,expected=expected,actual=selected.to_dict('records')))
    report=dict(classification='unpublished_official_gamebook_normalized_dataset',generation='unpublished-official-gamebooks-v1-20261105',original_withheld=1365,previously_qualified=811,restored=142,qualified=953,unknown=484,original_population_unknown=412,newly_unknown=72,unknown_groups=20,remaining_unknown_keys=remaining+newly_unknown,rate_changes=entries,raw_tokens_preserved_except_declared=raw_checked,game0142_windows='Q3 and H2 complete',added_player_rows=48,added_team_rows=4,required_windows=647,observed_windows=647,checked_existing_csv_tokens=checked_tokens,all811preserved=True,dataset_inventory=inventory,dataset_assessment=assessment,due_population=due,consumers=consumers,whole_corrections=core_changes,builders=builders,reported_rates_or_possessions_used_as_oracle=False,production_writes=0,full_numerical_readiness=False)
    (out/'qualification.json').write_text(json.dumps(report,indent=2,default=str)+'\n')
    print(json.dumps({k:report[k] for k in ['qualified','unknown','unknown_groups','observed_windows','added_player_rows','added_team_rows','checked_existing_csv_tokens']},indent=2))
    print('assessment',str(assessment)[:1600])
if __name__=='__main__':run()
