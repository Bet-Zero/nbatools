"""Portable data packaging only: deterministic archives, no fetch or publication."""
import csv
import hashlib
import io
import json
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED
import pandas as pd
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
OUT=ROOT/'working/nba-tools-completion-program/source-evidence/rollover-2026-27/official-gamebooks-20261105'
sha=lambda b:hashlib.sha256(b).hexdigest()
def render(x):return (json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode()
def archive(path,files):
    with ZipFile(path,'w',ZIP_DEFLATED) as z:
        for name,raw in sorted(files.items()):
            info=ZipInfo(name,date_time=(2026,11,5,0,0,0));info.compress_type=ZIP_DEFLATED
            z.writestr(info,raw)

def run():
    report=json.loads((HERE/'integrated/qualification.json').read_text())
    data={p.relative_to(HERE/'integrated/stage').as_posix():p.read_bytes() for p in (HERE/'integrated/stage/data').rglob('*.csv')}
    assert len(data)==16
    raw_frame=pd.read_csv(io.BytesIO(data['data/raw/player_game_period_stats/2026-27_regular_season.csv']),float_precision='round_trip')
    unknown=[]
    for c in report['remaining_unknown_keys']:
        row=raw_frame.iloc[c['row']]
        assert pd.isna(row[c['field']])
        unknown.append(dict(game_id=str(int(row.game_id)).zfill(10),team_id=int(row.team_id),player_id=int(row.player_id),period_family=row.period_family,period_value=str(row.period_value),field=c['field'],reason=c.get('reason','0009 one-shot award association/credit is not established'),original_1365_member=c.get('original_1365_member',True)))
    assert len(unknown)==484 and len({(r['game_id'],r['period_family'],r['period_value'],r['field']) for r in unknown})==20
    provenance=[]
    for p in sorted((HERE/'capture/acquired_data/official-gamebooks-20261105').rglob('capture.json')):
        r=json.loads(p.read_text());assert sha((p.parent/r['raw_file']).read_bytes())==r['sha256'];provenance.append(r)
    docs=json.loads((HERE/'methods-lane/correction-records.json').read_text())
    data['lineage/event-corrections.json']=render(docs+[json.loads((HERE/'0142-qualified/correction-record.json').read_text())])
    data['lineage/0009-cell-corrections.json']=(HERE/'methods-lane/csv-cell-patches.json').read_bytes()
    data['lineage/0142-whole-corrections.json']=(HERE/'integrated/whole-correction-records.json').read_bytes()
    qualified_rate_records=[]
    for item in report['rate_changes']:
        row=raw_frame.iloc[item['row']]
        qualified_rate_records.append(dict(item,game_id=str(int(row.game_id)).zfill(10),period_family=row.period_family,period_value=str(row.period_value),team_id=int(row.team_id),player_id=int(row.player_id),before_canonical=None))
    data['lineage/restored-rate-corrections.json']=render(qualified_rate_records)
    for gid in ['0022600009','0022600138']:
        data[f'canonical_events/{gid}.json']=(HERE/f'methods-lane/{gid}/conditional-canonical-events.json').read_bytes()
        data[f'lineage/{gid}-event-id-map.json']=(HERE/f'methods-lane/{gid}/identity-map.json').read_bytes()
    data['canonical_events/0022600142.json']=(HERE/'0142-qualified/canonical-events.json').read_bytes()
    data['lineage/unknown-rate-keys.json']=render(unknown)
    data['lineage/official-source-provenance.json']=render(provenance)
    manifest=dict(schema_version=1,dataset_id='nba-2026-27-normalized-official-gamebooks-v1-20261105',state='unpublished_development_snapshot',season='2026-27',season_type='Regular Season',historical_validation_cutoff_utc='2026-11-05T06:59:31.715470Z',observed_games=107,standard_and_overtime_windows=647,current_24_hour_freshness_accepted=False,full_numerical_readiness=False,production_published=False,original_withheld_population=1365,original_population_qualified=953,original_population_unknown=412,newly_unknown=72,total_explicit_unknown_rates=484,unknown_groups=20,prior811qualified_rates_preserved=True,required_structural_datasets_passed=16,original_capture_archive=dict(file='original-capture.zip',sha256='8ff6e2052f89cf6e0070aee22c5fcee4c83edc7a285a6d7f4c6209135e8b7190',git_blob='27969ff1d381ce857b3f39d830685cd990fcf409'),parent_stage=dict(repository='Bet-Zero/nbatools',revision='cd47ab9d4ff3edb00e17c1a21b414213fc0076ad',git_blob='27c8cfb2f8232dfd6cfe633cc6d6971535a3d652',sha256='3981e4e459daedee069a30ac49dc84c69078ddb2efb244f07d57b3aa596e076c'),rate_units='ast_pct, reb_pct, tov_pct and usg_pct are fractions, with explicit nulls for unknown inputs; zero-duration contract rows retain zero',numeric_scope='Field-scoped official scorer/PBP corrections and rate oracles. Structural passes do not certify every retained Advanced or derived field or complete current-season freshness.',source_generation_independence='Unestablished; field-specific official scorer authority and complete independent arithmetic do not prove a different upstream observer.',files=[dict(path=n,sha256=sha(b),size_bytes=len(b),**({'rows':len(list(csv.reader(io.StringIO(b.decode()))))-1} if n.endswith('.csv') else {})) for n,b in sorted(data.items())])
    data['dataset-manifest.json']=render(manifest)
    data['README.txt']=('This is a portable, unpublished NBA dataset snapshot. Load the sixteen CSV files with any CSV tool; no NBA Tools runtime or historical correction logic is required. Legacy raw/ paths contain normalized canonical tables, not the original HTTP bodies. Originals and capture receipts are preserved separately in original-capture.zip; original event copies and independent verification are in verification.zip. Canonical event copies and keyed correction/unknown records are included here. All original values outside declared corrections survive; only qualified data is changed. The snapshot has 647 validated period windows but still withholds 484 rate cells. Do not interpret historical coverage or structural validation as full numerical/current-data readiness or permission to publish. See dataset-manifest.json for the exact population, units, hashes and limits.\n').encode()
    archive(OUT/'normalized-snapshot.zip',data)
    (OUT/'dataset-manifest.json').write_bytes(render(manifest))
    (OUT/'remaining-dependencies.json').write_bytes(render(dict(original_dependency_ledger_revision='cd47ab9d4ff3edb00e17c1a21b414213fc0076ad',original_dependency_ledger_blob='622798e90c42470a950016f8f79170a13f298dbc',unknown_rates=unknown,shared_missing_method='Attributable NBA/scorer/provider TOV trip and USG use/exposure credit definitions for take/flagrant/retained-possession/canceled awards, including canceled FT plus turnover joint credit.',event_0118='Complete adjudication/award record for Q4 1:10 miss1of2, lane-violation turnover and absent2of2.',event_0009='Scorer-confirmed award association/credit for Q1 Eason madeFG2:15 and one-shotFT2:06; preserve both literal clocks.')))
    print('normalized snapshot', (OUT/'normalized-snapshot.zip').stat().st_size,sha((OUT/'normalized-snapshot.zip').read_bytes()))
if __name__=='__main__':run()
