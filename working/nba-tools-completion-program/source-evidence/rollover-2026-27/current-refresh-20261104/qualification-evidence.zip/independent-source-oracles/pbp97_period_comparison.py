import json,zipfile,hashlib
from fractions import Fraction as F
from pathlib import Path
E=Path('working/nba-tools-completion-program/source-evidence/rollover-2026-27');O=Path('work/checker');audit=json.loads((O/'pbp97-clock-oracle.json').read_text());terms=audit['all_player_period_clock_terms'];rows=[]
for archive in ['partial-capture-20261103/collection.zip','recovery-capture-20261104/collection.zip']:
 with zipfile.ZipFile(E/archive) as z:
  acquisition=json.loads(z.read('acquisition.json'))
  for a in acquisition['attempts']:
   if a['http_status']!=200:continue
   j=a['job'];p=j['parameters'];endpoint=j['endpoint']
   if endpoint not in ['boxscoretraditionalv3','boxscoreadvancedv3'] or p.get('GameID')!='0022600097' or str(p.get('RangeType'))!='1' or (int(p['StartPeriod']),int(p['EndPeriod'])) not in [(4,4),(3,4)]:continue
   raw=z.read(j['source_file']);d=json.loads(raw)['boxScoreTraditional' if endpoint=='boxscoretraditionalv3' else 'boxScoreAdvanced']
   for side in ['homeTeam','awayTeam']:
    team=d[side];tid=team['teamId'];subset=[t for t in terms if t['team_id']==tid and int(p['StartPeriod'])<=t['period']<=int(p['EndPeriod'])];seconds={}
    for t in subset:seconds[t['player_id']]=seconds.get(t['player_id'],F(0))+F(t['exact_seconds'])
    positive={pid:v for pid,v in seconds.items() if v>0};src={player['personId']:player for player in team['players']};sourcekeys=set(src);expectedkeys=set(positive);changes=[];totalold=F(0)
    for pid,player in src.items():
     token=player['statistics']['minutes'];m,s=token.split(':');original=60*int(m)+F(s);totalold+=original
     if original!=seconds.get(pid,F(0)):changes.append({'player_id':pid,'name':player['firstName']+' '+player['familyName'],'original_clock':token,'original_seconds':str(original),'PBP_exact_seconds':str(seconds.get(pid,F(0))),'difference_original_minus_PBP':str(original-seconds.get(pid,F(0)))})
    rows.append({'endpoint':endpoint,'period':[int(p['StartPeriod']),int(p['EndPeriod'])],'team_id':tid,'source':{'archive':archive,'member':j['source_file'],'sha256':hashlib.sha256(raw).hexdigest()},'source_player_count':len(sourcekeys),'PBP_positive_player_count':len(expectedkeys),'exact_positive_identity_match':sourcekeys==expectedkeys,'PBP_missing_in_source':sorted(expectedkeys-sourcekeys),'source_missing_in_PBP':sorted(sourcekeys-expectedkeys),'original_player_seconds':str(totalold),'PBP_player_seconds':str(sum(positive.values())),'expected_team_seconds':3600*(int(p['EndPeriod'])-int(p['StartPeriod'])+1),'changed_cells':changes})
assert len(rows)==8
report={'checker':'/root/recovery_checker','scope':'independent exact PBP97Q4/H2 duration and positive identity comparisons against both original endpoint bodies; no source edits','PBP_source_sha256':audit['PBP_sha256'],'whole_POS_identity_source':audit['whole_role_identity_source'],'rows':rows,'all_identity_sets_match':all(r['exact_positive_identity_match'] for r in rows),'all_PBP_team_clocks_exact':all(F(r['PBP_player_seconds'])==r['expected_team_seconds'] for r in rows),'accepted_cells_changed':0,'production_writes':0};(O/'pbp97-period-comparison.json').write_text(json.dumps(report,indent=2)+'\n');print('sha',hashlib.sha256((O/'pbp97-period-comparison.json').read_bytes()).hexdigest());print(json.dumps(rows,indent=2))
