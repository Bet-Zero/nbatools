"""Bounded independent PBP116Q1 arithmetic oracle; not production implementation."""
import json,hashlib,zipfile,re,copy
from pathlib import Path
from fractions import Fraction as F
E=Path('working/nba-tools-completion-program/source-evidence/rollover-2026-27');O=Path('work/checker');sha=lambda b:hashlib.sha256(b).hexdigest()
r=json.loads((O/'source-oracles.json').read_text());refs=r['restricted_usage']['all_observations'][0]['sources'];roots={}
for endpoint,ref in refs.items():
 with zipfile.ZipFile(E/ref['archive']) as z:
  b=z.read(ref['member']);assert sha(b)==ref['sha256'];roots[endpoint]=json.loads(b)['boxScoreTraditional' if endpoint=='boxscoretraditionalv3' else 'boxScoreAdvanced']
raw=Path('work/current-sources/playbyplayv3-0022600116.json').read_bytes();pbp=json.loads(raw);assert pbp['game']['gameId']=='0022600116';actions=[a for a in pbp['game']['actions'] if a['period']==1];tid=1610612746
tr=next(v for v in [roots['boxscoretraditionalv3']['homeTeam'],roots['boxscoretraditionalv3']['awayTeam']] if v['teamId']==tid);adv=next(v for v in [roots['boxscoreadvancedv3']['homeTeam'],roots['boxscoreadvancedv3']['awayTeam']] if v['teamId']==tid);players={p['personId']:p for p in tr['players']};astats={p['personId']:p['statistics'] for p in adv['players']};initial={p['personId'] for p in players.values() if p['position']};assert len(initial)==5
assert tr['statistics']['freeThrowsAttempted']==0 and tr['statistics']['reboundsOffensive']==0

def clock(a):
 m=re.fullmatch(r'PT(\d+)M([\d.]+)S',a['clock']);assert m,a['clock'];return 60*int(m[1])+F(m[2])
def incoming(name,roster):
 # Only exact full family name or exact first initial + family name of same team.
 found=[pid for pid,p in roster.items() if name==p['familyName'] or name==p['nameI']]
 assert len(found)==1,('ambiguous incoming identity',name,found)
 return found[0]
def derive(seq,roster=players):
 lineup=set(initial);last=F(720);den={pid:0 for pid in players};num={pid:0 for pid in players};secs={pid:F(0) for pid in players};events=[];subs=[];fga={pid:0 for pid in players};tov={pid:0 for pid in players};fta=0;oreb=0
 for a in seq:
  now=clock(a);assert 0<=now<=last,('nonmonotone clock',a['actionNumber'],now,last)
  assert len(lineup)==5
  for pid in lineup:secs[pid]+=last-now
  last=now
  if a['teamId']!=tid:continue
  if a['actionType']=='Substitution':
   m=re.fullmatch(r'SUB: (.+) FOR (.+)',a['description']);assert m
   out=a['personId'];assert out in lineup,(out,lineup)
   inc=incoming(m[1],roster);assert inc not in lineup
   lineup.remove(out);lineup.add(inc);assert len(lineup)==5
   subs.append({'action_number':a['actionNumber'],'clock':a['clock'],'out':out,'incoming':inc,'description':a['description']});continue
  if a['actionType']=='Free Throw':fta+=1
  if a['actionType']=='Rebound' and re.search(r'Off:[1-9]',a['description']):oreb+=1
  if a['isFieldGoal'] or a['actionType']=='Turnover':
   pid=a['personId'];assert pid in lineup,(a,lineup)
   for member in lineup:den[member]+=1
   num[pid]+=1
   (fga if a['isFieldGoal'] else tov)[pid]+=1
   events.append({'action_number':a['actionNumber'],'clock':a['clock'],'type':a['actionType'],'player_id':pid,'on_floor':sorted(lineup),'description':a['description']})
 assert last==0 and fta==0 and oreb==0
 return den,num,secs,events,subs,fga,tov

den,num,secs,events,subs,fgas,tovs=derive(actions);cases=[]
for pid,p in players.items():
 ps=p['statistics'];assert (fgas[pid],tovs[pid])==(ps['fieldGoalsAttempted'],ps['turnovers'])
 literal=ps['minutes'].split(':');source_seconds=60*int(literal[0])+F(literal[1]);assert secs[pid]==source_seconds
 expected=F(num[pid],den[pid]) if den[pid] else F(0);actual=F(str(astats[pid]['usagePercentage']))
 corrupt=actual+F(1,500)
 cases.append({'player_id':pid,'name':p['firstName']+' '+p['familyName'],'minutes_exact_seconds':str(secs[pid]),'fga':fgas[pid],'tov':tovs[pid],'numerator':num[pid],'independent_on_floor_team_FGA_TOV_denominator':den[pid],'independent_usage_exact':str(expected),'source_usage':str(actual),'source_advanced_possessions_NOT_used_as_denominator':astats[pid]['possessions'],'passed_unchanged_halfstep':abs(expected-actual)<=F(1,2000),'corruption_plus_002_rejected':abs(expected-corrupt)>F(1,2000)})
controls=[]
try:derive(sorted(actions,key=lambda a:a['actionNumber']))
except AssertionError as e:controls.append({'mutation':'sort actions by actionNumber (misplaces retroactively inserted163)','rejected':True,'reason':str(e)})
mut=copy.deepcopy(actions);a=next(a for a in mut if a['teamId']==tid and a['actionType']=='Substitution');a['personId']=1641711
try:derive(mut)
except AssertionError as e:controls.append({'mutation':'sub outgoing player not on floor','rejected':True,'reason':str(e)})
roster=copy.deepcopy(players);roster[999999]=dict(roster[1643413]);roster[999999]['personId']=999999
try:derive(actions,roster)
except AssertionError as e:controls.append({'mutation':'same-team incoming name duplicated','rejected':True,'reason':str(e)})
assert len(controls)==3
out={'checker':'/root/recovery_checker','scope':'independent full Q1 LAC on-floor NBA usage oracle from retained PBP116 plus original paired period source; not all-player/season USG acceptance','game_id':'0022600116','team_id':tid,'period':1,'PBP_sha256':sha(raw),'paired_source_refs':refs,'starter_POS_source':'same original Traditional Q1 body, exactly5nonblank positions','event_order':'original chronological array with nonincreasing validated clock, preserving original same-clock sequence; actionNumber not sorting key','initial_players':sorted(initial),'substitutions':subs,'team_FGA':sum(fgas.values()),'team_TOV':sum(tovs.values()),'team_FTA':0,'team_OREB':0,'formula':'(player FGA+playerTOV)/(count of own-teamFGA+TOV events while player on floor), only this zeroFTA/OREB source scope','unchanged_source_rate_halfstep':'1/2000 inclusive','cases':cases,'event_lineups':events,'controls':controls,'case_count':len(cases),'all_pass':all(c['passed_unchanged_halfstep'] for c in cases),'production_writes':0,'accepted_cells_changed':0}
(O/'pbp116-usage-oracle.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'sha256':sha((O/'pbp116-usage-oracle.json').read_bytes()),'cases':cases,'controls':controls},indent=2))
