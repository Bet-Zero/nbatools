import json,hashlib,collections
from pathlib import Path
sha=lambda b:hashlib.sha256(b).hexdigest();O=Path('work/checker')
targets={118:[1643409,1642907,203924,1627734],142:[1628997],144:[1630552]};out=[]
for num,pids in targets.items():
 path=Path(f'work/current-sources/playbyplayv3-0022600{num:03d}.json');raw=path.read_bytes();body=json.loads(raw)['game'];assert body['gameId']==f'0022600{num:03d}';allactions=body['actions'];byplayer={pid:collections.Counter() for pid in pids};periods={pid:collections.defaultdict(collections.Counter) for pid in pids};events={pid:[] for pid in pids}
 for a in allactions:
  pid=a['personId']
  if pid not in pids:continue
  delta=collections.Counter();kind=a['actionType'];fg=a['isFieldGoal'];description=a['description']
  if fg:
   assert kind in ['Made Shot','Missed Shot'];assert a['shotValue'] in [2,3]
   delta['fga']=1
   if a['shotValue']==3:delta['fg3a']=1
   if kind=='Made Shot':
    delta['fgm']=1;delta['pts']=a['shotValue']
    if a['shotValue']==3:delta['fg3m']=1
  if kind=='Free Throw':
   delta['fta']=1
   if not description.startswith('MISS '):delta['ftm']=1;delta['pts']=1
  if kind=='Turnover':delta['tov']=1
  if delta:
   byplayer[pid].update(delta);periods[pid][a['period']].update(delta);events[pid].append({k:a[k] for k in ['actionNumber','period','clock','teamId','personId','description','actionType','shotValue','isFieldGoal','shotResult']})
 for pid in pids:
  out.append({'game_id':body['gameId'],'player_id':pid,'PBP_source':str(path),'PBP_sha256':sha(raw),'counts':dict(byplayer[pid]),'period_counts':{str(k):dict(v) for k,v in periods[pid].items()},'events':events[pid]})
report={'checker':'/root/recovery_checker','scope':'independent PBP field-goal/free-throw/turnover event counts for contested selected player cells; original rows unchanged','method':'isFieldGoal rows classify Made/Missed and shotValue; FreeThrow rows classify MISS prefix; actual player IDs only; no team or scorer reassignments','players':out,'accepted_cells_changed':0,'production_writes':0};(O/'pbp-scorer-oracles.json').write_text(json.dumps(report,indent=2)+'\n');print('sha256',sha((O/'pbp-scorer-oracles.json').read_bytes()))
for r in out:print(r['game_id'],r['player_id'],r['counts'],r['period_counts'])
