"""Independent bounded game142 clock oracle; no stored data or source edits."""
import json,zipfile,hashlib,re,collections
from pathlib import Path
from fractions import Fraction as F
O=Path('work/checker');E=Path('working/nba-tools-completion-program/source-evidence/rollover-2026-27');r=json.loads((O/'source-oracles.json').read_text());raw=Path('work/current-sources/playbyplayv3-0022600142.json').read_bytes();pbp=json.loads(raw)['game'];assert pbp['gameId']=='0022600142';refs={}
with zipfile.ZipFile(E/'recovery-capture-20261104/collection.zip') as z:
 jobs=json.loads(z.read('acquisition.json'))['request']['jobs'];job=next(j for j in jobs if j['endpoint']=='boxscoretraditionalv3' and j['parameters']['GameID']=='0022600142' and str(j['parameters']['RangeType'])=='0');whole=z.read(job['source_file']);d=json.loads(whole)['boxScoreTraditional'];whole_ref={'archive':'recovery-capture-20261104/collection.zip','member':job['source_file'],'sha256':hashlib.sha256(whole).hexdigest(),'grain':'POS and player identity only; no whole clocks used'}
roster={};periodteams={}
for period in range(1,5):
 for side in ['homeTeam','awayTeam']:
  team=d[side];tid=team['teamId'];periodteams[period,tid]=team
  for player in team['players']:roster[tid,player['personId']]=player

def inc(name,tid):
 matches=[pid for (team,pid),p in roster.items() if team==tid and name in [p['familyName'],p['nameI']]]
 assert len(matches)==1,(name,matches)
 return matches[0]
def clock(a):
 m=re.fullmatch(r'PT(\d+)M([\d.]+)S',a['clock']);assert m;return 60*int(m[1])+F(m[2])
seconds=collections.defaultdict(F);terms=[];initials=[]
for period in range(1,5):
 actions=[a for a in pbp['actions'] if a['period']==period]
 assert actions and clock(actions[0])==720 and clock(actions[-1])==0
 for tid in {tid for p,tid in periodteams if p==period}:
  team=periodteams[period,tid];players={p['personId'] for p in team['players']};first={};subs=[]
  for a in actions:
   if a['teamId']==tid and a['actionType']=='Substitution':
    m=re.fullmatch(r'SUB: (.+) FOR (.+)',a['description']);assert m
    out=a['personId'];incoming=inc(m[1],tid);first.setdefault(out,'out');first.setdefault(incoming,'in');subs.append((a,out,incoming))
  initial={pid for pid in players if first.get(pid)=='out'}
  if period==1:initial={p['personId'] for p in team['players'] if p['position']}
  else:
   initial|={a['personId'] for a in actions if a['teamId']==tid and a['personId'] in players and a['personId'] not in first and a['actionType'] in ['Made Shot','Missed Shot','Free Throw','Turnover','Rebound','Foul']}
  assert len(initial)==5,(period,tid,initial)
  lineup=set(initial);last=F(720);quarter=collections.defaultdict(F);initials.append({'period':period,'team_id':tid,'initial_players':sorted(initial),'basis':'Q1 nonblank originalPOS; later first-substitution outgoing plus no-substitution actual event actors; exactly5 required; incoming unique same-team names'})
  for a in actions:
   now=clock(a);assert now<=last
   for pid in lineup:quarter[pid]+=last-now
   last=now
   if a['teamId']==tid and a['actionType']=='Substitution':
    m=re.fullmatch(r'SUB: (.+) FOR (.+)',a['description']);out=a['personId'];incoming=inc(m[1],tid);assert out in lineup and incoming not in lineup,(period,tid,a,lineup,incoming)
    lineup.remove(out);lineup.add(incoming);assert len(lineup)==5
   # Every primary shot/turnover/foul/rebound actor present, except team events/person0.
   elif a['teamId']==tid and a['personId'] in players and a['actionType'] in ['Made Shot','Missed Shot','Free Throw','Turnover','Rebound','Foul']:
    assert a['personId'] in lineup,(period,tid,a)
  assert sum(quarter.values())==3600
  for pid,secs in quarter.items():seconds[tid,pid]+=secs;terms.append({'period':period,'team_id':tid,'player_id':pid,'exact_seconds':str(secs)})
targets=[]
for row in r['target_game_rows']:
 if row['game_id']!=22600142:continue
 tid,pid=row['team_id'],row['player_id'];s=seconds[tid,pid];targets.append({'team_id':tid,'player_id':pid,'name':row['player_name'],'accepted_minute_token':row['accepted_minute_token'],'accepted_seconds':str(F(row['accepted_minute_token'])*60),'PBP_exact_seconds':str(s),'PBP_exact_minutes':str(s/60),'primary_minutes':row['primary_minute_raw'],'agrees_primary_within_serialization':abs(s-F(str(row['primary_minute_raw']))*60)<F(1,10**9)})
out={'checker':'/root/recovery_checker','scope':'independent exact substitution-clock sums for game142; source intervals/other games not replaced','game_id':'0022600142','PBP_sha256':hashlib.sha256(raw).hexdigest(),'whole_role_identity_source':whole_ref,'period_initials':initials,'all_player_period_clock_terms':terms,'target_cells':targets,'accepted_cells_changed':0,'production_writes':0};(O/'pbp142-clock-oracle.json').write_text(json.dumps(out,indent=2)+'\n');print('sha',hashlib.sha256((O/'pbp142-clock-oracle.json').read_bytes()).hexdigest());print(json.dumps(targets,indent=2))
