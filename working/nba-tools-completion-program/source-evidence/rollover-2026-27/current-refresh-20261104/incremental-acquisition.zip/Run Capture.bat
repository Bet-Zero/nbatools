@echo off
cd /d "%~dp0"
call :try_python python3 && goto done
call :try_python python && goto done
py -3 -c "import nba_api" >nul 2>&1
if not errorlevel 1 (
    py -3 run_capture.py
    goto done
)
if defined VIRTUAL_ENV call :try_python "%VIRTUAL_ENV%\Scripts\python.exe" && goto done
call :try_python "%~dp0.venv\Scripts\python.exe" && goto done
call :try_python "%~dp0venv\Scripts\python.exe" && goto done
call :try_python "%~dp0..\.venv\Scripts\python.exe" && goto done
call :try_python "%~dp0..\venv\Scripts\python.exe" && goto done
python3 run_capture.py
goto done
:try_python
"%~1" -c "import nba_api" >nul 2>&1
if errorlevel 1 exit /b 1
"%~1" run_capture.py
exit /b 0
:done
echo.
echo Return readiness-refresh\current-run.zip, including after a failure.
pause
