#!/bin/sh
cd -- "$(dirname -- "$0")" || exit 1
found=0
# Preserve the proven PATH route first, then check only finite existing environments.
set -- python3 python
if [ -n "${VIRTUAL_ENV:-}" ]; then
    set -- "$@" "$VIRTUAL_ENV/bin/python"
fi
for runtime in "$@" ".venv/bin/python" "venv/bin/python"     "../.venv/bin/python" "../venv/bin/python"; do
    if "$runtime" -c 'import nba_api' >/dev/null 2>&1; then
        "$runtime" run_capture.py
        found=1
        break
    fi
done
if [ "$found" -eq 0 ]; then
    python3 run_capture.py
fi
printf '\nReturn readiness-refresh/current-run.zip, including after a failure.\n'
printf 'Press Return to close.'
read -r ignored
