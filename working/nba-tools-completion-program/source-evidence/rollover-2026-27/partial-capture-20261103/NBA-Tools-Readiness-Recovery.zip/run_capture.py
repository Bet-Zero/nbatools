"""Build/run a finite acquisition-only package with the laptop's existing nba_api.

Cloud usage: build_package(request, destination) embeds the reviewed request in
one standalone Python file. The generated file needs no NBA Tools checkout,
parameters, source selection, credentials or installation on the laptop.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import io
import json
import re
import time
import zipfile
import zlib
from datetime import UTC, datetime
from importlib.metadata import version
from pathlib import Path

# Replaced only by the cloud packaging function, never by laptop configuration.
EMBEDDED_REQUEST = json.loads(zlib.decompress(base64.b64decode(
    'eJztnW1z20aWhf8Ki19HsgF0gwSUT5lkdidVSexyXDO1lU2xGkBTYkIRDADK1qTy36dBUlIrRrud'
    'rbuPa6s2XyzwBbwHp3HvQ8Xu89vcDIO93Q/9am+71c9tNb9KL+aV6e3q2u5sZ4ZNu5tfzc2d2WxN'
    'tdluhvvLra26dnfZW9O7P+7SyyzJFmmi0vn5rbdmt1nbflj1NybLF+79KlmqRa5MnhTLzOg6y6sq'
    'X6paVbpOcp3YhVVZom3hnjN2nde5LmyVNet1apN6rdyZ68PQrter+sbWv9hmZQZ32vGDL9P0MlFv'
    'k/Iqy67y5MUyz7Oy+EuSXCWJe1tzsKvTW/3XZ8HXrzfv3dk/fMco7trc2tWm6edXP86TJMsWiftv'
    'fOLxIPMPlH+g/YPcP1j4B0v/oPAPSu8g9U+Q+idI/ROk/glS/wRZ4h/4EjJfQuZLyHwJhV9B4VdQ'
    '+BUUfgWFX0HpV1D6FZR+BaVfQelXUPoVlH4FpV9B6VdQehWkSeIfpP5B5h8o/0D7B7l/sPAPlv5B'
    '4R/4FaR+BalfQepXkPoVpH4F/jpI/XWQ+usg9ddB6q+D1F8Hqb8OUn8dpP46SP11kGZ+BZlfQeZX'
    'kPkVZH4Fyq9A+RUovwLlV6D8CpRfgfIrUH4Fyq9A+RVovwLtV6D9CrRfgfYr0H4F2q9A+xVovwLt'
    'V5D7FeR+BblfQe5XkPsV5H4FuV9Bvpz/dDF3jX1sWr/N7a7Zt5vd2Dur9n1ft501zZ3Z1ba5G8++'
    'N53rcYPt3Mt/m/9t17y23aZtjlPBHb0xu2s7v8qKIkku5v/pXvrN1+5Uz1bg8TVv7/f2+KYfBtMN'
    '3kmOx+fTJL9fzPv20NV2td5s3QPno/7lh7Wtnj5j9Wv64mc3eea/X0wKGjrTbMa5ZbYf15RJaMr+'
    'rKZn5T2TlX1U1qf59Hk0BXz6uKBP9klJaFJyPikBnz6PpoBPHxf0yT5pCU1azict4NPn0RTw6eOC'
    '2L73p3t50Kebj7dzsO8JzaeIIPZ+kut7NxLz6fNoCvgkNJ8+jY2WzP20jOGRJO9Ja5ryKSpIuO9F'
    'NEnx3pLkPWlNAZ9Q3otokup7S5L3pDUFfEJ5L6JJiveWJO9Jawr4hPIeNp9A3mPmE8t7WN8DeY/p'
    'eyzvFcz9VJC8J61pyqeoIOG+F9EkxXsFyXvSmgI+obwX0STV9wqS96Q1BXxCeS+iSYr3CpL3pDUF'
    'fEJ5D5tPIO8x84nlPazvgbzH9D2W90rmfipJ3pPWNOVTVJBw34tokuK9kuQ9aU0Bn1Dei2iS6nsl'
    'yXvSmgI+obwX0STFeyXJe9KaAj6hvIfNJ5D3mPnE8h7W90DeY/oeynvHvzn5v38/ZQnIe+KaJnyK'
    'C5LtezFNQrw3ysJ4T1xTwCeS92KahPreKAvjPXFNAZ9I3otpEuK9URbGe+KaAj6RvMfNJ473oPmE'
    '8h7X9zjeg/qeGO+JiMrFjGoHCeD7PKKmnYooEibzlOl8KUnm0pqmfIoKEp5QEU1SZJ6SZC6tKeAT'
    'SuYRTVITKiXJXFpTwCeUzCOapMg8JclcWlPAJ5TMsfkEkjkzn1gyx/oeSOZM32N/E5sx91NG8p60'
    'pimfooKE+15EkxTvZSTvSWsK+ITyXkSTVN/LSN6T1hTwCeW9iCYp3stI3pPWFPAJ5T1sPoG8x8wn'
    'lvewvgfyHtP3WN5TzP2kSN6T1jTlU1SQcN+LaJLiPUXynrSmgE8o70U0SfU9RfKetKaATyjvRTRJ'
    '8Z4ieU9aU8AnlPew+QTyHjOfWN7D+h7Ie0zfY3lPM/eTJnlPWtOUT1FBwn0vokmK9zTJe9KaAj6h'
    'vBfRJNX3NMl70poCPqG8F9EkxXua5D1pTQGfUN7D5hPIe8x8YnkP63sg7zF9j+W9nLmfcpL3pDVN'
    '+RQVJNz3IpqkeC8neU9aU8AnlPcimqT6Xk7ynrSmgE8o70U0SfFeTvKetKaATyjvYfMJ5D1mPrG8'
    'h/U9kPeYvsfyHrPTfBYNDpHkPWCn+bgg4b7HJKFkZBKKuKaATyjvMYkAGZmEIq4p4BPKe0wSSkYm'
    'oYhrCviE8h42n0DeY+YTy3tY3wN5j+l7LO8xO81nZBKKuKYpn+AklJgmKd4jk1DENQV8QnmPSQTI'
    'yCQUcU0Bn1DeY5JQMjIJRVxTwCeU97D5BPIeM59Y3sP6Hsh7TN9jeY/ZaT4jk1DENU35BCehxDRJ'
    '8R6ZhCKuKeATyntMIkBGJqGIawr4hPIek4SSkUko4poCPqG8h80nkPeY+cTyHtb3QN5j+h7Le8xO'
    '8xmZhCKuaconOAklpkmK98gkFHFNAZ9Q3mMSATIyCUVcU8AnlPeYJJSMTEIR1xTwCeU9bD6BvMfM'
    'J5b3sL4H8h7T91DeU8xO84pMQhHXNOFTXJBs34tpEuI9RSahiGsK+ETyXkyTUN9TZBKKuKaATyTv'
    'xTQJ8Z4ik1DENQV8InmPm08c70HzCeU9ru9xvAf1PZb3mP3LFZmvIa5pyic4XyOmSYr3yHwNcU0B'
    'n1DeY/aZV2S+hrimgE8o7zH5GorM1xDXFPAJ5T1sPoG8x8wnlvewvgfyHtP3WN5j9i9XZL6GuKYp'
    'n+B8jZgmKd4j8zXENQV8QnmP2Wdekfka4poCPqG8x+RrKDJfQ1xTwCeU97D5BPIeM59Y3sP6Hsh7'
    'TN9jeY/Zv1yR+RrimqZ8gvM1YpqkeI/M1xDXFPAJ5T1mn3lF5muIawr4hPJeRJMU75H5GuKaAj6h'
    'vIfNJ5D3mPnE8h7W90DeY/oey3vM/uWKzNcQ1zTlE5yvEdMkxXtkvoa4poBPKO8x+8wrMl9DXFPA'
    'J5T3mHwNReZriGsK+ITyHjafQN5j5hPLe1jfA3mP6Xss7zH7lysyX0Nc05RPcL5GTJMU75H5GuKa'
    'Aj6hvMfsM6/IfA1xTQGfUN5j8jUUma8hringE8p72HwCeY+ZTyzvYX0P5D2m77G8x+xfrsh8DXFN'
    'Uz7B+RoxTVK8R+ZriGsK+ITyHrPPvCLzNcQ1BXxCeY/J11Bkvoa4poBPKO9h8wnkPWY+sbyH9T2Q'
    '95i+x/Ies3+5IvM1xDVN+QTna8Q0SfEema8hringE8p7zD7ziszXENcU8AnlPSZfQ5H5GuKaAj6h'
    'vIfNJ5D3mPnE8h7W90DeY/oey3vM/uWKzNcQ1zTlE5yvEdMkxXtkvoa4poBPKO8x+8wrMl9DXFPA'
    'J5T3mHwNReZriGsK+ITyHjafQN5j5hPLe1jfA3mP6Xss7zH7lysyX0Nc05RPcL5GTJMU75H5GuKa'
    'Aj6hvMfsM6/IfA1xTQGfUN5j8jUUma8hringE8p72HwCeY+ZTyzvYX0P5D2m76G8p5n9yzWZryGu'
    'acKnuCDZvhfTJMR7mszXENcU8InkvZgmob6nyXwNcU0Bn0jei2kS4j1N5muIawr4RPIeN5843oPm'
    'E8p7XN/jeA/qeyzvMfuXazJfQ1zTlE9wvkZMkxTvkfka4poCPqG8x+wzr8l8DXFNAZ9Q3mPyNTSZ'
    'ryGuKeATynvYfAJ5j5lPLO9hfQ/kPabvifGeiKhczKh2kAC+zyNq2qmIImEyZ3aa12QSirimKZ/g'
    'JJSYJikyJ5NQxDUFfELJnEkE0GQSirimgE8omTNJKJpMQhHXFPAJJXNsPoFkzswnlsyxvgeSOdP3'
    '2N/EMjvNazIJRVzTlE9wEkpMkxTvkUko4poCPqG8xyQCaDIJRVxTwCeU9yKapHiPTEIR1xTwCeU9'
    'bD6BvMfMJ5b3sL4H8h7T91jeY3aa12QSirimKZ/gJJSYJineI5NQxDUFfEJ5j0kE0GQSirimgE8o'
    '7zFJKJpMQhHXFPAJ5T1sPoG8x8wnlvewvgfyHtP3WN5jdprXZBKKuKYpn+AklJgmKd4jk1DENQV8'
    'QnmPSQTQZBKKuKaATyjvMUkomkxCEdcU8AnlPWw+gbzHzCeW97C+B/Ie0/dY3mN2mtdkEoq4pimf'
    '4CSUmCYp3iOTUMQ1BXxCeY9JBNBkEoq4poBPKO8xSSiaTEIR1xTwCeU9bD6BvMfMJ5b3sL4H8h7T'
    '91jeY3aa12QSirimKZ/gJJSYJineI5NQxDUFfEJ5j0kE0GQSirimgE8o7zFJKJpMQhHXFPAJ5T1s'
    'PoG8x8wnlvewvgfyHtP3WN5jdprXZBKKuKYpn+AklJgmKd4jk1DENQV8QnmPSQTQZBKKuKaATyjv'
    'MUkomkxCEdcU8AnlPWw+gbzHzCeW97C+B/Ie0/dY3mN2mtdkEoq4pimf4CSUmCYp3iOTUMQ1BXxC'
    'eY9JBNBkEoq4poBPKO8xSSiaTEIR1xTwCeU9bD6BvMfMJ5b3sL4H8h7T91Dey5md5nMyCUVc04RP'
    'cUGyfS+mSYj3cjIJRVxTwCeS92KahPpeTiahiGsK+ETyXkyTEO/lZBKKuKaATyTvcfOJ4z1oPqG8'
    'x/U9jvegvsfyHrPTfE4moYhrmvIJTkKJaZLiPTIJRVxTwCeU95hEgJxMQhHXFPAJ5T0mCSUnk1DE'
    'NQV8QnkPm08g7zHzieU9rO+BvMf0PZb3mP3LczJfQ1zTlE9wvkZMkxTvkfka4poCPqG8x+wzn5P5'
    'GuKaAj6hvMfka+Rkvoa4poBPKO9h8wnkPWY+sbyH9T2Q95i+x/Ies395TuZriGua8gnO14hpkuI9'
    'Ml9DXFPAJ5T3mH3mczJfQ1xTwCeU9yKapHiPzNcQ1xTwCeU9bD6BvMfMJ5b3sL4H8h7T9yKC+sPt'
    'renuJ/R8WLCeR2t4PN1TCUL386exGbN/ek7me4hrmloncL5HTJMUb5L5HuKaAj6hvMnsc5+T+R7i'
    'mgI+obzJ5HvkZL6HuKaATyhvYvMJ5E1mPrG8ifU9kDeZvsf+fpHZPz0n8z3ENU35BOd7xDRJ8R6Z'
    '7yGuKeATynvMPvc5me8hringE8p7TL5HTuZ7iGsK+ITyHjafQN5j5hPLe1jfA3mP6Xss7zH7p+dk'
    'voe4pimf4HyPmCYp3iPzPcQ1BXxCeY/Z5z4n8z3ENQV8QnmPyffIyXwPcU0Bn1Dew+YTyHvMfGJ5'
    'D+t7IO8xfY/lPWb/9JzM9xDXNOUTnO8R0yTFe2S+h7imgE8o7zH73Odkvoe4poBPKO8x+R45me8h'
    'ringE8p72HwCeY+ZTyzvYX0P5D2m70nx3nzcvuZJ1fHwj5qS8g//5vn4qmeqnh55OtH/zC33Yav1'
    'Ybvl5KVJyclzH0bLSwtQXlrQ8jJwcboPo+Up0j2Fu6czUJ7OcHmalKfD8rbWXB9sY/qb/dbcOzWD'
    'GfoP5H3Vbrf2WIR76qt2t7addbPn4fiwG7r708HXZrD/0bW3T0dvW/dzmr5M0pdZko2/9fh6c7fp'
    'XZHn13RmPbze1L94h/9lTXc6HK/cD3W7t96hvb61x+LdA3+3m+ub88/f/PD2javFXbydk3sx/9b0'
    'w/fjO/rz5fz2KPZsxHjc1mZ4LOQ7a/pD92DIl+fxOj7R7oab8yle7fftzn36W2tuxxO5Uf/qMNTt'
    '7bnA16/OJRwPTG2/bH4+9GOB348P2O67thlf6n4aKzs99mT466MJf3u/dw8+XeHTo6/bfvNU7evt'
    'of9uszv051O7VfLL+ccfnJDjy8brfZktHx96duVOD53VvrHXh63pZue3umdv2uGrbVv/8rD6Hlaj'
    '7f7qCrs5PfJwFY4/v2v/ac6r4B/9HxfJP/rnrv/z0bfgop5cmqsH7FkNN117uL5ZjSLTNJnm06dz'
    'DK7U0OJ+XuqfX8KxRfr/C/P/ysL8hMX4uJCiS/Gni/mteb+5Pdyu7Nbse/fK3tbtrnGXRqts/Jrw'
    '8Hxnfz3Y3i3Oqzxduoc3u+PDbhHb7s5sn97nvja0d7YbNrd2de18Wm3GR398grrRrEcq8Q90OncF'
    '7bu2OdSjW6t33WYYV6Aro3Ond2e9H28H+97Uw6o/L+e1cdehmf3Ldu1ldT/Y2bnS2d7ZPNN5MdtZ'
    '985LMwz2dj+4l/7cVv0XxzfM+kPtrl3vho97296ebr7TGVfuZSt3HzrXncrGvp9fLRL3hbftNtcb'
    'N75W/9rsV/2NyfLFuAKVtQul06Js1DrTeWWaqkkqY5p6kTSNsabWVWnXTbks6rzJqmaRNUlmzLLR'
    'ta3O83r8rHP5T6fWRiV1Xtb1YpmrdZUsEpWXVVI2aVaVVaZrXdpFXuTpunLf7Jp8aZdprpNlWebl'
    'OrXjFX64eqv6xta/OG1meFjjaXqZqLdJeaWKqzx/USSFSpK/JMlVcnrjYDa7cVk8XqjVecGdL8c4'
    '0u9Xu3ZYVXbtBrx/3uxtsrhK9VWevcjTRZnk/nndu7qHu+3Vzs7euO+Lb92iaQ/DzA1Y283c+Z8b'
    '1LsG0lvn3a6d/f3t29cvbde13axqm/uZ+3Ozcwtx01yOa3/TD5u6n9m7TTPeSS9mX856O3ZVt0Bc'
    'F3pYDbNjIefPq9t227TvdrOmtb37jPHZrXk/G9fD5dqMS6rdbur7F0cBh96u3DK5tt2TVfnaWb52'
    'xqbGVk2VZFVR5so5Y6tFvq6MWyFmvXbXeGELnTpPi9KaPCvselmpZD22m8PucaE+rL5xIboVuDle'
    '9B+d/RepWwQ//e75at8PdndqEb/NTfOAWONb+6fymnVd2WWT12VqynWzXBaJHhdLmS7StcmsMSa1'
    'a0djZa0qa4o6XTfaLooyTZs6W6xdeY8dpd+5fuE63apxl3Q1fDB/Pnzhw9A7doMQ1U2Nw5+mzva4'
    'dsa/JL7vNuO/EpzVY9udDe1gtn2WLF4s85e9WwCzu/7dTbu1mU6+mNWHbryqp499GFXfffN9Z9db'
    'Ww+9u+jDxmzPp7xIc9fX1s72oTfX7l7oh61rSp3ZHs94/EC3IMdu/nCuv776ISsWd31WKrNrXr35'
    'NitSd1QUs3OPdR920Q43tsuKo8hbM9Q3L2bfW9vs7LvTOHfXMq1Mv+n/+5C5zugW46k/nZ9NXqp0'
    'XIbrjbtyq2OvHa12zblwD7oR/nShjLuB9oM5jpO1uy52bN59v9ldr87/uHKyTed6vO6untCzT337'
    '+BfDnv1fQ+9XSueTTI0E99SvB3fHDver8RZzADFO5Nedu2nbQ791dpr94B5tZrdm63rLrfvpdMHd'
    'jXnrvJi5t3dmN4wd6tgU3DeMU5donLzZ/ogH7rXn84w9onetfTfMHlvE2Pa3jjXG4T7b9A/D4wgv'
    '493l/O5O08iV9vXGPeTefGyAs3funmzf9a6dbO+Pnz5W45bG5dBe3riCx497WBOzP5zLDfFxfLlV'
    'vG87r9cXSd3U9dpUVard1Ehrq5TO87QujcmqRC0WmRrHSmbrxKj1Os+SQqs0zcqmcEeVO7H3DWt1'
    'XEFTBp5+Mfbs10jPfuny7FcUz77QP/v6631ZPLWjU4debTe3GzcQ7o/T22HE+N+5ZzarX9Pno9NU'
    'i0VaVLpKGlM2zTg/F1mul4XKlmmRa90sdWOXtRurzWK51tWyTNK6KpPCNauiaI4X88Y2h619Ouk4'
    'Vk2h8qUqXYPN17Upl3ZR6jptmkSnZb1UiUlNYpuiyLJ6UeWFqtYLJ6s2tiyK80lvzcot3FNjTc+m'
    'jSM5L2eH3doxUO8++GmhnRDpRB72/d51jc3g1nE1cu3seK9ejjeBm1T7g3udW9Nl1hzsaFA/c83C'
    'zag7u5u53uOtnZfj9+bZ0crZYy86LjhvOJ7X5LjCzzf+A9B8MS726/F+GBfqxWzsDrOnpnC+lXqn'
    'x5GX+/RR+YcUfHpoNQSYd7yfjjxdj9/DT/Q2Xg53w4x31pEP9ofKlX781rAy+/HDzHZcr6eZ/wSQ'
    'Kvn930IwyQA='
)))
EMBEDDED_SHA256 = 'ee6eb91d35ff5f1c2c008df3cd460e516bf412c8a0f0161c366c87098823ad6d'
MAX_BODY = 2_000_000
MAX_EXPANDED = 100_000_000
MAX_ZIP = 20_000_000
MAX_JOBS = 1200
ENDPOINTS = {
    "boxscoretraditionalv3",
    "boxscoreadvancedv3",
    "boxscoresummaryv3",
    "leaguedashplayerstats",
    "leaguedashteamstats",
}


def _json(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def _sha(raw):
    return hashlib.sha256(raw).hexdigest()


def validate_request(request):
    if (
        request.get("status") != "collection_requirement_not_publication_approval"
        or request.get("season") != "2026-27"
        or request.get("season_type") != "Regular Season"
        or not request.get("base_generation")
        or not re.fullmatch(r"[a-f0-9]{64}", request.get("base_manifest_sha256", ""))
        or len(_json(request)) > 250_000
    ):
        raise ValueError("Invalid fixed collection requirement")
    jobs = request["jobs"]
    if (
        not 1 <= len(jobs) <= MAX_JOBS
        or request["maximum_requests"] != len(jobs)
        or request["attempts_per_job"] != 1
        or request["timeout_seconds"] != 30
        or request["response_limit_bytes"] != MAX_BODY
        or request["minimum_interval_seconds"] < 1
        or not 1 <= request["maximum_elapsed_seconds"] <= 43_200
    ):
        raise ValueError("Collection bounds differ from reviewed finite protocol")
    names = set()
    requests_seen = set()
    for job in jobs:
        name = job["source_file"]
        if (
            job["endpoint"] not in ENDPOINTS
            or not re.fullmatch(r"sources/[a-zA-Z0-9_-]+\.json", name)
            or name in names
            or not isinstance(job["parameters"], dict)
        ):
            raise ValueError("Invalid/duplicate fixed source job")
        names.add(name)
        params = job["parameters"]
        identity = (job["endpoint"], _json(params))
        if identity in requests_seen:
            raise ValueError("Duplicate source request")
        requests_seen.add(identity)
        if job["endpoint"] == "boxscoresummaryv3":
            if set(params) != {"GameID"} or not re.fullmatch(r"00226\d{5}", params["GameID"]):
                raise ValueError("Summary source must use its exact game identity only")
        elif job["endpoint"].startswith("boxscore"):
            full_traditional = (
                job["endpoint"] == "boxscoretraditionalv3"
                and set(params)
                == {"GameID", "StartPeriod", "EndPeriod", "RangeType", "StartRange", "EndRange"}
                and all(params[key] == "0" for key in params if key != "GameID")
            )
            if full_traditional:
                if not re.fullmatch(r"00226\d{5}", params["GameID"]):
                    raise ValueError("Invalid full Traditional source game identity")
                continue
            if (
                set(params)
                != {"GameID", "StartPeriod", "EndPeriod", "RangeType", "StartRange", "EndRange"}
                or not re.fullmatch(r"00226\d{5}", params["GameID"])
                or type(params["StartPeriod"]) is not int
                or type(params["EndPeriod"]) is not int
                or (params["StartPeriod"], params["EndPeriod"])
                not in {(1, 1), (2, 2), (3, 3), (4, 4), (1, 2), (3, 4), (5, 14)}
                or params["RangeType"] != 1
                or params["StartRange"] != 0
                or params["EndRange"] != 28800
            ):
                raise ValueError("Invalid fixed box-score window")
        elif (
            params.get("Season") != "2026-27"
            or params.get("SeasonType") != "Regular Season"
            or params.get("MeasureType") != "Advanced"
            or params.get("PerMode") != "PerGame"
            or not re.fullmatch(r"\d{2}/\d{2}/2026", params.get("DateTo", ""))
        ):
            raise ValueError("Advanced snapshot must retain its explicit cutoff/basis")
    return _sha(_json(request))


def _client(job):
    from nba_api.stats.endpoints import (
        BoxScoreAdvancedV3,
        BoxScoreSummaryV3,
        BoxScoreTraditionalV3,
        LeagueDashPlayerStats,
        LeagueDashTeamStats,
    )
    from nba_api.stats.library.http import NBAStatsHTTP

    name, params = job["endpoint"], job["parameters"]
    if name == "boxscoresummaryv3":
        endpoint = BoxScoreSummaryV3(game_id=params["GameID"], get_request=False)
    elif name.startswith("boxscore"):
        cls = BoxScoreTraditionalV3 if name == "boxscoretraditionalv3" else BoxScoreAdvancedV3
        endpoint = cls(
            game_id=params["GameID"],
            start_period=params["StartPeriod"],
            end_period=params["EndPeriod"],
            range_type=params["RangeType"],
            start_range=params["StartRange"],
            end_range=params["EndRange"],
            get_request=False,
        )
    else:
        cls = LeagueDashPlayerStats if name == "leaguedashplayerstats" else LeagueDashTeamStats
        endpoint = cls(
            season="2026-27",
            season_type_all_star="Regular Season",
            measure_type_detailed_defense="Advanced",
            per_mode_detailed="PerGame",
            date_from_nullable=params.get("DateFrom", ""),
            date_to_nullable=params["DateTo"],
            get_request=False,
        )
    actual_parameters = endpoint.parameters.copy()
    planned_parameters = params.copy()
    # v1.12 adds this optional default None to both Advanced snapshot endpoints.
    # Requests omits None-valued query items; no statistical filter changes.
    if name in {"leaguedashplayerstats", "leaguedashteamstats"}:
        for parameters in [actual_parameters, planned_parameters]:
            if "ISTRound" in parameters:
                if parameters["ISTRound"] is not None:
                    raise ValueError("Unexpected tournament-round filter")
                parameters.pop("ISTRound")
    if endpoint.endpoint != name or actual_parameters != planned_parameters:
        raise ValueError("Installed SDK parameters differ from the fixed reviewed request")
    http = NBAStatsHTTP()
    url = http.base_url.format(endpoint=name)
    if url != f"https://stats.nba.com/stats/{name}":
        raise ValueError("Unexpected source transport host")
    return http, url


def _checkpoint(output, report):
    metadata = json.dumps(report, indent=2) + "\n"
    for name in ["acquisition.json", "sources/capture-attempt.json"]:
        temporary = output / "checkpoint.tmp"
        temporary.write_text(metadata)
        temporary.replace(output / name)


def _bundle(output, request, report):
    """Existing collection_bundle protocol; originals remain untouched on disk."""
    _checkpoint(output, report)
    paths = [output / "acquisition.json", *(output / "sources").glob("*.json")]
    files = {}
    total = 0
    for path in sorted(paths):
        if path.is_symlink():
            raise ValueError("Symlink not allowed")
        raw = path.read_bytes()
        total += len(raw)
        files[path.relative_to(output).as_posix()] = {"bytes": len(raw), "sha256": _sha(raw)}
    if len(files) > 2000 or total > MAX_EXPANDED:
        raise ValueError("Collection exceeds expanded data-only bound; loose originals preserved")
    manifest = dict(
        schema_version=1,
        classification="unvalidated_development_collection",
        request=request,
        request_sha256=_sha(_json(request)),
        files=files,
        production_writes=0,
    )
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        for name in files:
            archive.write(output / name, name)
        archive.writestr("collection-manifest.json", json.dumps(manifest, indent=2) + "\n")
    payload = buffer.getvalue()
    if len(payload) > MAX_ZIP:
        raise ValueError("Collection exceeds ZIP bound; loose originals preserved")
    temporary = output / "collection.tmp"
    temporary.write_bytes(payload)
    temporary.replace(output / "collection.zip")


def _resume(output, request, request_sha):
    path = output / "acquisition.json"
    if not path.exists():
        output.mkdir(parents=True, exist_ok=False)
        (output / "sources").mkdir()
        return dict(
            classification="unvalidated_laptop_source_capture_not_publication",
            source="NBA Stats",
            captured_at=datetime.now(UTC).isoformat(),
            parameters="exact fixed per-job parameters in request and attempts",
            request=request,
            request_sha256=request_sha,
            nba_api_version=None,
            attempts=[],
            production_writes=0,
            canonical_period_accepted=False,
        )
    if output.is_symlink() or path.is_symlink() or (output / "sources").is_symlink():
        raise ValueError("Symlink not allowed")
    report = json.loads(path.read_bytes())
    if report["request"] != request or report["request_sha256"] != request_sha:
        raise ValueError("Existing output belongs to a different fixed package")
    attempts = report["attempts"]
    if len(attempts) > len(request["jobs"]):
        raise ValueError("Unexpected prior attempts")
    expected_names = {"capture-attempt.json"}
    for attempt, job in zip(attempts, request["jobs"], strict=False):
        if attempt["job"] != job:
            raise ValueError("Prior attempted request differs")
        if attempt.get("source_file"):
            if attempt["source_file"] != job["source_file"]:
                raise ValueError("Prior source path differs")
            source = output / attempt["source_file"]
            expected_names.add(source.name)
            if source.is_symlink():
                raise ValueError("Symlink not allowed")
            raw = source.read_bytes()
            if len(raw) != attempt["response_bytes"] or _sha(raw) != attempt["response_sha256"]:
                raise ValueError("Prior source bytes changed; no requests made")
    if {p.name for p in (output / "sources").iterdir()} != expected_names:
        raise ValueError("Unexpected source file; no requests made")
    return report


def collect(output: Path, request: dict):
    request_sha = validate_request(request)
    report = _resume(output, request, request_sha)
    attempts = report["attempts"]
    # A failure is never an implicit retry or permission to continue a batch.
    if any(not row.get("transport_complete", False) for row in attempts):
        report["stop_reason"] = "failure_return_output_do_not_retry"
        report["unattempted_jobs"] = request["jobs"][len(attempts) :]
        _bundle(output, request, report)
        return report
    started = time.monotonic()
    compressed_bytes = expanded_bytes = 0
    for row in attempts:
        if row.get("source_file"):
            raw = (output / row["source_file"]).read_bytes()
            compressed_bytes += len(zlib.compress(raw))
            expanded_bytes += len(raw)
    try:
        report["nba_api_version"] = version("nba_api")
        for job in request["jobs"][len(attempts) :]:
            # Reserve 2MB for next original and 4MB for bounded plan/diagnostics.
            if expanded_bytes > 94_000_000 or compressed_bytes > 14_000_000:
                report["stop_reason"] = "collection_size_limit"
                break
            if time.monotonic() - started + 31 > request["maximum_elapsed_seconds"]:
                report["stop_reason"] = "elapsed_limit"
                break
            if attempts:
                time.sleep(request["minimum_interval_seconds"])
            http, url = _client(job)
            attempt = dict(
                job=job,
                endpoint=job["endpoint"],
                url=url,
                parameters=job["parameters"],
                started_at=datetime.now(UTC).isoformat(),
                attempts=1,
                timeout_seconds=30,
                http_status=None,
                response_complete=False,
                transport_complete=False,
            )
            attempts.append(attempt)
            # Record intent before transport; interruption never causes a retry.
            _checkpoint(output, report)
            raw = bytearray()
            try:
                with http.get_session().get(
                    url=url,
                    params=sorted(job["parameters"].items()),
                    headers=http.headers,
                    timeout=30,
                    stream=True,
                    allow_redirects=False,
                ) as response:
                    attempt["http_status"] = response.status_code
                    for chunk in response.iter_content(65536):
                        remaining = MAX_BODY - len(raw)
                        raw.extend(chunk[:remaining])
                        if len(chunk) > remaining:
                            attempt["response_truncated"] = True
                            raise ValueError("Response exceeds2MB retained bound")
                        if time.monotonic() - started > request["maximum_elapsed_seconds"]:
                            raise TimeoutError("Fixed collection elapsed limit reached")
                    attempt["response_complete"] = True
                    response.raise_for_status()
                    if response.status_code != 200:
                        raise ValueError("Source transport did not return HTTP200")
                document = json.loads(raw)
                if not isinstance(document, dict):
                    raise ValueError("Expected JSON source object")
                attempt["transport_complete"] = True
            except BaseException as exc:
                attempt["error_type"] = type(exc).__name__
                raise
            finally:
                if raw:
                    destination = output / job["source_file"]
                    with destination.open("xb") as handle:
                        handle.write(raw)
                attempt.update(
                    finished_at=datetime.now(UTC).isoformat(),
                    response_bytes=len(raw),
                    response_sha256=_sha(raw),
                    source_file=job["source_file"] if raw else None,
                )
                compressed_bytes += len(zlib.compress(raw))
                expanded_bytes += len(raw)
                _checkpoint(output, report)
            print(
                f"Captured {len(attempts)}/{len(request['jobs'])}; originals retained.", flush=True
            )
    except BaseException as exc:
        report["error_type"] = type(exc).__name__
        report["stop_reason"] = "failure_return_output_do_not_retry"
    finally:
        report.update(
            finished_at=datetime.now(UTC).isoformat(),
            unattempted_jobs=request["jobs"][len(attempts) :],
            transport_finished=len(attempts) == len(request["jobs"])
            and all(row.get("transport_complete", False) for row in attempts),
        )
        _bundle(output, request, report)
    return report


def _package_source(request):
    request_sha = validate_request(request)
    source = Path(__file__).read_text()
    encoded = base64.b64encode(zlib.compress(_json(request))).decode()
    chunks = "\n".join(f"    {encoded[i : i + 76]!r}" for i in range(0, len(encoded), 76))
    replacement = (
        "EMBEDDED_REQUEST = json.loads(zlib.decompress(base64.b64decode(\n" + chunks + "\n)))"
    )
    source = source.replace("EMBEDDED_REQUEST = None", replacement, 1)
    source = source.replace("EMBEDDED_SHA256 = None", f"EMBEDDED_SHA256 = {request_sha!r}", 1)
    return source, {"request_sha256": request_sha, "package_sha256": _sha(source.encode())}


def build_package(request: dict, destination: Path):
    """Cloud-only builder; generated file has no repository imports or inputs."""
    source, binding = _package_source(request)
    with Path(destination).open("x") as handle:
        handle.write(source)
    return binding


def build_owner_bundle(request: dict, destination: Path):
    """One ZIP containing executable and existing-Python desktop launchers."""
    source, binding = _package_source(request)
    mac = """#!/bin/sh
cd -- "$(dirname -- "$0")" || exit 1
found=0
for runtime in python3 python; do
    if "$runtime" -c 'import nba_api' >/dev/null 2>&1; then
        "$runtime" run_capture.py
        found=1
        break
    fi
done
if [ "$found" -eq 0 ]; then
    python3 run_capture.py
fi
printf '\nReturn readiness-capture/collection.zip, including after a failure.\n'
printf 'Press Return to close.'
read -r ignored
"""
    windows = r"""@echo off
cd /d "%~dp0"
for %%P in (python python3) do (
    %%P -c "import nba_api" >nul 2>&1
    if not errorlevel 1 (
        %%P run_capture.py
        goto done
    )
)
py -3 -c "import nba_api" >nul 2>&1
if not errorlevel 1 (
    py -3 run_capture.py
    goto done
)
python run_capture.py
:done
echo.
echo Return readiness-capture\collection.zip, including after a failure.
pause
"""
    instructions = (
        "Unzip this package in a new folder. Open Run Capture.command on Mac "
        "or Run Capture.bat on Windows. Keep this folder open until it finishes.\n"
        "The launcher uses Python and nba_api already installed. It installs nothing.\n"
        f"Scope: {len(request['jobs'])} fixed requests; one attempt per request; "
        f"30-second timeout, {request['minimum_interval_seconds']}s minimum spacing, "
        f"finite {request['maximum_elapsed_seconds']}s ceiling.\n"
        "Return readiness-capture/collection.zip through the existing handoff, "
        "even if capture stops or fails. Keep the whole output folder until Codex "
        "confirms receipt. Do not delete it or restart to troubleshoot a failure.\n"
        "Every captured original and the exact request are preserved. "
        "The collection makes no production change and accepts no dataset.\n"
    )
    with Path(destination).open("xb") as output:
        with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("run_capture.py", source)
            command = zipfile.ZipInfo("Run Capture.command")
            command.create_system = 3
            command.external_attr = 0o100755 << 16
            archive.writestr(command, mac)
            archive.writestr("Run Capture.bat", windows.replace("\n", "\r\n"))
            archive.writestr("READ ME.txt", instructions)
    binding["owner_bundle_sha256"] = _sha(Path(destination).read_bytes())
    return binding


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=Path(__file__).resolve().with_name("readiness-capture")
    )
    args = parser.parse_args()
    if EMBEDDED_REQUEST is None or validate_request(EMBEDDED_REQUEST) != EMBEDDED_SHA256:
        parser.error("Run the cloud-prepared standalone package; no request is embedded here")
    try:
        report = collect(args.output, EMBEDDED_REQUEST)
    except Exception as exc:
        print(f"Stopped safely ({type(exc).__name__}); preserve the output directory for Codex.")
        return 1
    print(
        f"Return {args.output / 'collection.zip'} to Codex, including after failure. "
        "No data published."
    )
    return 0 if report.get("transport_finished") else 1


if __name__ == "__main__":
    raise SystemExit(main())
