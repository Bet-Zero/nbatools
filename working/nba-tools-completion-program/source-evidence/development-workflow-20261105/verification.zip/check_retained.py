"""Independent retained-input flow. This verifies interpretation, not NBA truth."""
from pathlib import Path
from tempfile import TemporaryDirectory
from zipfile import ZipFile
from io import BytesIO
import hashlib,json
import pandas as pd
from nbatools.development_data import development_snapshot,sha256
from nbatools.api_handlers import natural_query_payload
from tools.development_snapshot import prepare

base=Path('working/nba-tools-completion-program/source-evidence/rollover-2026-27/official-gamebooks-20261105')
archive=base/'normalized-snapshot.zip';assert sha256(archive.read_bytes())=='b43546c6e911b98b303a81bc23072d5ea08c2cd71a6175f48959c25886f8d8b2'
with TemporaryDirectory(dir='/workspace/work/policy-checker-probes',prefix='retained-final-') as folder:
    folder=Path(folder);source=folder/'source';source.mkdir();root=folder/'snapshot'
    with ZipFile(archive) as z:
        assert z.testzip() is None
        for name in z.namelist():assert not Path(name).is_absolute() and '..' not in Path(name).parts
        z.extractall(source)
        csvs=[n for n in z.namelist() if n.endswith('.csv')]
        raw=pd.read_csv(BytesIO(z.read('data/raw/player_game_stats/2026-27_regular_season.csv')))
        expected=raw.loc[raw.player_id.eq(201939)]
        assert len(expected)==6 and expected.ast.sum()==27 and expected.pts.sum()==180
        digest=prepare(source,root,version='independent-pr582-flow',season='2026-27',season_type='Regular Season',scope='107historical games at2026-11-05T06:59:31.715470Z; not current freshness',source_evidence={'reference':'PR582 portable source','sha256':sha256(archive.read_bytes())},backlog=folder/'backlog',exceptions=['DQ-001','DQ-002','DQ-003'])
        for name in csvs:assert (root/name).read_bytes()==z.read(name),name
        period=pd.read_csv(root/'data/raw/player_game_period_stats/2026-27_regular_season.csv',dtype=str,keep_default_na=False)
        def key(r):return tuple(str(r[k]).lstrip('0') or '0' for k in ['game_id','team_id','player_id'])+(str(r['period_family']),str(r['period_value']))
        rows={key(r):r for r in period.to_dict('records')}
        ledger=json.loads((base/'remaining-dependencies.json').read_text())['unknown_rates'];assert len(ledger)==484
        assert all(rows[key(r)][r['field']]=='' for r in ledger)
        with development_snapshot(root,digest):
            p=natural_query_payload('Stephen Curry average assists in 2026-27')
            assert p['result_status']=='ok'
            summary=p['result']['sections']['summary'][0]
            assert summary['games']==6 and summary['ast_sum']==27 and summary['ast_avg']==4.5
            q=p['result']['metadata']['data_quality']
            assert q['state']=='provisional' and q['manifest_sha256']==digest and not q['numerical_acceptance'] and not q['production_accepted']
        result=dict(candidate='38cd2b5dff728c7b217b7a0a87634cc83a774cfd',normalized_sha256=sha256(archive.read_bytes()),csvs_preserved=len(csvs),exact_unknown_keys_preserved=len(ledger),query='Stephen Curry average assists in2026-27',games=summary['games'],ast_sum=summary['ast_sum'],ast_avg=summary['ast_avg'],pts_sum=summary['pts_sum'],snapshot=digest,numerical_acceptance=False,production_accepted=False)
        print(json.dumps(result,sort_keys=True))
        Path('/workspace/work/policy-checker-probes/retained-flow-result.json').write_text(json.dumps(result,indent=2)+'\n')
