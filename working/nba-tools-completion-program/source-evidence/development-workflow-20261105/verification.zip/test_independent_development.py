"""Independent controlled probes. No real NBA qualification is claimed."""
import asyncio
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import shutil
from threading import Barrier

import httpx
import pandas as pd
import pytest

from nbatools.api_handlers import query_result_to_payload
from nbatools.data_source import DataSourceConfigError,data_glob,data_path,data_source_cache_key
from nbatools.development_data import MANIFEST,development_snapshot,selected_snapshot,sha256
from nbatools.query_service import execute_structured_query
from tools.development_query import create_app
from tools.development_snapshot import intake,prepare

FIXTURE=Path('/workspace/work/agent1/qa/fixtures/query_engine_sample')
RAW='data/raw/player_game_stats/2025-26_regular_season.csv'

@pytest.fixture
def prepared(tmp_path):
    source=tmp_path/'source';root=tmp_path/'v1'
    shutil.copytree(FIXTURE/'data',source/'data')
    frame=pd.read_csv(source/RAW)
    frame['fg_pct']=frame.fgm/frame.fga
    frame['fg3_pct']=frame.fg3m/frame.fg3a
    frame.to_csv(source/RAW,index=False)
    kwargs=dict(season='2025-26',season_type='Regular Season',scope='independent controlled2025-26; not NBA evidence',source_evidence={'reference':'independent controlled source','sha256':sha256((source/RAW).read_bytes())},backlog=tmp_path/'backlog',exceptions=['DQ-independent-control'],fixture=True)
    digest=prepare(source,root,version='independent-v1',**kwargs)
    return source,root,digest,kwargs

def test_second_entity_filter_exact_ids_and_arithmetic(prepared):
    _,root,digest,_=prepared
    raw=pd.read_csv(root/RAW)
    expected=raw.loc[raw.player_id.eq(201939)&raw.is_away.eq(True)&raw.pts.ge(20)]
    assert len(expected)>1
    with development_snapshot(root,digest):
        assert len(data_glob('raw/player_game_stats/*.csv'))==1
        assert data_glob('raw/player_game_stats/*.csv')==data_glob('data/raw/player_game_stats/*.csv')
        result=query_result_to_payload(execute_structured_query('player_game_summary',player='Stephen Curry',season='2025-26',away_only=True,stat='pts',min_value=20))
        sections=result['result']['sections'];summary=sections['summary'][0]
        assert set(r['game_id'] for r in sections['game_log'])==set(expected.game_id)
        assert summary['games']==len(expected)
        assert summary['pts_avg']==pytest.approx(expected.pts.mean(),abs=.00051)
        assert summary['ast_sum']==expected.ast.sum()
        quality=result['result']['metadata']['data_quality']
        assert quality['manifest_sha256']==digest
        assert quality['fixture'] is True
        assert quality['numerical_acceptance'] is False and quality['production_accepted'] is False
        assert 'DQ-independent-control' in quality['exceptions']

def test_http_response_and_public_route_cannot_choose_snapshot(prepared):
    _,root,digest,_=prepared
    async def run():
        transport=httpx.ASGITransport(app=create_app(root,digest))
        async with httpx.AsyncClient(transport=transport,base_url='http://127.0.0.1') as client:
            response=await client.post('/query',json={'query':'Stephen Curry stats in 2025-26'})
            assert response.status_code==200
            payload=response.json()
            assert payload['result']['metadata']['data_quality']['manifest_sha256']==digest
            assert 'PROVISIONAL' in payload['notes'][0]
    asyncio.run(run())
    assert selected_snapshot() is None

@pytest.mark.parametrize('flag,value',[('ENVIRONMENT','production'),('VERCEL','1'),('VERCEL_ENV','preview'),('DATA_SOURCE','r2'),('AWS_LAMBDA_FUNCTION_NAME','controlled-lambda')])
def test_actual_host_modes_reject_opt_in_and_direct_absolute_path(prepared,monkeypatch,flag,value):
    _,root,digest,_=prepared
    monkeypatch.setenv(flag,value)
    with pytest.raises(ValueError,match='isolated local'):
        with development_snapshot(root,digest):pass
    if flag!='DATA_SOURCE':
        with pytest.raises(DataSourceConfigError,match='Provisional'):
            data_path(root/RAW)

def test_snapshot_scope_does_not_include_unvalidated_seasons(prepared):
    source,root,_,_=prepared
    assert list((source/'data/raw/player_game_stats').glob('2023-24*'))
    assert not list((root/'data/raw/player_game_stats').glob('2023-24*'))

def test_zero_discrepancy_dedup_preserves_claim_and_resolution(tmp_path):
    failure=dict(dataset='player_game_stats',source_sha256='b'*64,scope={'game':'controlled','field':'ast'},check='independent-source-difference',observed=0,expected=3,impact=['ast_sum','ast_last_5'],evidence={'reference':'independent controlled oracle'},next_evidence='review source correction')
    first=intake(tmp_path,failure);path=tmp_path/(first+'.json');item=json.loads(path.read_text());item['status']='resolved';item['claim']={'session':'independent'};item['resolution']={'version':'controlled-v2'};path.write_text(json.dumps(item))
    assert intake(tmp_path,failure)==first
    assert json.loads(path.read_text())['resolution']==item['resolution']
    assert len(list(tmp_path.glob('*.json')))==1

def test_identity_contradiction_is_quarantined(prepared,tmp_path):
    source,_,_,kwargs=prepared
    raw=pd.read_csv(source/RAW);raw.loc[raw.index[0],'game_id']=9999999999;raw.to_csv(source/RAW,index=False)
    with pytest.raises(ValueError,match='identity'):
        prepare(source,tmp_path/'bad',version='bad',**kwargs)
    assert not (tmp_path/'bad').exists()

def test_correction_two_concurrent_readers_get_distinct_versions(prepared,tmp_path):
    _,old,digest,kwargs=prepared
    before=(old/RAW).read_bytes();frame=pd.read_csv(old/RAW,dtype=str,keep_default_na=False)
    target=frame.loc[frame.player_id.eq('201939')].sort_values(['game_date','game_id']).iloc[0]
    correction=dict(author='independent-controlled-author',base_manifest_sha256=digest,source_sha256=sha256(before),independent_review={'reviewer':'different-controlled-reviewer','reference':'synthetic software oracle only'},changes=[dict(key={k:target[k] for k in ['game_id','team_id','player_id']},field='ast',before=target.ast,after=int(target.ast)+3,evidence='controlled correction oracle')])
    new=tmp_path/'v2';newdigest=prepare(old,new,version='independent-v2',correction=correction,**kwargs)
    features=pd.read_csv(new/'data/processed/player_game_features/2025-26_regular_season.csv')
    next_game=features.loc[features.player_id.eq(201939)].sort_values(['game_date','game_id']).iloc[1]
    assert next_game.ast_last_5==int(target.ast)+3
    barrier=Barrier(2)
    def query(root,d):
        with development_snapshot(root,d):
            barrier.wait(timeout=10)
            payload=query_result_to_payload(execute_structured_query('player_game_summary',player='Stephen Curry',season='2025-26'))
            return payload['result']['sections']['summary'][0]['ast_sum'],payload['result']['metadata']['data_quality']['manifest_sha256'],data_source_cache_key()
    with ThreadPoolExecutor(max_workers=2) as pool:
        a=pool.submit(query,old,digest);b=pool.submit(query,new,newdigest);old_result,new_result=a.result(timeout=20),b.result(timeout=20)
    assert old_result[1]==digest and new_result[1]==newdigest
    assert new_result[0]==old_result[0]+3
    assert old_result[2]!=new_result[2]
    assert (old/RAW).read_bytes()==before
    correction['changes'][0]['before']='9999'
    with pytest.raises(ValueError,match='stale old'):
        prepare(old,tmp_path/'stale',version='stale',correction=correction,**kwargs)
    assert not (tmp_path/'stale').exists()

def test_production_rejects_symlink_alias(prepared,tmp_path,monkeypatch):
    _,root,_,_=prepared
    alias=tmp_path/'alias.csv';alias.symlink_to(root/RAW)
    monkeypatch.setenv('ENVIRONMENT','production')
    with pytest.raises(DataSourceConfigError,match='Provisional'):
        data_path(alias)

def test_correction_rejects_mutated_other_file_in_pinned_base(prepared,tmp_path):
    _,old,digest,kwargs=prepared
    frame=pd.read_csv(old/RAW,dtype=str,keep_default_na=False);row=frame.iloc[0]
    correction=dict(author='independent-fixture-author',base_manifest_sha256=digest,source_sha256=sha256((old/RAW).read_bytes()),independent_review={'reviewer':'different-fixture-reviewer','reference':'controlled software oracle'},changes=[dict(key={k:row[k] for k in ['game_id','team_id','player_id']},field='ast',before=row.ast,after=int(row.ast)+1,evidence='controlled correction')])
    team_path=old/'data/raw/team_game_stats/2025-26_regular_season.csv'
    team=pd.read_csv(team_path);team.loc[team.index[0],'pts']+=3;team.to_csv(team_path,index=False)
    with pytest.raises(ValueError,match='changed|hash|manifest|precondition'):
        prepare(old,tmp_path/'tampered-v2',version='tampered-v2',correction=correction,**kwargs)
    assert not (tmp_path/'tampered-v2').exists()

def test_numeric_unknown_query_has_labeled_no_data_result(prepared,tmp_path):
    source,_,_,kwargs=prepared
    frame=pd.read_csv(source/RAW);frame.loc[frame.player_id.eq(201939).idxmax(),'pts']=float('nan');frame.to_csv(source/RAW,index=False)
    root=tmp_path/'missing-pts';digest=prepare(source,root,version='missing-pts',**kwargs)
    with development_snapshot(root,digest):
        p=query_result_to_payload(execute_structured_query('player_game_summary',player='Stephen Curry',season='2025-26'))
        assert p['result_status']=='no_result'
        assert p['result']['metadata']['data_quality']['manifest_sha256']==digest
        assert p['result']['metadata']['data_quality']['numerical_acceptance'] is False
        assert 'PROVISIONAL' in p['notes'][0]
        assert 'unknown numeric' in str(p)

def test_same_logical_correction_key_conflicts_across_id_formats(prepared,tmp_path):
    _,old,digest,kwargs=prepared
    frame=pd.read_csv(old/RAW,dtype=str,keep_default_na=False);row=frame.iloc[0]
    key={k:row[k] for k in ['game_id','team_id','player_id']}
    alternate={k:int(v) for k,v in key.items()};alternate['game_id']=str(int(key['game_id'])).zfill(10)
    correction=dict(author='controlled-author',base_manifest_sha256=digest,source_sha256=sha256((old/RAW).read_bytes()),independent_review={'reviewer':'different-controlled-reviewer','reference':'controlled oracle'},changes=[dict(key=key,field='ast',before=row.ast,after=int(row.ast)+1,evidence='controlled first'),dict(key=alternate,field='ast',before=int(row.ast)+1,after=int(row.ast)+2,evidence='controlled conflicting second')])
    with pytest.raises(ValueError,match='conflict'):
        prepare(old,tmp_path/'duplicate-v2',version='duplicate-v2',correction=correction,**kwargs)
    assert not (tmp_path/'duplicate-v2').exists()
