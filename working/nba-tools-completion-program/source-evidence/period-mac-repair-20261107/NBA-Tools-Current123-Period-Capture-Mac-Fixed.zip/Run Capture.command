#!/bin/sh
cd -- "$(dirname -- "$0")" || exit 1
# Finder has a minimal PATH. Never invoke the Apple developer-tools stub.
found=0
set --
if [ -n "${VIRTUAL_ENV:-}" ]; then set -- "$VIRTUAL_ENV/bin/python"; fi
for runtime in "$@" .nba-tools-env/bin/python .venv/bin/python venv/bin/python \
    ../.venv/bin/python ../venv/bin/python python3.11 \
    /opt/homebrew/bin/python3.11 /usr/local/bin/python3.11 \
    /Library/Frameworks/Python.framework/Versions/3.11/bin/python3 \
    python3.12 /opt/homebrew/bin/python3.12 /usr/local/bin/python3.12 \
    /Library/Frameworks/Python.framework/Versions/3.12/bin/python3 \
    python3.13 /opt/homebrew/bin/python3.13 /usr/local/bin/python3.13 \
    /Library/Frameworks/Python.framework/Versions/3.13/bin/python3 python3 python; do
    case "$runtime" in
        python*)
            located=$(command -v "$runtime" 2>/dev/null) || continue
            if [ "$located" = /usr/bin/python3 ] &&
                [ ! -d /Library/Developer/CommandLineTools ]; then continue; fi
            ;;
    esac
    if "$runtime" -I -c 'import sys; assert sys.version_info >= (3, 8)' >/dev/null 2>&1; then
        "$runtime" -I prepare_environment.py
        found=1
        break
    fi
done
if [ "$found" -eq 0 ]; then
    if [ ! -e readiness-capture ]; then
        mkdir readiness-capture && cp environment-failure.zip readiness-capture/collection.zip
    fi
    printf '\nPython setup could not start. No NBA requests were attempted.\n'
fi
printf '\nReturn readiness-capture/collection.zip, including after a failure.\n'
printf 'Press Return to close.'
read -r ignored
