@echo off
cd /d "%~dp0"
for %%P in (python python3) do (
    %%P -c "import nba_api" >nul 2>&1
    if not errorlevel 1 (
        %%P run_capture.py
        goto done
    )
)
py -3 -c "import nba_api" >nul 2>&1
if not errorlevel 1 (
    py -3 run_capture.py
    goto done
)
python run_capture.py
:done
echo.
echo Return readiness-capture\collection.zip, including after a failure.
pause
