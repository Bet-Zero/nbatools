import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
const { chromium } = await import(pathToFileURL(process.cwd() + '/frontend/node_modules/playwright/index.mjs'));
const dir='work/occurrence-label-rendering';
const oracle=JSON.parse(await readFile(dir+'/independent-oracle.json','utf8'));
const queries=['Who has the most 30 point games in 2026-27?','Who has the most 30-point games in 2026-27?'];
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true});
const receipts=[];
try {
 for (const [view,width,height] of [['desktop',1280,900],['mobile',390,844]]) {
  const context=await browser.newContext({viewport:{width,height}});
  const page=await context.newPage();
  const errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto('http://127.0.0.1:8765',{timeout:30000});
  for (let i=0;i<queries.length;i++) {
   await page.locator('#nba-query-input').fill(queries[i]);
   const pending=page.waitForResponse(r=>r.url()==='http://127.0.0.1:8765/query' && r.request().method()==='POST');
   await page.getByRole('button',{name:'Query',exact:true}).click();
   const response=await pending;const body=await response.json();
   await page.locator('[data-app-state="loading"]').waitFor({state:'detached'});
   const text=await page.locator('[data-state-surface="result"]').innerText();
   const meta=body.result.metadata;
   if(response.status()!==200||body.result_status!=='ok')throw Error('Positive counter unavailable');
   if(meta.stat!=='games_30p'||meta.data_quality.manifest_sha256!==oracle.manifest_sha256)throw Error('Wrong counter or snapshot');
   if(JSON.stringify(meta.applied_filters)!==JSON.stringify([{label:'pts min',value:'30.0',kind:'threshold'}]))throw Error('Wrong event basis label');
   if(!/30\+\s*PTS/i.test(text)||!text.includes('PROVISIONAL')||/games_30p min/.test(text))throw Error('Visible event label/provisional scope missing: '+text.slice(0,1800));
   const rows=body.result.sections.leaderboard;
   if(rows.length!==10||new Set(rows.map(r=>r.player_id)).size!==10)throw Error('Wrong complete top10');
   for(const r of rows){const expected=oracle.counts[String(r.player_id)];if(!expected||r.games_30p!==expected.count||r.games_played!==expected.games)throw Error('Independent event count/denominator mismatch');}
   const screenshot=`${view}-${i}.png`;const bytes=await page.screenshot({path:dir+'/'+screenshot,fullPage:true,animations:'disabled'});
   receipts.push({view,query:queries[i],http:response.status(),body,text,screenshot,screenshot_sha256:createHash('sha256').update(bytes).digest('hex'),errors:[...errors],production_accepted:false});
   await writeFile(dir+'/receipt.json',JSON.stringify({oracle,receipts},null,2)+'\n');
  }
  await context.close();
 }
} finally {await browser.close();}
console.log(JSON.stringify({actual_captures:receipts.length,errors:receipts.flatMap(r=>r.errors),qualified_games:123,publication_accepted:false}));
