# Raw Query Answer QA Product Review

## Run Metadata And Review Status

- Run ID: `r2_validation`
- Scope: `custom_selection`
- Corpus: `qa/raw_query_answer_corpus.yaml`
- Cases run: `621`
- Source commit: `b8e3a6a18605f11c9578ec5f1dd8960731bc2497`
- Source tree clean: `True`
- Corpus SHA-256: `d9dd6f96cca4bfa15f19b6b805dd1d1f9d507d881853dcfee2e3b41e73cb964f`
- Selected-case content SHA-256: `3ccf3023c6d859b956b46f029286157ac8e3e0d58144f5045d9a7565704b7f11`
- Review-output SHA-256: `87ecd0fb79bcc26ebed45ff1de76cc184054c4e02f7d7645abc2ba0815ec1e95`
- Data generation: `availability-lebron-season-v1-20261031`
- Family registry surface: `public_query_acceptance`
- Machine regression: `fail`
- Coverage review: `missing_variants`
- Human review declaration: `human_review_pending`
- Closure integrity: `not_declared`

Machine regression passing does not mean coverage review, human review, or public acceptance is complete.

## Feature-Family Summary

| Family | Public | Cases | Machine pass/fail | Required variants | Covered variants | Missing variants | Coverage review | Human review | Public accepted |
|---|---|---:|---|---|---|---|---|---|---|
| Player stats this season | yes | 12 | 12 pass / 0 fail | canonical, short, sentence, synonym, inverse_sibling, nearby_unsupported, typo_partial | canonical, inverse_sibling, nearby_unsupported, sentence, short, synonym, typo_partial | none | complete | pending | no |
| Team records | yes | 22 | 22 pass / 0 fail | canonical, short, sentence, synonym, inverse_sibling, nearby_unsupported, typo_partial | canonical, inverse_sibling, sentence, short, synonym, typo_partial | nearby_unsupported | missing_variants | pending | no |
| Team record with or without player | yes | 12 | 9 pass / 3 fail | canonical, short, sentence, synonym, inverse_sibling, nearby_unsupported, typo_partial | canonical, inverse_sibling, nearby_unsupported, sentence, short, synonym, typo_partial | none | complete | pending | no |
| Player summaries and recent form | yes | 7 | 7 pass / 0 fail | canonical, short, sentence, synonym, inverse_sibling, nearby_unsupported, typo_partial | canonical, inverse_sibling, nearby_unsupported, sentence, short, synonym, typo_partial | none | complete | pending | no |
| Leaderboards | yes | 10 | 10 pass / 0 fail | canonical, short, sentence, synonym, inverse_sibling, nearby_unsupported, typo_partial | canonical, inverse_sibling, nearby_unsupported, sentence, short, synonym, typo_partial | none | complete | pending | no |
| Top single-game performances | yes | 13 | 13 pass / 0 fail | canonical, short, sentence, synonym, inverse_sibling, nearby_unsupported, typo_partial | canonical, inverse_sibling, nearby_unsupported, sentence, short, synonym, typo_partial | none | complete | pending | no |
| Count queries | yes | 16 | 16 pass / 0 fail | canonical, short, sentence, synonym, inverse_sibling, nearby_unsupported, typo_partial | canonical, inverse_sibling, nearby_unsupported, sentence, short, synonym, typo_partial | none | complete | pending | no |
| Game finders | yes | 32 | 32 pass / 0 fail | canonical, short, sentence, synonym, inverse_sibling, nearby_unsupported, typo_partial | canonical, inverse_sibling, nearby_unsupported, sentence, short, synonym, typo_partial | none | complete | pending | no |
| Splits | yes | 8 | 8 pass / 0 fail | canonical, short, sentence, synonym, inverse_sibling, nearby_unsupported, typo_partial | canonical, inverse_sibling, nearby_unsupported, sentence, short, synonym, typo_partial | none | complete | pending | no |
| Streaks | yes | 15 | 15 pass / 0 fail | canonical, short, sentence, synonym, inverse_sibling, nearby_unsupported, typo_partial | canonical, inverse_sibling, nearby_unsupported, sentence, short, synonym, typo_partial | none | complete | pending | no |
| Rolling stretches | yes | 11 | 11 pass / 0 fail | canonical, short, sentence, synonym, inverse_sibling, nearby_unsupported, typo_partial | canonical, inverse_sibling, nearby_unsupported, sentence, short, synonym, typo_partial | none | complete | pending | no |
| Comparisons | yes | 18 | 18 pass / 0 fail | canonical, short, sentence, synonym, inverse_sibling, nearby_unsupported, typo_partial | canonical, inverse_sibling, nearby_unsupported, sentence, short, synonym, typo_partial | none | complete | pending | no |
| Playoff history | yes | 18 | 18 pass / 0 fail | canonical, short, sentence, synonym, inverse_sibling, nearby_unsupported, typo_partial | canonical, inverse_sibling, sentence, short, synonym, typo_partial | nearby_unsupported | missing_variants | pending | no |
| Date and window filters | yes | 7 | 7 pass / 0 fail | canonical, short, sentence, synonym, inverse_sibling, nearby_unsupported, typo_partial | canonical, inverse_sibling, nearby_unsupported, sentence, short, synonym, typo_partial | none | complete | pending | no |
| Unsupported subjective and narrative questions | no | 7 | 7 pass / 0 fail | canonical, short, sentence, synonym, inverse_sibling, nearby_unsupported, typo_partial | canonical, inverse_sibling, nearby_unsupported, sentence, short, synonym, typo_partial | none | complete | pending | no |
| Typo and partial-entity guardrails | no | 2 | 2 pass / 0 fail | canonical, short, sentence, synonym, inverse_sibling, nearby_unsupported, typo_partial | short, typo_partial | none | complete | pending | no |

## Missing / Unchecked Variant Checklist

| Family | Variant | State | Cases | Reason |
|---|---|---|---|---|
| player_stats_this_season | canonical | covered | `luka_stats_this_season_public_sweep`, `k12_s1`, `k12_n1`, `k12_h1` |  |
| player_stats_this_season | short | covered | `jokic_season_summary` |  |
| player_stats_this_season | sentence | covered | `pqa_player_stats_sentence_luka_played` |  |
| player_stats_this_season | synonym | covered | `pqa_player_stats_synonym_luka_averages` |  |
| player_stats_this_season | inverse_sibling | covered | `luka_40_point_count` |  |
| player_stats_this_season | nearby_unsupported | covered | `a01_salary_contract_boundary`, `mvp_candidates_subjective` |  |
| player_stats_this_season | typo_partial | covered | `pqa_player_stats_typo_jokc`, `pqa_typo_synonym_stephn_averages` |  |
| team_records | canonical | covered | `celtics_overall_record`, `medical_subject_team_unavailable`, `medical_subject_team_played_control`, `k12_r1` |  |
| team_records | short | covered | `pqa_team_record_short_celtics_record` |  |
| team_records | sentence | covered | `lakers_how_did_road_last_season_wave5` |  |
| team_records | synonym | covered | `team_record_thunder_top_10_teams_006`, `team_record_celtics_top_5_teams_006`, `team_record_bucks_losing_teams_006`, `team_record_suns_bad_teams_006`, `team_record_lakers_playoff_teams_006`, `team_record_nuggets_winning_teams_006`, `team_record_knicks_over_500_006`, `lakers_road_record_last_season`, `celtics_atlantic_division_guard`, `k12_r1_win_loss` |  |
| team_records | inverse_sibling | covered | `team_record_mavericks_west_playoff_teams_006`, `warriors_lakers_record_this_season_wave5`, `record_against_northwest_division_teams_guard`, `playoff_record_against_northwest_division_teams_guard`, `k09_w1_last_n_control` |  |
| team_records | nearby_unsupported | missing |  |  |
| team_records | typo_partial | covered | `pqa_team_record_typo_celtcs` |  |
| team_record_availability | canonical | covered | `lakers_record_with_luka_public_sweep`, `original_window_played_pair_source_empty`, `original_window_played_pair_source_positive`, `original_window_played_pair_source_qualifying` |  |
| team_record_availability | short | covered | `pqa_availability_short_lakers_w_luka` |  |
| team_record_availability | sentence | covered | `pqa_availability_sentence_luka_plays` |  |
| team_record_availability | synonym | covered | `lakers_record_with_reaves_public_sweep`, `pqa_availability_synonym_reaves_available` |  |
| team_record_availability | inverse_sibling | covered | `lakers_record_without_luka_public_sweep` |  |
| team_record_availability | nearby_unsupported | covered | `lakers_record_with_reaves_without_luka_public_sweep`, `team_leading_scorer_with_absence_unsupported` |  |
| team_record_availability | typo_partial | covered | `lakers_record_without_luk_public_sweep` |  |
| player_summaries_recent_form | canonical | covered | `tatum_recent_form` |  |
| player_summaries_recent_form | short | covered | `luka_last_10_summary_wave5` |  |
| player_summaries_recent_form | sentence | covered | `tatum_good_teams` |  |
| player_summaries_recent_form | synonym | covered | `kd_ts_top_defenses_missing_filters` |  |
| player_summaries_recent_form | inverse_sibling | covered | `tatum_brown_last10_comparison_wave4` |  |
| player_summaries_recent_form | nearby_unsupported | covered | `best_player_lately_ambiguous` |  |
| player_summaries_recent_form | typo_partial | covered | `pqa_player_recent_typo_tatm` |  |
| leaderboards | canonical | covered | `points_per_game_leader`, `k12_b1` |  |
| leaderboards | short | covered | `leaders_in_steals_wave5` |  |
| leaderboards | sentence | covered | `centers_rebound_leaders_wave4` |  |
| leaderboards | synonym | covered | `true_shooting_leaders_phrase_wave5` |  |
| leaderboards | inverse_sibling | covered | `most_assists_single_game` |  |
| leaderboards | nearby_unsupported | covered | `rookie_scoring_leaders_wave4`, `efficient_thirty_point_games_unexecutable`, `forty_point_games_injury_condition_unsupported` |  |
| leaderboards | typo_partial | covered | `pqa_leaderboard_stat_typo_pionts` |  |
| top_single_game_performances | canonical | covered | `biggest_scoring_games`, `k11_l1`, `k11_l2` |  |
| top_single_game_performances | short | covered | `most_rebounds_single_game` |  |
| top_single_game_performances | sentence | covered | `most_rebounds_single_game_this_year_public_sweep`, `highest_team_scoring_games_single_game_007` |  |
| top_single_game_performances | synonym | covered | `top_scoring_games_single_game_007`, `pqa_top_games_synonym_single_game_rebounds` |  |
| top_single_game_performances | inverse_sibling | covered | `rebound_leaders_this_season`, `most_points_by_team_in_game_007`, `highest_scoring_teams_season_leader_boundary_007` |  |
| top_single_game_performances | nearby_unsupported | covered | `biggest_team_three_point_games_boundary` |  |
| top_single_game_performances | typo_partial | covered | `pqa_top_games_stat_typo_rebunds` |  |
| count_queries | canonical | covered | `jokic_triple_double_count`, `team_compound_occurrence_elliptical_verbs`, `two_threshold_player_condition_unexecutable`, `k12_c1`, `k12_z1` |  |
| count_queries | short | covered | `pqa_count_short_lebron_triple_doubles` |  |
| count_queries | sentence | covered | `a06_boolean_count_top_level_or`, `celtics_120_15_threes_count_missing_filter` |  |
| count_queries | synonym | covered | `a06_boolean_count_grouped_or`, `players_10_assist_count` |  |
| count_queries | inverse_sibling | covered | `jokic_30_10_10_finder` |  |
| count_queries | nearby_unsupported | covered | `a01_multi_player_both_play_count_boundary`, `a02_team_clutch_count_coverage_boundary`, `a02_player_clutch_count_coverage_boundary`, `pqa_count_unsupported_players_played` |  |
| count_queries | typo_partial | covered | `pqa_count_typo_jokc_triple_doubles` |  |
| game_finders | canonical | covered | `jokic_30_points_10_assists_finder_misparsed`, `latest_original_both_source_false`, `latest_original_both_source_true`, `qualified_scalar_played_source_yes`, `qualified_scalar_played_source_dnp_no`, `qualified_scalar_played_source_unknown`, `qualified_original_minutes_source_dnp_no`, `qualified_original_minutes_source_exact_no`, `qualified_original_minutes_source_exact_yes`, `qualified_original_minutes_source_unknown`, `qualified_original_stat_pair_source_yes`, `qualified_original_stat_pair_source_dnp_no`, `qualified_original_stat_pair_source_unknown`, `k11_t1`, `k11_t2`, `k11_r1`, `k11_r2`, `k11_p1`, `k11_p2`, `k11_p3`, `k11_c1`, `k12_l1`, `k12_e1` |  |
| game_finders | short | covered | `curry_5_threes_finder` |  |
| game_finders | sentence | covered | `pqa_finder_sentence_tatum_35_5_threes`, `k11_r2_leading_season` |  |
| game_finders | synonym | covered | `pqa_finder_synonym_show_lakers_home_losses`, `qualified_original_stat_pair_source_no`, `qualified_original_stat_pair_source_zero` |  |
| game_finders | inverse_sibling | covered | `anthony_edwards_last_10_summary_no_match` |  |
| game_finders | nearby_unsupported | covered | `celtics_bench_scoring_boundary_wave4` |  |
| game_finders | typo_partial | covered | `pqa_finder_typo_curr_5_threes` |  |
| splits | canonical | covered | `jokic_home_away_split`, `k12_x1` |  |
| splits | short | covered | `celtics_wins_losses_split` |  |
| splits | sentence | covered | `anthony_edwards_wins_losses_split_no_match` |  |
| splits | synonym | covered | `curry_home_away_last_20_split_wave4` |  |
| splits | inverse_sibling | covered | `knicks_road_record` |  |
| splits | nearby_unsupported | covered | `pqa_split_unsupported_celtics_bench_home_away` |  |
| splits | typo_partial | covered | `pqa_split_typo_jokc_home_away` |  |
| streaks | canonical | covered | `jokic_5_straight_20_points`, `k09_t1`, `k09_p1`, `k09_r1`, `k09_r2`, `k09_c1`, `k09_c2` |  |
| streaks | short | covered | `lakers_win_streak` |  |
| streaks | sentence | covered | `pqa_streak_sentence_curry_3_threes` |  |
| streaks | synonym | covered | `thunder_110_point_streak`, `k09_r2_synonym_control` |  |
| streaks | inverse_sibling | covered | `curry_5_threes_count`, `k09_c2_single_season_control` |  |
| streaks | nearby_unsupported | covered | `cooled_off_lately_wave5` |  |
| streaks | typo_partial | covered | `pqa_streak_typo_jok_longest` |  |
| rolling_stretches | canonical | covered | `hottest_3_game_scoring_stretch`, `k09_w1`, `k09_w2` |  |
| rolling_stretches | short | covered | `booker_4_game_scoring_stretch` |  |
| rolling_stretches | sentence | covered | `pqa_stretch_sentence_game_score` |  |
| rolling_stretches | synonym | covered | `efficient_10_game_stretch`, `team_net_rating_stretch_unsupported` |  |
| rolling_stretches | inverse_sibling | covered | `team_5_game_scoring_stretch`, `k09_w2_last_n_control` |  |
| rolling_stretches | nearby_unsupported | covered | `team_game_score_stretch_unsupported` |  |
| rolling_stretches | typo_partial | covered | `pqa_stretch_typo_bookr` |  |
| comparisons | canonical | covered | `lebron_durant_comparison_wave4`, `player_comparison_team_scope_source_primary`, `player_comparison_team_scope_source_count_partial_empty`, `player_comparison_team_scope_source_count_empty`, `medical_subject_comparison_unavailable`, `k12_m1` |  |
| comparisons | short | covered | `jokic_embiid_recent_comparison` |  |
| comparisons | sentence | covered | `compare_lebron_durant_wave5`, `question_form_lebron_durant_comparison_wave2b`, `player_comparison_team_scope_source_question` |  |
| comparisons | synonym | covered | `celtics_bucks_comparison_this_season_wave5` |  |
| comparisons | inverse_sibling | covered | `lebron_stats_vs_durant_wave5` |  |
| comparisons | nearby_unsupported | covered | `bare_lebron_kd_ambiguous_boundary_v1`, `bare_lebron_durant_ambiguous_boundary_v1`, `bare_jokic_embiid_ambiguous_boundary_v1`, `pqa_comparison_subjective_better_jokic_embiid` |  |
| comparisons | typo_partial | covered | `pqa_comparison_typo_kevn_durant`, `player_comparison_team_scope_unresolved_operand` |  |
| playoff_history | canonical | covered | `lakers_playoff_history`, `k10_g1`, `k10_s1`, `k10_a1`, `k10_r1`, `k10_q1`, `k10_f1`, `k10_t1`, `k10_t2` |  |
| playoff_history | short | covered | `lakers_finals_appearances`, `bulls_finals_record_wave4` |  |
| playoff_history | sentence | covered | `a03_player_finals_appearances_boundary`, `lakers_celtics_playoff_matchup_history_wave5` |  |
| playoff_history | synonym | covered | `heat_knicks_playoff_series_record_wave4`, `k10_f1_seattle`, `k10_s1_postseason` |  |
| playoff_history | inverse_sibling | covered | `celtics_record_playoff_teams` |  |
| playoff_history | nearby_unsupported | missing |  |  |
| playoff_history | typo_partial | covered | `pqa_playoff_typo_lakeers_history` |  |
| date_window_filters | canonical | covered | `top_scorers_in_march` |  |
| date_window_filters | short | covered | `luka_last_5_summary` |  |
| date_window_filters | sentence | covered | `specific_date_jan_1` |  |
| date_window_filters | synonym | covered | `jokic_since_all_star_break` |  |
| date_window_filters | inverse_sibling | covered | `most_points_last_night` |  |
| date_window_filters | nearby_unsupported | covered | `pqa_date_unsupported_since_trade_deadline` |  |
| date_window_filters | typo_partial | covered | `pqa_date_typo_marhc` |  |
| unsupported_subjective_narrative | canonical | covered | `best_defender_subjective` |  |
| unsupported_subjective_narrative | short | covered | `pqa_subjective_short_mvp_candidates` |  |
| unsupported_subjective_narrative | sentence | covered | `cooled_off_last_10` |  |
| unsupported_subjective_narrative | synonym | covered | `most_clutch_player_wave5` |  |
| unsupported_subjective_narrative | inverse_sibling | covered | `tatum_clutch_stats` |  |
| unsupported_subjective_narrative | nearby_unsupported | covered | `best_duo_unsupported` |  |
| unsupported_subjective_narrative | typo_partial | covered | `pqa_subjective_typo_defnder` |  |
| typo_partial_entity_behavior | canonical | not_applicable |  | Domain-specific typo guards belong to their owning feature families. |
| typo_partial_entity_behavior | short | covered | `pqa_typo_short_jokc_stats` |  |
| typo_partial_entity_behavior | sentence | not_applicable |  | Domain-specific typo guards belong to their owning feature families. |
| typo_partial_entity_behavior | synonym | not_applicable |  | Domain-specific typo guards belong to their owning feature families. |
| typo_partial_entity_behavior | inverse_sibling | not_applicable |  | Domain-specific typo guards belong to their owning feature families. |
| typo_partial_entity_behavior | nearby_unsupported | not_applicable |  | Domain-specific typo guards belong to their owning feature families. |
| typo_partial_entity_behavior | typo_partial | covered | `pqa_typo_team_lakeers_record` |  |

## Representative Outputs Requiring Human Review

### jokic_triple_double_count

#### jokic_triple_double_count

**Query**  
How often has Nikola Jokic recorded a triple-double this season?

**Answer shown**  
Nikola Jokić has recorded 34 triple-doubles this season.

**Rendered output**

##### Table — Player Game Detail

Subject: Nikola Jokić  
Mode: Player game log  
Filter: Special Event: Triple Double  
Table type: player_game_log  
Column schema: player_game_log_default  
Rows: 34  

| # | Date | TM |  | Opp | W/L | MIN | PTS | REB | AST | FG | 3P | FT | STL | BLK | TOV | +/- | TS% | eFG% |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Apr 8 | DEN |  | MEM | W | 31 | 14 | 16 | 10 | — | — | — | 2 | 0 | 2 | 24 | 68.6% | 62.5% |
| 2 | Apr 6 | DEN |  | POR | W | 43 | 35 | 14 | 13 | — | — | — | 5 | 2 | 6 | 5 | 53.4% | 50.0% |
| 3 | Apr 1 | DEN |  | UTA | W | 33 | 15 | 17 | 12 | — | — | — | 0 | 0 | 5 | 10 | 57.3% | 50.0% |

- Query: `How often has Nikola Jokic recorded a triple-double this season?`
- Family / concept / variant: `count_queries` / `player_event_count` / `canonical`
- Review role: `representative`
- Sibling of: `<none>`
- Expected route / status / shape: `player_game_finder` / `ok` / `count_with_finder`
- Actual route / status / shape: `player_game_finder` / `ok` / `count_with_finder`
- Machine expectation status: `pass`
- Backend answer text: Nikola Jokić has recorded 34 triple-doubles this season.
- Answer summary: Count: 34
- Filters: `Special Event=Triple Double (special_event)`
- Sections: `count` 1 row(s), `finder` 34 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### points_per_game_leader

#### points_per_game_leader

**Query**  
Who leads the NBA in points per game this season?

**Answer shown**  
Luka Dončić led with 33.5 pts per game.

**Rendered output**

##### Table — Leaderboard

Subject: League  
Mode: Leaderboard  
Table type: leaderboard  
Column schema: leaderboard_default  
Rows: 10  

| # | Player | PPG | Season | TM | GP | Type |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | Luka Dončić | 33.5 | 2025-26 | LAL | 64 | Regular Season |
| 2 | Shai Gilgeous-Alexander | 31.1 | 2025-26 | OKC | 68 | Regular Season |
| 3 | Anthony Edwards | 28.8 | 2025-26 | MIN | 61 | Regular Season |

- Query: `Who leads the NBA in points per game this season?`
- Family / concept / variant: `leaderboards` / `player_season_per_game_leader` / `canonical`
- Review role: `representative`
- Sibling of: `<none>`
- Expected route / status / shape: `season_leaders` / `ok` / `leaderboard_table`
- Actual route / status / shape: `season_leaders` / `ok` / `leaderboard_table`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Top row: Luka Dončić -- LAL
- Filters: _none_
- Sections: `leaderboard` 10 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### team_record_thunder_top_10_teams_006

#### team_record_thunder_top_10_teams_006

**Query**  
Thunder record vs top 10 teams

**Answer shown**  
The Oklahoma City Thunder are 18-10 in 2025-26 Regular Season, a 64.3% win rate.

**Rendered output**

##### Card — Team Record

Subject: Oklahoma City Thunder  
Mode: Team record  
Filter: Opponent quality: top 10 teams  
Record: 18-10  
Games: 28  
Win %: 64.3%  
PPG: 115.5  
+/-: 5.4  

##### Table — Team record

Subject: Oklahoma City Thunder  
Mode: Team record  
Filter: Opponent quality: top 10 teams  
Table type: record_summary  
Column schema: team_record_summary_default  
Rows: 1  

| Team | W-L | Games | Win % | PPG | +/- | Opponent Group |
| --- | --- | --- | --- | --- | --- | --- |
| Oklahoma City Thunder | 18-10 | 28 | 64.3% | 115.5 | 5.4 | top 10 teams |

- Query: `Thunder record vs top 10 teams`
- Family / concept / variant: `team_records` / `opponent_quality_team_record` / `synonym`
- Review role: `representative`
- Sibling of: `<none>`
- Expected route / status / shape: `team_record` / `ok` / `team_record`
- Actual route / status / shape: `team_record` / `ok` / `team_record`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Oklahoma City Thunder -- 18-10 over 28 games, 115.536 PPG, 42.571 RPG, 24.75 APG, Regular Season
- Filters: `Opponent quality=top 10 teams (quality)`
- Sections: `summary` 1 row(s), `by_season` 1 row(s)
- Manual review status: `pass`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### team_record_celtics_top_5_teams_006

#### team_record_celtics_top_5_teams_006

**Query**  
Celtics record vs top 5 teams

**Answer shown**  
The Boston Celtics are 2-8 in 2025-26 Regular Season, a 20% win rate.

**Rendered output**

##### Card — Team Record

Subject: Boston Celtics  
Mode: Team record  
Filter: Opponent quality: top 5 teams  
Record: 2-8  
Games: 10  
Win %: 20.0%  
PPG: 106.4  
+/-: -4.0  

##### Table — Team record

Subject: Boston Celtics  
Mode: Team record  
Filter: Opponent quality: top 5 teams  
Table type: record_summary  
Column schema: team_record_summary_default  
Rows: 1  

| Team | W-L | Games | Win % | PPG | +/- | Opponent Group |
| --- | --- | --- | --- | --- | --- | --- |
| Boston Celtics | 2-8 | 10 | 20.0% | 106.4 | -4.0 | top 5 teams |

- Query: `Celtics record vs top 5 teams`
- Family / concept / variant: `team_records` / `opponent_quality_team_record` / `synonym`
- Review role: `supporting`
- Sibling of: `<none>`
- Expected route / status / shape: `team_record` / `ok` / `team_record`
- Actual route / status / shape: `team_record` / `ok` / `team_record`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Boston Celtics -- 2-8 over 10 games, 106.4 PPG, 44.1 RPG, 19.8 APG, Regular Season
- Filters: `Opponent quality=top 5 teams (quality)`
- Sections: `summary` 1 row(s), `by_season` 1 row(s)
- Manual review status: `pass`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### team_record_bucks_losing_teams_006

#### team_record_bucks_losing_teams_006

**Query**  
Bucks record against losing teams

**Answer shown**  
The Milwaukee Bucks are 18-10 in 2025-26 Regular Season, a 64.3% win rate.

**Rendered output**

##### Card — Team Record

Subject: Milwaukee Bucks  
Mode: Team record  
Filter: Opponent quality: losing teams  
Record: 18-10  
Games: 28  
Win %: 64.3%  
PPG: 116.5  
+/-: 2.9  

##### Table — Team record

Subject: Milwaukee Bucks  
Mode: Team record  
Filter: Opponent quality: losing teams  
Table type: record_summary  
Column schema: team_record_summary_default  
Rows: 1  

| Team | W-L | Games | Win % | PPG | +/- | Opponent Group |
| --- | --- | --- | --- | --- | --- | --- |
| Milwaukee Bucks | 18-10 | 28 | 64.3% | 116.5 | 2.9 | losing teams |

- Query: `Bucks record against losing teams`
- Family / concept / variant: `team_records` / `opponent_quality_team_record` / `synonym`
- Review role: `supporting`
- Sibling of: `<none>`
- Expected route / status / shape: `team_record` / `ok` / `team_record`
- Actual route / status / shape: `team_record` / `ok` / `team_record`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Milwaukee Bucks -- 18-10 over 28 games, 116.464 PPG, 43.857 RPG, 26.929 APG, Regular Season
- Filters: `Opponent quality=losing teams (quality)`
- Sections: `summary` 1 row(s), `by_season` 1 row(s)
- Manual review status: `pass`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### team_record_suns_bad_teams_006

#### team_record_suns_bad_teams_006

**Query**  
Suns record vs bad teams

**Answer shown**  
The Phoenix Suns are 23-4 in 2025-26 Regular Season, a 85.2% win rate.

**Rendered output**

##### Card — Team Record

Subject: Phoenix Suns  
Mode: Team record  
Filter: Opponent quality: bad teams  
Record: 23-4  
Games: 27  
Win %: 85.2%  
PPG: 119.5  
+/-: 11.9  

##### Table — Team record

Subject: Phoenix Suns  
Mode: Team record  
Filter: Opponent quality: bad teams  
Table type: record_summary  
Column schema: team_record_summary_default  
Rows: 1  

| Team | W-L | Games | Win % | PPG | +/- | Opponent Group |
| --- | --- | --- | --- | --- | --- | --- |
| Phoenix Suns | 23-4 | 27 | 85.2% | 119.5 | 11.9 | bad teams |

- Query: `Suns record vs bad teams`
- Family / concept / variant: `team_records` / `opponent_quality_team_record` / `synonym`
- Review role: `supporting`
- Sibling of: `<none>`
- Expected route / status / shape: `team_record` / `ok` / `team_record`
- Actual route / status / shape: `team_record` / `ok` / `team_record`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Phoenix Suns -- 23-4 over 27 games, 119.481 PPG, 45.667 RPG, 27.333 APG, Regular Season
- Filters: `Opponent quality=bad teams (quality)`
- Sections: `summary` 1 row(s), `by_season` 1 row(s)
- Manual review status: `pass`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### team_record_lakers_playoff_teams_006

#### team_record_lakers_playoff_teams_006

**Query**  
Lakers record against playoff teams

**Answer shown**  
The Los Angeles Lakers are 27-26 in 2025-26 Regular Season, a 50.9% win rate.

**Rendered output**

##### Card — Team Record

Subject: Los Angeles Lakers  
Mode: Team record  
Filter: Opponent quality: playoff teams  
Record: 27-26  
Games: 53  
Win %: 50.9%  
PPG: 111.9  
+/-: -3.4  

##### Table — Team record

Subject: Los Angeles Lakers  
Mode: Team record  
Filter: Opponent quality: playoff teams  
Table type: record_summary  
Column schema: team_record_summary_default  
Rows: 1  

| Team | W-L | Games | Win % | PPG | +/- | Opponent Group |
| --- | --- | --- | --- | --- | --- | --- |
| Los Angeles Lakers | 27-26 | 53 | 50.9% | 111.9 | -3.4 | playoff teams |

- Query: `Lakers record against playoff teams`
- Family / concept / variant: `team_records` / `opponent_quality_team_record` / `synonym`
- Review role: `supporting`
- Sibling of: `<none>`
- Expected route / status / shape: `team_record` / `ok` / `team_record`
- Actual route / status / shape: `team_record` / `ok` / `team_record`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Los Angeles Lakers -- 27-26 over 53 games, 111.943 PPG, 39.377 RPG, 24.585 APG, Regular Season
- Filters: `Opponent quality=playoff teams (quality)`
- Sections: `summary` 1 row(s), `by_season` 1 row(s)
- Manual review status: `pass`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### team_record_nuggets_winning_teams_006

#### team_record_nuggets_winning_teams_006

**Query**  
Nuggets record vs winning teams

**Answer shown**  
The Denver Nuggets are 29-20 in 2025-26 Regular Season, a 59.2% win rate.

**Rendered output**

##### Card — Team Record

Subject: Denver Nuggets  
Mode: Team record  
Filter: Opponent quality: winning teams  
Record: 29-20  
Games: 49  
Win %: 59.2%  
PPG: 120.9  
+/-: 3.3  

##### Table — Team record

Subject: Denver Nuggets  
Mode: Team record  
Filter: Opponent quality: winning teams  
Table type: record_summary  
Column schema: team_record_summary_default  
Rows: 1  

| Team | W-L | Games | Win % | PPG | +/- | Opponent Group |
| --- | --- | --- | --- | --- | --- | --- |
| Denver Nuggets | 29-20 | 49 | 59.2% | 120.9 | 3.3 | winning teams |

- Query: `Nuggets record vs winning teams`
- Family / concept / variant: `team_records` / `opponent_quality_team_record` / `synonym`
- Review role: `supporting`
- Sibling of: `<none>`
- Expected route / status / shape: `team_record` / `ok` / `team_record`
- Actual route / status / shape: `team_record` / `ok` / `team_record`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Denver Nuggets -- 29-20 over 49 games, 120.857 PPG, 43.939 RPG, 28.163 APG, Regular Season
- Filters: `Opponent quality=winning teams (quality)`
- Sections: `summary` 1 row(s), `by_season` 1 row(s)
- Manual review status: `pass`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### team_record_knicks_over_500_006

#### team_record_knicks_over_500_006

**Query**  
Knicks record against teams over .500

**Answer shown**  
The New York Knicks are 29-23 in 2025-26 Regular Season, a 55.8% win rate.

**Rendered output**

##### Card — Team Record

Subject: New York Knicks  
Mode: Team record  
Filter: Opponent quality: teams over .500  
Record: 29-23  
Games: 52  
Win %: 55.8%  
PPG: 114.0  
+/-: 3.1  

##### Table — Team record

Subject: New York Knicks  
Mode: Team record  
Filter: Opponent quality: teams over .500  
Table type: record_summary  
Column schema: team_record_summary_default  
Rows: 1  

| Team | W-L | Games | Win % | PPG | +/- | Opponent Group |
| --- | --- | --- | --- | --- | --- | --- |
| New York Knicks | 29-23 | 52 | 55.8% | 114.0 | 3.1 | teams over .500 |

- Query: `Knicks record against teams over .500`
- Family / concept / variant: `team_records` / `opponent_quality_team_record` / `synonym`
- Review role: `supporting`
- Sibling of: `<none>`
- Expected route / status / shape: `team_record` / `ok` / `team_record`
- Actual route / status / shape: `team_record` / `ok` / `team_record`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: New York Knicks -- 29-23 over 52 games, 113.981 PPG, 44.923 RPG, 26.442 APG, Regular Season
- Filters: `Opponent quality=teams over .500 (quality)`
- Sections: `summary` 1 row(s), `by_season` 1 row(s)
- Manual review status: `pass`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### team_record_mavericks_west_playoff_teams_006

#### team_record_mavericks_west_playoff_teams_006

**Query**  
Mavericks record against West playoff teams

**Answer shown**  
The Dallas Mavericks are 9-27 in 2025-26 Regular Season, a 25% win rate.

**Rendered output**

##### Card — Team Record

Subject: Dallas Mavericks  
Mode: Team record  
Filter: Opponent conference: West; Opponent quality: playoff teams  
Record: 9-27  
Games: 36  
Win %: 25.0%  
PPG: 114.1  
+/-: -7.4  

##### Table — Team record

Subject: Dallas Mavericks  
Mode: Team record  
Filter: Opponent conference: West; Opponent quality: playoff teams  
Table type: record_summary  
Column schema: team_record_summary_default  
Rows: 1  

| Team | W-L | Games | Win % | PPG | +/- | Opponent Group |
| --- | --- | --- | --- | --- | --- | --- |
| Dallas Mavericks | 9-27 | 36 | 25.0% | 114.1 | -7.4 | playoff teams |

- Query: `Mavericks record against West playoff teams`
- Family / concept / variant: `team_records` / `compound_conference_opponent_quality_team_record` / `inverse_sibling`
- Review role: `boundary`
- Sibling of: `<none>`
- Expected route / status / shape: `team_record` / `ok` / `team_record`
- Actual route / status / shape: `team_record` / `ok` / `team_record`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Dallas Mavericks -- 9-27 over 36 games, 114.139 PPG, 41.972 RPG, 24.694 APG, Regular Season
- Filters: `Opponent conference=West (conference)`, `Opponent quality=playoff teams (quality)`
- Sections: `summary` 1 row(s), `by_season` 1 row(s)
- Manual review status: `pass`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### hottest_3_game_scoring_stretch

#### hottest_3_game_scoring_stretch

**Query**  
Which players have the hottest 3-game scoring stretch this year?

**Answer shown**  
Luka Dončić had the best 3-game stretch of 2025-26 by any player: 45.3 points per game from 2026-03-16 to 2026-03-19.

**Rendered output**

##### Table — Rolling Stretch

Subject: Luka Dončić  
Mode: rolling stretch  
Table type: leaderboard  
Column schema: leaderboard_default  
Rows: 10  

| Rank | Player Name | Team Abbr | Window Size | Stretch Metric | Window Start Date | Window End Date | Window Start Season | Games In Window | Window End Season |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Luka Dončić | LAL | 3 | pts | Mar 16 | Mar 19 | 2025-26 | 3 | 2025-26 |
| 2 | Kawhi Leonard | LAC | 3 | pts | Dec 28 | Jan 1 | 2025-26 | 3 | 2025-26 |
| 3 | Bam Adebayo | MIA | 3 | pts | Mar 6 | Mar 10 | 2025-26 | 3 | 2025-26 |

- Query: `Which players have the hottest 3-game scoring stretch this year?`
- Family / concept / variant: `rolling_stretches` / `player_rolling_stretch` / `canonical`
- Review role: `representative`
- Sibling of: `<none>`
- Expected route / status / shape: `player_stretch_leaderboard` / `ok` / `rolling_stretch`
- Actual route / status / shape: `player_stretch_leaderboard` / `ok` / `rolling_stretch`
- Machine expectation status: `pass`
- Backend answer text: Luka Dončić had the best 3-game stretch of 2025-26 by any player: 45.3 points per game from 2026-03-16 to 2026-03-19.
- Answer summary: Top row: Luka Dončić -- LAL
- Filters: _none_
- Sections: `leaderboard` 10 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### jokic_5_straight_20_points

#### jokic_5_straight_20_points

**Query**  
Jokic 5 straight games with 20+ points

**Answer shown**  
Top row: Nikola Jokić

**Rendered output**

##### Table — Streaks

Subject: Nikola Jokić  
Mode: streak table  
Table type: streak_table  
Column schema: streak_default  
Rows: 15  

| Rank | Player Name | Games | Wins | Losses | Pts Avg | Reb Avg | Ast Avg | Condition | Streak Length |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Nikola Jokić | 18 | 11 | 7 | 33.2 | 13.7 | 10.0 | pts&gt;=20 | 18 |
| 2 | Nikola Jokić | 17 | 9 | 8 | 31.5 | 13.5 | 9.9 | pts&gt;=20 | 17 |
| 3 | Nikola Jokić | 15 | 6 | 9 | 28.1 | 13.7 | 9.5 | pts&gt;=20 | 15 |

- Query: `Jokic 5 straight games with 20+ points`
- Family / concept / variant: `streaks` / `player_threshold_streak` / `canonical`
- Review role: `representative`
- Sibling of: `<none>`
- Expected route / status / shape: `player_streak_finder` / `ok` / `streak_table`
- Actual route / status / shape: `player_streak_finder` / `ok` / `streak_table`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: streak: Nikola Jokić -- 11 WINS
- Filters: `pts min=20.0 (threshold)`, `Season range=2023-24 – 2025-26 (season)`
- Sections: `streak` 15 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### lakers_playoff_history

#### lakers_playoff_history

**Query**  
Lakers playoff history

**Answer shown**  
From 1996-97 to 2025-26, the Los Angeles Lakers won 40 of 56 playoff series (169-121 in games), with 6 titles.

**Rendered output**

##### Table — Playoff History

Mode: history  
Table type: playoff_history  
Column schema: playoff_history_default  
Rows: 22  

| Season | Games | Wins | Losses | Win Pct | Deepest Round |
| --- | --- | --- | --- | --- | --- |
| 1996-97 | 9 | 4 | 5 | 44.4% | Second Round |
| 1997-98 | 13 | 7 | 6 | 53.8% | Conference Finals |
| 1998-99 | 8 | 3 | 5 | 37.5% | Second Round |

- Query: `Lakers playoff history`
- Family / concept / variant: `playoff_history` / `single_team_playoff_history` / `canonical`
- Review role: `representative`
- Sibling of: `<none>`
- Expected route / status / shape: `playoff_history` / `ok` / `playoff_history`
- Actual route / status / shape: `playoff_history` / `ok` / `playoff_history`
- Machine expectation status: `pass`
- Backend answer text: From 1996-97 to 2025-26, the Los Angeles Lakers won 40 of 56 playoff series (169-121 in games), with 6 titles.
- Answer summary: Los Angeles Lakers -- 169-121 over 290 games, Playoffs
- Filters: _none_
- Sections: `summary` 1 row(s), `by_season` 22 row(s), `series` 56 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### a01_salary_contract_boundary

#### a01_salary_contract_boundary

**Query**  
Jokic salary and contract

**Answer shown**  
No answer returned.

**Rendered output**

##### Message — No result

No answer rows returned; reason=filter_not_supported.  

- Query: `Jokic salary and contract`
- Family / concept / variant: `player_stats_this_season` / `salary_contract_boundary` / `nearby_unsupported`
- Review role: `boundary`
- Sibling of: `<none>`
- Expected route / status / shape: `<none>` / `no_result` / `no_result`
- Actual route / status / shape: `<none>` / `no_result` / `no_result`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: No answer rows returned; reason=filter_not_supported
- Filters: _none_
- Sections: _none_
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### a01_multi_player_both_play_count_boundary

#### a01_multi_player_both_play_count_boundary

**Query**  
How many games did LeBron and Curry both play?

**Answer shown**  
No answer returned.

**Rendered output**

##### Message — No result

No answer rows returned; reason=filter_not_supported.  

- Query: `How many games did LeBron and Curry both play?`
- Family / concept / variant: `count_queries` / `multi_player_cooccurrence_boundary` / `nearby_unsupported`
- Review role: `boundary`
- Sibling of: `<none>`
- Expected route / status / shape: `<none>` / `no_result` / `no_result`
- Actual route / status / shape: `<none>` / `no_result` / `no_result`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: No answer rows returned; reason=filter_not_supported
- Filters: _none_
- Sections: _none_
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### a02_team_clutch_count_coverage_boundary

#### a02_team_clutch_count_coverage_boundary

**Query**  
How many Lakers games were clutch in 1996-97?

**Answer shown**  
No answer returned.

**Rendered output**

##### Message — No result

No answer rows returned; reason=filter_not_supported.  

- Query: `How many Lakers games were clutch in 1996-97?`
- Family / concept / variant: `count_queries` / `team_clutch_count_coverage_boundary` / `nearby_unsupported`
- Review role: `boundary`
- Sibling of: `<none>`
- Expected route / status / shape: `game_finder` / `no_result` / `no_result`
- Actual route / status / shape: `game_finder` / `no_result` / `no_result`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: No answer rows returned; reason=filter_not_supported
- Filters: `Clutch=True (situation)`
- Sections: _none_
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### a02_player_clutch_count_coverage_boundary

#### a02_player_clutch_count_coverage_boundary

**Query**  
How many Jokic games were clutch in 2025-26?

**Answer shown**  
No answer returned.

**Rendered output**

##### Message — No result

No answer rows returned; reason=filter_not_supported.  

- Query: `How many Jokic games were clutch in 2025-26?`
- Family / concept / variant: `count_queries` / `player_clutch_count_coverage_boundary` / `nearby_unsupported`
- Review role: `boundary`
- Sibling of: `<none>`
- Expected route / status / shape: `player_game_finder` / `no_result` / `no_result`
- Actual route / status / shape: `player_game_finder` / `no_result` / `no_result`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: No answer rows returned; reason=filter_not_supported
- Filters: `Clutch=True (situation)`
- Sections: _none_
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### a06_boolean_count_top_level_or

#### a06_boolean_count_top_level_or

**Query**  
How many LeBron games over 20 points or over 10 assists in 2024-25?

**Answer shown**  
LeBron James has had 52 matching games in the 2024-25 regular season.

**Rendered output**

##### Table — Player Game Detail

Subject: LeBron James  
Mode: Player game log  
Filter: pts min: 20 (exclusive); ast min: 10 (exclusive)  
Table type: player_game_log  
Column schema: player_game_log_default  
Rows: 52  

| # | Date | TM |  | Opp | W/L | MIN | PTS | REB | AST | FG | 3P | FT | STL | BLK | TOV | +/- | TS% | eFG% |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Apr 9 | LAL |  | DAL | W | 36 | 27 | 7 | 3 | — | — | — | 1 | 0 | 2 | 18 | 59.6% | 55.0% |
| 2 | Apr 8 | LAL |  | OKC | L | 35 | 28 | 7 | 3 | — | — | — | 1 | 0 | 6 | -23 | 59.8% | 50.0% |
| 3 | Apr 4 | LAL |  | NOP | W | 33 | 27 | 0 | 8 | — | — | — | 2 | 0 | 1 | 7 | 65.8% | 58.8% |

- Query: `How many LeBron games over 20 points or over 10 assists in 2024-25?`
- Family / concept / variant: `count_queries` / `boolean_or_count` / `sentence`
- Review role: `representative`
- Sibling of: `<none>`
- Expected route / status / shape: `player_game_finder` / `ok` / `count_with_finder`
- Actual route / status / shape: `player_game_finder` / `ok` / `count_with_finder`
- Machine expectation status: `pass`
- Backend answer text: LeBron James has had 52 matching games in the 2024-25 regular season.
- Answer summary: Count: 52
- Filters: `pts min=20 (exclusive) (threshold)`, `ast min=10 (exclusive) (threshold)`
- Sections: `count` 1 row(s), `finder` 52 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### a06_boolean_count_grouped_or

#### a06_boolean_count_grouped_or

**Query**  
How many LeBron games (over 20 points or over 10 assists) in 2024-25?

**Answer shown**  
LeBron James has had 52 matching games in the 2024-25 regular season.

**Rendered output**

##### Table — Player Game Detail

Subject: LeBron James  
Mode: Player game log  
Filter: pts min: 20 (exclusive); ast min: 10 (exclusive)  
Table type: player_game_log  
Column schema: player_game_log_default  
Rows: 52  

| # | Date | TM |  | Opp | W/L | MIN | PTS | REB | AST | FG | 3P | FT | STL | BLK | TOV | +/- | TS% | eFG% |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Apr 9 | LAL |  | DAL | W | 36 | 27 | 7 | 3 | — | — | — | 1 | 0 | 2 | 18 | 59.6% | 55.0% |
| 2 | Apr 8 | LAL |  | OKC | L | 35 | 28 | 7 | 3 | — | — | — | 1 | 0 | 6 | -23 | 59.8% | 50.0% |
| 3 | Apr 4 | LAL |  | NOP | W | 33 | 27 | 0 | 8 | — | — | — | 2 | 0 | 1 | 7 | 65.8% | 58.8% |

- Query: `How many LeBron games (over 20 points or over 10 assists) in 2024-25?`
- Family / concept / variant: `count_queries` / `boolean_or_count` / `synonym`
- Review role: `supporting`
- Sibling of: `a06_boolean_count_top_level_or`
- Expected route / status / shape: `player_game_finder` / `ok` / `count_with_finder`
- Actual route / status / shape: `player_game_finder` / `ok` / `count_with_finder`
- Machine expectation status: `pass`
- Backend answer text: LeBron James has had 52 matching games in the 2024-25 regular season.
- Answer summary: Count: 52
- Filters: `pts min=20 (exclusive) (threshold)`, `ast min=10 (exclusive) (threshold)`
- Sections: `count` 1 row(s), `finder` 52 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### most_rebounds_single_game_this_year_public_sweep

#### most_rebounds_single_game_this_year_public_sweep

**Query**  
Who had the most rebounds in a game this year?

**Answer shown**  
Scottie Barnes had the top rebounding game in 2025-26 Regular Season with 25 rebounds in a win against GSW on Dec 28.

**Rendered output**

##### Table — Top Performances

Subject: Players  
Mode: single-game player performances  
Table type: top_performances  
Column schema: top_performances_default  
Rows: 10  

| Rank | Player | Team | Date | Opp | W/L | REB | MIN | PTS | AST | FG | 3P |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Scottie Barnes | TOR | Dec 28 | GSW | W | 25 | 42 | 23 | 10 | — | — |
| 2 | Andre Drummond | PHI | Nov 23 | MIA | L | 24 | 38 | 14 | 1 | — | — |
| 3 | Jalen Duren | DET | Nov 5 | UTA | W | 22 | 35 | 22 | 3 | — | — |

- Query: `Who had the most rebounds in a game this year?`
- Family / concept / variant: `top_single_game_performances` / `player_single_game_stat_high` / `sentence`
- Review role: `representative`
- Sibling of: `<none>`
- Expected route / status / shape: `top_player_games` / `ok` / `top_performances`
- Actual route / status / shape: `top_player_games` / `ok` / `top_performances`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Top row: Scottie Barnes -- 25 REB, 2025-12-28 TOR vs GSW
- Filters: _none_
- Sections: `leaderboard` 10 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### top_scoring_games_single_game_007

#### top_scoring_games_single_game_007

**Query**  
top scoring games this season

**Answer shown**  
Bam Adebayo had the top scoring game this season with 83 points in a win against WAS on Mar 10.

**Rendered output**

##### Table — Top Performances

Subject: Players  
Mode: single-game player performances  
Table type: top_performances  
Column schema: top_performances_default  
Rows: 10  

| Rank | Player | Team | Date | Opp | W/L | PTS | MIN | REB | AST | FG | 3P |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Bam Adebayo | MIA | Mar 10 | WAS | W | 83 | 42 | 9 | 3 | — | — |
| 2 | Luka Dončić | LAL | Mar 19 | MIA | W | 60 | 38 | 7 | 3 | — | — |
| 3 | Nikola Jokić | DEN | Dec 25 | MIN | W | 56 | 43 | 16 | 15 | — | — |

- Query: `top scoring games this season`
- Family / concept / variant: `top_single_game_performances` / `player_single_game_stat_high` / `synonym`
- Review role: `representative`
- Sibling of: `<none>`
- Expected route / status / shape: `top_player_games` / `ok` / `top_performances`
- Actual route / status / shape: `top_player_games` / `ok` / `top_performances`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Top row: Bam Adebayo -- 83 PTS, 2026-03-10 MIA vs WAS
- Filters: _none_
- Sections: `leaderboard` 10 row(s)
- Manual review status: `pass`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### highest_team_scoring_games_single_game_007

#### highest_team_scoring_games_single_game_007

**Query**  
highest team scoring games this season

**Answer shown**  
Denver Nuggets had the top scoring game this season with 157 points in a 157-103 win against POR on Feb 20.

**Rendered output**

##### Table — Top Performances

Subject: Teams  
Mode: single-game team performances  
Table type: top_performances  
Column schema: top_performances_default  
Rows: 10  

| Rank | Team | Date | Opp | W/L | Score | PTS | Opp PTS | Margin | REB | AST | 3PM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Denver Nuggets | Feb 20 | POR | W | 157-103 | 157 | 103 | 54 | 60 | 41 | 21 |
| 2 | Philadelphia 76ers | Mar 25 | CHI | W | 157-137 | 157 | 137 | 20 | 45 | 34 | 22 |
| 3 | New Orleans Pelicans | Apr 7 | UTA | W | 156-137 | 156 | 137 | 19 | 48 | 32 | 14 |

- Query: `highest team scoring games this season`
- Family / concept / variant: `top_single_game_performances` / `team_single_game_stat_high` / `sentence`
- Review role: `representative`
- Sibling of: `<none>`
- Expected route / status / shape: `top_team_games` / `ok` / `top_performances`
- Actual route / status / shape: `top_team_games` / `ok` / `top_performances`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Top row: Denver Nuggets -- 157 PTS, 2026-02-20 DEN vs POR
- Filters: _none_
- Sections: `leaderboard` 10 row(s)
- Manual review status: `pass`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### most_points_by_team_in_game_007

#### most_points_by_team_in_game_007

**Query**  
most points by a team in a game this season

**Answer shown**  
Denver Nuggets had the top scoring game this season with 157 points in a 157-103 win against POR on Feb 20.

**Rendered output**

##### Table — Top Performances

Subject: Teams  
Mode: single-game team performances  
Table type: top_performances  
Column schema: top_performances_default  
Rows: 10  

| Rank | Team | Date | Opp | W/L | Score | PTS | Opp PTS | Margin | REB | AST | 3PM |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Denver Nuggets | Feb 20 | POR | W | 157-103 | 157 | 103 | 54 | 60 | 41 | 21 |
| 2 | Philadelphia 76ers | Mar 25 | CHI | W | 157-137 | 157 | 137 | 20 | 45 | 34 | 22 |
| 3 | New Orleans Pelicans | Apr 7 | UTA | W | 156-137 | 156 | 137 | 19 | 48 | 32 | 14 |

- Query: `most points by a team in a game this season`
- Family / concept / variant: `top_single_game_performances` / `team_single_game_stat_high` / `inverse_sibling`
- Review role: `boundary`
- Sibling of: `highest_scoring_teams_season_leader_boundary_007`
- Expected route / status / shape: `top_team_games` / `ok` / `top_performances`
- Actual route / status / shape: `top_team_games` / `ok` / `top_performances`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Top row: Denver Nuggets -- 157 PTS, 2026-02-20 DEN vs POR
- Filters: _none_
- Sections: `leaderboard` 10 row(s)
- Manual review status: `pass`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### highest_scoring_teams_season_leader_boundary_007

#### highest_scoring_teams_season_leader_boundary_007

**Query**  
highest scoring teams this season

**Answer shown**  
Denver Nuggets led with 122.1 pts per game.

**Rendered output**

##### Table — Leaderboard

Subject: Teams  
Mode: Leaderboard  
Table type: leaderboard  
Column schema: leaderboard_default  
Rows: 10  

| # | Team | PPG | Season | TM | GP | Type |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | Denver Nuggets | 122.1 | 2025-26 | DEN | 82 | Regular Season |
| 2 | Miami Heat | 120.9 | 2025-26 | MIA | 82 | Regular Season |
| 3 | San Antonio Spurs | 119.8 | 2025-26 | SAS | 82 | Regular Season |

- Query: `highest scoring teams this season`
- Family / concept / variant: `top_single_game_performances` / `season_team_scoring_leaderboard_sibling` / `inverse_sibling`
- Review role: `boundary`
- Sibling of: `most_points_by_team_in_game_007`
- Expected route / status / shape: `season_team_leaders` / `ok` / `leaderboard_table`
- Actual route / status / shape: `season_team_leaders` / `ok` / `leaderboard_table`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Top row: Denver Nuggets -- DEN
- Filters: _none_
- Sections: `leaderboard` 10 row(s)
- Manual review status: `pass`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### tatum_recent_form

#### tatum_recent_form

**Query**  
Jayson Tatum recent form

**Answer shown**  
Jayson Tatum -- 8-2 over 10 games, 22.4 PPG, 10.9 RPG, 6.1 APG

**Rendered output**

##### Card — Summary

Subject: Jayson Tatum  
Mode: entity summary  
Filter: Last N games: 10; Sample selection: Select the last 10 games matching the conditions  
Games: 10  
Record: 8-2  
PPG: 22.4  
RPG: 10.9  
APG: 6.1  

##### Table — By Season

Subject: Jayson Tatum  
Mode: season stats  
Filter: Last N games: 10; Sample selection: Select the last 10 games matching the conditions  
Table type: record_summary  
Column schema: player_by_season_default  
Rows: 1  

| Season | Games | Wins | Losses | PPG | REB | AST |
| --- | --- | --- | --- | --- | --- | --- |
| 2025-26 | 10 | 8 | 2 | 22.4 | 10.9 | 6.1 |

##### Table — Player Game Log

Subject: Jayson Tatum  
Mode: Player game log  
Filter: Last N games: 10; Sample selection: Select the last 10 games matching the conditions  
Table type: player_game_log  
Column schema: player_game_log_default  
Rows: 10  

| # | Date | TM |  | Opp | W/L | MIN | PTS | REB | AST | FG | 3P | FT | STL | BLK | TOV | +/- | TS% | eFG% |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Mar 20 | BOS |  | MEM | W | 31 | 13 | 9 | 0 | — | — | — | 0 | 0 | 3 | -5 | 36.8% | 26.7% |
| 2 | Mar 22 | BOS |  | MIN | L | 31 | 16 | 11 | 2 | — | — | — | 2 | 0 | 1 | -4 | 46.2% | 43.8% |
| 3 | Mar 25 | BOS |  | OKC | W | 35 | 19 | 12 | 7 | — | — | — | 3 | 1 | 5 | 2 | 64.9% | 54.2% |

- Query: `Jayson Tatum recent form`
- Family / concept / variant: `player_summaries_recent_form` / `player_recent_form_summary` / `canonical`
- Review role: `representative`
- Sibling of: `<none>`
- Expected route / status / shape: `player_game_summary` / `ok` / `entity_summary`
- Actual route / status / shape: `player_game_summary` / `ok` / `entity_summary`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Jayson Tatum -- 8-2 over 10 games, 22.4 PPG, 10.9 RPG, 6.1 APG, Regular Season
- Filters: `Last N games=10 (window)`, `Sample selection=Select the last 10 games matching the conditions (window)`
- Sections: `summary` 1 row(s), `by_season` 1 row(s), `game_log` 10 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### celtics_overall_record

#### celtics_overall_record

**Query**  
What is the Celtics record this season?

**Answer shown**  
The Boston Celtics are 56-26 in 2025-26 Regular Season, a 68.3% win rate.

**Rendered output**

##### Card — Team Record

Subject: Boston Celtics  
Mode: Team record  
Record: 56-26  
Games: 82  
Win %: 68.3%  
PPG: 114.9  
+/-: 7.7  

##### Table — Team record

Subject: Boston Celtics  
Mode: Team record  
Table type: record_summary  
Column schema: team_record_summary_default  
Rows: 1  

| Team | W-L | Games | Win % | PPG | +/- |
| --- | --- | --- | --- | --- | --- |
| Boston Celtics | 56-26 | 82 | 68.3% | 114.9 | 7.7 |

- Query: `What is the Celtics record this season?`
- Family / concept / variant: `team_records` / `single_team_record` / `canonical`
- Review role: `representative`
- Sibling of: `<none>`
- Expected route / status / shape: `team_record` / `ok` / `team_record`
- Actual route / status / shape: `team_record` / `ok` / `team_record`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Boston Celtics -- 56-26 over 82 games, 114.854 PPG, 46.366 RPG, 24.646 APG, Regular Season
- Filters: _none_
- Sections: `summary` 1 row(s), `by_season` 1 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### lakers_record_with_luka_public_sweep

#### lakers_record_with_luka_public_sweep

**Query**  
Lakers record with Luka

**Answer shown**  
The Los Angeles Lakers are 43-21 in 2025-26 Regular Season, a 67.2% win rate.

**Rendered output**

##### Card — Team Record

Subject: Los Angeles Lakers  
Mode: Team record  
Filter: With player: Luka Dončić  
Record: 43-21  
Games: 64  
Win %: 67.2%  
PPG: 116.9  
+/-: 2.6  

##### Table — Team record

Subject: Los Angeles Lakers  
Mode: Team record  
Filter: With player: Luka Dončić  
Table type: record_summary  
Column schema: team_record_summary_default  
Rows: 1  

| Team | W-L | Games | Win % | PPG | +/- |
| --- | --- | --- | --- | --- | --- |
| Los Angeles Lakers | 43-21 | 64 | 67.2% | 116.9 | 2.6 |

##### Detail — Game Detail

Subject: Los Angeles Lakers  
Mode: Team game log  
Filter: With player: Luka Dončić  
Table type: team_game_log  
Column schema: team_game_log_default  
Rows: 64  
Collapsed label: Show game detail  

| # | Date | Team |  | Opp | Score | W/L | PTS | Opp PTS | Margin | REB | AST | 3PM | FG | 3P | FT | TOV | STL | BLK | oreb | dreb |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Oct 21 | LAL |  | GSW | 109-119 | L | 109 | 119 | — | 39 | 23 | 8 | — | — | — | 19 | 7 | 2 | 7 | 32 |
| 2 | Oct 24 | LAL |  | MIN | 128-110 | W | 128 | 110 | — | 38 | 26 | 12 | — | — | — | 10 | 6 | 3 | 7 | 31 |
| 3 | Oct 31 | LAL |  | MEM | 117-112 | W | 117 | 112 | — | 40 | 24 | 13 | — | — | — | 13 | 8 | 3 | 5 | 35 |

- Query: `Lakers record with Luka`
- Family / concept / variant: `team_record_availability` / `whole_game_player_presence` / `canonical`
- Review role: `representative`
- Sibling of: `<none>`
- Expected route / status / shape: `team_record` / `ok` / `team_record`
- Actual route / status / shape: `team_record` / `ok` / `team_record`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Los Angeles Lakers -- 43-21 over 64 games, 116.891 PPG, 41.438 RPG, 25.281 APG, Regular Season
- Filters: `With player=Luka Dončić (player)`
- Sections: `summary` 1 row(s), `by_season` 1 row(s), `game_log` 64 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### lakers_record_with_reaves_without_luka_public_sweep

#### lakers_record_with_reaves_without_luka_public_sweep

**Query**  
Lakers record with Reaves without Luka

**Answer shown**  
No answer returned.

**Rendered output**

##### Message — No result

No answer rows returned; reason=filter_not_supported.  

- Query: `Lakers record with Reaves without Luka`
- Family / concept / variant: `team_record_availability` / `multi_player_availability_boundary` / `nearby_unsupported`
- Review role: `boundary`
- Sibling of: `lakers_record_with_luka_public_sweep`
- Expected route / status / shape: `team_record` / `no_result` / `no_result`
- Actual route / status / shape: `team_record` / `no_result` / `no_result`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: No answer rows returned; reason=filter_not_supported
- Filters: _none_
- Sections: _none_
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### curry_5_threes_finder

#### curry_5_threes_finder

**Query**  
Curry 5+ threes this season

**Answer shown**  
Stephen Curry had 17 games matching this season.

**Rendered output**

##### Table — Player Game Detail

Subject: Stephen Curry  
Mode: Player game log  
Filter: fg3m min: 5.0  
Table type: player_game_log  
Column schema: player_game_log_default  
Rows: 17  

| # | Date | TM |  | Opp | W/L | MIN | PTS | REB | AST | FG | 3P | FT | STL | BLK | TOV | +/- | TS% | eFG% |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Dec 14 | GSW |  | POR | L | 35 | 48 | 3 | 2 | — | — | — | 3 | 1 | 3 | -8 | 86.5% | 84.6% |
| 2 | Nov 21 | GSW |  | POR | L | 34 | 38 | 2 | 4 | — | — | — | 0 | 0 | 3 | -3 | 81.1% | 80.4% |
| 3 | Nov 14 | GSW |  | SAS | W | 36 | 49 | 4 | 2 | — | — | — | 2 | 0 | 3 | 9 | 83.0% | 78.8% |

- Query: `Curry 5+ threes this season`
- Family / concept / variant: `game_finders` / `player_threshold_game_finder` / `short`
- Review role: `representative`
- Sibling of: `<none>`
- Expected route / status / shape: `player_game_finder` / `ok` / `<none>`
- Actual route / status / shape: `player_game_finder` / `ok` / `game_log_table`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Top row: Stephen Curry -- 12 FG3M, 2025-12-14 GSW vs POR
- Filters: `fg3m min=5.0 (threshold)`
- Sections: `finder` 17 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### a03_player_finals_appearances_boundary

#### a03_player_finals_appearances_boundary

**Query**  
How many Finals appearances does LeBron have?

**Answer shown**  
LeBron James reached the Finals in 10 seasons (2006-07, 2010-11, 2011-12, 2012-13, 2013-14, 2014-15, 2015-16, 2016-17, 2017-18, 2019-20).

**Rendered output**

##### Table — Leaderboard

Subject: League  
Mode: Leaderboard  
Table type: leaderboard  
Column schema: leaderboard_default  
Rows: 1  

| # | Player | Appearances | Season |
| --- | --- | --- | --- |
| 1 | LeBron James | 10 | 1996-97 to 2025-26 |

- Query: `How many Finals appearances does LeBron have?`
- Family / concept / variant: `playoff_history` / `player_round_appearances` / `sentence`
- Review role: `representative`
- Sibling of: `<none>`
- Expected route / status / shape: `playoff_appearances` / `ok` / `leaderboard_table`
- Actual route / status / shape: `playoff_appearances` / `ok` / `leaderboard_table`
- Machine expectation status: `pass`
- Backend answer text: LeBron James reached the Finals in 10 seasons (2006-07, 2010-11, 2011-12, 2012-13, 2013-14, 2014-15, 2015-16, 2016-17, 2017-18, 2019-20).
- Answer summary: Top row: LeBron James
- Filters: _none_
- Sections: `leaderboard` 1 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### top_scorers_in_march

#### top_scorers_in_march

**Query**  
top scorers in March

**Answer shown**  
Luka Dončić led with 37.5 pts per game.

**Rendered output**

##### Table — Leaderboard

Subject: League  
Mode: Leaderboard  
Filter: Date range: 2026-03-01 – 2026-03-31  
Table type: leaderboard  
Column schema: leaderboard_default  
Rows: 10  

| # | Player | PPG | Season | TM | GP | Type |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | Luka Dončić | 37.5 | 2025-26 | LAL | 16 | Regular Season |
| 2 | Shai Gilgeous-Alexander | 30.7 | 2025-26 | OKC | 14 | Regular Season |
| 3 | Joel Embiid | 30.0 | 2025-26 | PHI | 3 | Regular Season |

- Query: `top scorers in March`
- Family / concept / variant: `date_window_filters` / `month_window_leaderboard` / `canonical`
- Review role: `representative`
- Sibling of: `<none>`
- Expected route / status / shape: `season_leaders` / `ok` / `leaderboard_table`
- Actual route / status / shape: `season_leaders` / `ok` / `leaderboard_table`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Top row: Luka Dončić -- LAL
- Filters: `Date range=2026-03-01 – 2026-03-31 (date)`
- Sections: `leaderboard` 10 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### jokic_home_away_split

#### jokic_home_away_split

**Query**  
Jokic home vs away this season

**Answer shown**  
Nikola Jokić

**Rendered output**

##### Table — Split Comparison

Mode: player split  
Table type: split_comparison  
Column schema: split_comparison_default  
Rows: 2  

| Games | Wins | Losses | Win Pct | Pts Avg | Reb Avg | Ast Avg | Bucket | Minutes Avg | Stl Avg |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 33 | 24 | 9 | 72.7% | 27.6 | 12.6 | 11.2 | home | 34.6 | 1.5 |
| 32 | 19 | 13 | 59.4% | 27.8 | 13.1 | 10.2 | away | 35.1 | 1.3 |

- Query: `Jokic home vs away this season`
- Family / concept / variant: `splits` / `player_home_away_split` / `canonical`
- Review role: `representative`
- Sibling of: `<none>`
- Expected route / status / shape: `player_split_summary` / `ok` / `<none>`
- Actual route / status / shape: `player_split_summary` / `ok` / `entity_summary`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Nikola Jokić -- Regular Season
- Filters: `Location=Home (location)`, `Location=Away (location)`
- Sections: `summary` 1 row(s), `split_comparison` 2 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### jokic_embiid_recent_comparison

#### jokic_embiid_recent_comparison

**Query**  
Jokic vs Embiid recent form

**Answer shown**  
Nikola Jokić -- 10-0 over 10 games, 25.3 PPG, 14.5 RPG, 11.9 APG

**Rendered output**

##### Table — Comparison

Mode: player comparison  
Table type: comparison_table  
Column schema: comparison_default  
Rows: 20  

| Metric | Nikola Jokić | Joel Embiid |
| --- | --- | --- |
| games | 10 | 10 |
| wins | 10 | 7 |
| losses | 0 | 3 |

- Query: `Jokic vs Embiid recent form`
- Family / concept / variant: `comparisons` / `player_stat_comparison` / `short`
- Review role: `representative`
- Sibling of: `<none>`
- Expected route / status / shape: `player_compare` / `ok` / `comparison`
- Actual route / status / shape: `player_compare` / `ok` / `comparison`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Nikola Jokić -- 10-0 over 10 games, 25.3 PPG, 14.5 RPG, 11.9 APG, Regular Season
- Filters: `Last N games=10 (window)`, `Sample selection=Select the last 10 games matching the conditions (window)`
- Sections: `summary` 2 row(s), `comparison` 20 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### bare_lebron_kd_ambiguous_boundary_v1

#### bare_lebron_kd_ambiguous_boundary_v1

**Query**  
LeBron vs KD

**Answer shown**  
No answer returned.

**Rendered output**

##### Message — No result

No answer rows returned; reason=ambiguous_query.  

- Query: `LeBron vs KD`
- Family / concept / variant: `comparisons` / `ambiguous_vs_clarification_candidate` / `nearby_unsupported`
- Review role: `boundary`
- Sibling of: `<none>`
- Expected route / status / shape: `player_compare` / `no_result` / `no_result`
- Actual route / status / shape: `player_compare` / `no_result` / `no_result`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: No answer rows returned; reason=ambiguous_query
- Filters: _none_
- Sections: _none_
- Manual review status: `expected_unsupported`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### bare_lebron_durant_ambiguous_boundary_v1

#### bare_lebron_durant_ambiguous_boundary_v1

**Query**  
LeBron James vs Kevin Durant

**Answer shown**  
No answer returned.

**Rendered output**

##### Message — No result

No answer rows returned; reason=ambiguous_query.  

- Query: `LeBron James vs Kevin Durant`
- Family / concept / variant: `comparisons` / `ambiguous_vs_clarification_candidate` / `nearby_unsupported`
- Review role: `boundary`
- Sibling of: `lebron_durant_comparison_wave4`
- Expected route / status / shape: `player_compare` / `no_result` / `no_result`
- Actual route / status / shape: `player_compare` / `no_result` / `no_result`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: No answer rows returned; reason=ambiguous_query
- Filters: _none_
- Sections: _none_
- Manual review status: `expected_unsupported`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### bare_jokic_embiid_ambiguous_boundary_v1

#### bare_jokic_embiid_ambiguous_boundary_v1

**Query**  
Jokic vs Embiid

**Answer shown**  
No answer returned.

**Rendered output**

##### Message — No result

No answer rows returned; reason=ambiguous_query.  

- Query: `Jokic vs Embiid`
- Family / concept / variant: `comparisons` / `ambiguous_vs_clarification_candidate` / `nearby_unsupported`
- Review role: `boundary`
- Sibling of: `jokic_embiid_recent_comparison`
- Expected route / status / shape: `player_compare` / `no_result` / `no_result`
- Actual route / status / shape: `player_compare` / `no_result` / `no_result`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: No answer rows returned; reason=ambiguous_query
- Filters: _none_
- Sections: _none_
- Manual review status: `expected_unsupported`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### pqa_player_stats_sentence_luka_played

#### pqa_player_stats_sentence_luka_played

**Query**  
How has Luka Doncic played this season?

**Answer shown**  
Luka Dončić -- 43-21 over 64 games, 33.5 PPG, 7.7 RPG, 8.3 APG

**Rendered output**

##### Card — Summary

Subject: Luka Dončić  
Mode: entity summary  
Games: 64  
Record: 43-21  
PPG: 33.5  
RPG: 7.7  
APG: 8.3  

##### Table — By Season

Subject: Luka Dončić  
Mode: season stats  
Table type: record_summary  
Column schema: player_by_season_default  
Rows: 1  

| Season | Games | Wins | Losses | PPG | REB | AST |
| --- | --- | --- | --- | --- | --- | --- |
| 2025-26 | 64 | 43 | 21 | 33.5 | 7.7 | 8.3 |

- Query: `How has Luka Doncic played this season?`
- Family / concept / variant: `player_stats_this_season` / `player_season_summary` / `sentence`
- Review role: `representative`
- Sibling of: `<none>`
- Expected route / status / shape: `player_game_summary` / `ok` / `entity_summary`
- Actual route / status / shape: `player_game_summary` / `ok` / `entity_summary`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Luka Dončić -- 43-21 over 64 games, 33.484 PPG, 7.734 RPG, 8.281 APG, Regular Season
- Filters: _none_
- Sections: `summary` 1 row(s), `by_season` 1 row(s), `game_log` 64 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### team_compound_occurrence_elliptical_verbs

#### team_compound_occurrence_elliptical_verbs

**Query**  
teams with most games scoring 120+ and making 15+ threes since 2020

**Answer shown**  
Top row: BOS

**Rendered output**

##### Table — Leaderboard

Subject: Teams  
Mode: Leaderboard  
Filter: pts min: 120.0; fg3m min: 15.0; Season range: 2020-21 – 2025-26  
Table type: leaderboard  
Column schema: leaderboard_default  
Rows: 10  

| # | Team | Games Pts 120+ Fg3m 15+ | Season | TM | GP | Type |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | BOS | 157 | 2020-21 to 2025-26 | BOS | 482 | Regular Season |
| 2 | GSW | 140 | 2020-21 to 2025-26 | GSW | 482 | Regular Season |
| 3 | MIL | 117 | 2020-21 to 2025-26 | MIL | 482 | Regular Season |

- Query: `teams with most games scoring 120+ and making 15+ threes since 2020`
- Family / concept / variant: `count_queries` / `team_multi_threshold_occurrence_leaderboard` / `canonical`
- Review role: `supporting`
- Sibling of: `<none>`
- Expected route / status / shape: `team_occurrence_leaders` / `ok` / `leaderboard_table`
- Actual route / status / shape: `team_occurrence_leaders` / `ok` / `leaderboard_table`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Top row: BOS -- BOS
- Filters: `pts min=120.0 (threshold)`, `fg3m min=15.0 (threshold)`, `Season range=2020-21 – 2025-26 (season)`
- Sections: `leaderboard` 10 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### efficient_thirty_point_games_unexecutable

#### efficient_thirty_point_games_unexecutable

**Query**  
most efficient 30-point games

**Answer shown**  
No answer returned.

**Rendered output**

##### Message — No result

No answer rows returned; reason=filter_not_supported.  

- Query: `most efficient 30-point games`
- Family / concept / variant: `leaderboards` / `compound_ranking_metric_boundary` / `nearby_unsupported`
- Review role: `boundary`
- Sibling of: `<none>`
- Expected route / status / shape: `season_leaders` / `no_result` / `no_result`
- Actual route / status / shape: `season_leaders` / `no_result` / `no_result`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: No answer rows returned; reason=filter_not_supported
- Filters: _none_
- Sections: _none_
- Manual review status: `expected_unsupported`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### forty_point_games_injury_condition_unsupported

#### forty_point_games_injury_condition_unsupported

**Query**  
most 40-point games while the player was injured

**Answer shown**  
No answer returned.

**Rendered output**

##### Message — No result

No answer rows returned; reason=filter_not_supported.  

- Query: `most 40-point games while the player was injured`
- Family / concept / variant: `leaderboards` / `injury_availability_boundary` / `nearby_unsupported`
- Review role: `boundary`
- Sibling of: `<none>`
- Expected route / status / shape: `season_leaders` / `no_result` / `no_result`
- Actual route / status / shape: `season_leaders` / `no_result` / `no_result`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: No answer rows returned; reason=filter_not_supported
- Filters: _none_
- Sections: _none_
- Manual review status: `expected_unsupported`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### team_leading_scorer_with_absence_unsupported

#### team_leading_scorer_with_absence_unsupported

**Query**  
Lakers leading scorer while LeBron was out

**Answer shown**  
No answer returned.

**Rendered output**

##### Message — No result

No answer rows returned; reason=filter_not_supported.  

- Query: `Lakers leading scorer while LeBron was out`
- Family / concept / variant: `team_record_availability` / `team_scoped_leader_availability_boundary` / `nearby_unsupported`
- Review role: `boundary`
- Sibling of: `<none>`
- Expected route / status / shape: `season_leaders` / `no_result` / `no_result`
- Actual route / status / shape: `season_leaders` / `no_result` / `no_result`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: No answer rows returned; reason=filter_not_supported
- Filters: _none_
- Sections: _none_
- Manual review status: `expected_unsupported`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### original_window_played_pair_source_empty

#### original_window_played_pair_source_empty

**Query**  
Lakers record against Celtics within their last 1 game with Jayson Tatum playing while Anthony Davis plays in 2023-24

**Answer shown**  
No answer returned.

**Rendered output**

##### Message — No result

No answer rows returned; reason=no_match.  

- Query: `Lakers record against Celtics within their last 1 game with Jayson Tatum playing while Anthony Davis plays in 2023-24`
- Family / concept / variant: `team_record_availability` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `team_record` / `no_result` / `no_result`
- Actual route / status / shape: `team_record` / `no_result` / `no_result`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: No answer rows returned; reason=no_match
- Filters: `Opponent=BOS (team)`, `With player=Jayson Tatum and Anthony Davis (player)`, `Last N games=1 (window)`, `Sample selection=Select the last 1 original matchup game before checking both played predicates (window)`
- Sections: _none_
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### original_window_played_pair_source_positive

#### original_window_played_pair_source_positive

**Query**  
Lakers record against Celtics within their last 1 game with Jayson Tatum playing while Austin Reaves plays in 2023-24

**Answer shown**  
The Los Angeles Lakers are 1-0 in 2023-24 Regular Season, a 100% win rate.

**Rendered output**

##### Card — Team Record

Subject: Los Angeles Lakers  
Mode: Team record  
Filter: Opponent: BOS; With player: Jayson Tatum and Austin Reaves; Last N games: 1; Sample selection: Select the last 1 original matchup game before checking both played predicates  
Record: 1-0  
Games: 1  
Win %: 100.0%  
PPG: 114.0  
+/-: 9.0  

##### Table — Team record

Subject: Los Angeles Lakers  
Mode: Team record  
Filter: Opponent: BOS; With player: Jayson Tatum and Austin Reaves; Last N games: 1; Sample selection: Select the last 1 original matchup game before checking both played predicates  
Table type: record_summary  
Column schema: team_record_summary_default  
Rows: 1  

| Team | W-L | Games | Win % | PPG | +/- | Opponent |
| --- | --- | --- | --- | --- | --- | --- |
| Los Angeles Lakers | 1-0 | 1 | 100.0% | 114.0 | 9.0 | Celtics |

##### Detail — Game Detail

Subject: Los Angeles Lakers  
Mode: Team game log  
Filter: Opponent: BOS; With player: Jayson Tatum and Austin Reaves; Last N games: 1; Sample selection: Select the last 1 original matchup game before checking both played predicates  
Table type: team_game_log  
Column schema: team_game_log_default  
Rows: 1  
Collapsed label: Show game detail  

| # | Date | Team |  | Opp | Score | W/L | PTS | Opp PTS | Margin | REB | AST | 3PM | FG | 3P | FT | TOV | STL | BLK | oreb | dreb |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Feb 1 | LAL |  | BOS | 114-105 | W | 114 | 105 | — | 52 | 30 | 19 | — | — | — | 7 | 11 | 2 | 15 | 37 |

- Query: `Lakers record against Celtics within their last 1 game with Jayson Tatum playing while Austin Reaves plays in 2023-24`
- Family / concept / variant: `team_record_availability` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `team_record` / `ok` / `team_record`
- Actual route / status / shape: `team_record` / `ok` / `team_record`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Los Angeles Lakers -- 1-0 over 1 games, 114 PPG, 52 RPG, 30 APG, Regular Season
- Filters: `Opponent=BOS (team)`, `With player=Jayson Tatum and Austin Reaves (player)`, `Last N games=1 (window)`, `Sample selection=Select the last 1 original matchup game before checking both played predicates (window)`
- Sections: `summary` 1 row(s), `by_season` 1 row(s), `game_log` 1 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### original_window_played_pair_source_qualifying

#### original_window_played_pair_source_qualifying

**Query**  
Lakers record against Celtics in their last 1 qualifying game with Jayson Tatum playing while Anthony Davis plays in 2023-24

**Answer shown**  
The Los Angeles Lakers are 0-1 in 2023-24 Regular Season, a 0% win rate.

**Rendered output**

##### Card — Team Record

Subject: Los Angeles Lakers  
Mode: Team record  
Filter: Opponent: BOS; With player: Jayson Tatum and Anthony Davis; Last N games: 1; Sample selection: Select the last 1 games matching the conditions  
Record: 0-1  
Games: 1  
Win %: 0.0%  
PPG: 115.0  
+/-: -11.0  

##### Table — Team record

Subject: Los Angeles Lakers  
Mode: Team record  
Filter: Opponent: BOS; With player: Jayson Tatum and Anthony Davis; Last N games: 1; Sample selection: Select the last 1 games matching the conditions  
Table type: record_summary  
Column schema: team_record_summary_default  
Rows: 1  

| Team | W-L | Games | Win % | PPG | +/- | Opponent |
| --- | --- | --- | --- | --- | --- | --- |
| Los Angeles Lakers | 0-1 | 1 | 0.0% | 115.0 | -11.0 | Celtics |

##### Detail — Game Detail

Subject: Los Angeles Lakers  
Mode: Team game log  
Filter: Opponent: BOS; With player: Jayson Tatum and Anthony Davis; Last N games: 1; Sample selection: Select the last 1 games matching the conditions  
Table type: team_game_log  
Column schema: team_game_log_default  
Rows: 1  
Collapsed label: Show game detail  

| # | Date | Team |  | Opp | Score | W/L | PTS | Opp PTS | Margin | REB | AST | 3PM | FG | 3P | FT | TOV | STL | BLK | oreb | dreb |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Dec 25 | LAL |  | BOS | 115-126 | L | 115 | 126 | — | 43 | 24 | 13 | — | — | — | 12 | 4 | 1 | 13 | 30 |

- Query: `Lakers record against Celtics in their last 1 qualifying game with Jayson Tatum playing while Anthony Davis plays in 2023-24`
- Family / concept / variant: `team_record_availability` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `team_record` / `ok` / `team_record`
- Actual route / status / shape: `team_record` / `ok` / `team_record`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Los Angeles Lakers -- 0-1 over 1 games, 115 PPG, 43 RPG, 24 APG, Regular Season
- Filters: `Opponent=BOS (team)`, `With player=Jayson Tatum and Anthony Davis (player)`, `Last N games=1 (window)`, `Sample selection=Select the last 1 games matching the conditions (window)`
- Sections: `summary` 1 row(s), `by_season` 1 row(s), `game_log` 1 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### latest_original_both_source_false

#### latest_original_both_source_false

**Query**  
Of the Lakers last game against Celtics in 2023-24, did BOTH Jayson Tatum and Anthony Davis play?

**Answer shown**  
No: Jayson Tatum and Anthony Davis did not both play in the Los Angeles Lakers' latest original game against the Boston Celtics (2024-02-01).

**Rendered output**

##### Table — Game Detail

Subject: Los Angeles Lakers  
Mode: Team game log  
Filter: Opponent: BOS; Last N games: 1; Sample selection: Select the latest original matchup game before checking both played predicates; Played check: Jayson Tatum and Anthony Davis both played  
Table type: team_game_log  
Column schema: team_game_log_default  
Rows: 1  

| # | Date | Team |  | Opp | W/L | PTS | Margin | REB | AST | 3PM | FG | 3P | FT | TOV | STL | BLK | oreb | dreb |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Feb 1 | LAL |  | BOS | W | 114 | — | 52 | 30 | 19 | — | — | — | 7 | 11 | 2 | 15 | 37 |

- Query: `Of the Lakers last game against Celtics in 2023-24, did BOTH Jayson Tatum and Anthony Davis play?`
- Family / concept / variant: `game_finders` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `game_finder` / `ok` / `game_log_team_table`
- Actual route / status / shape: `game_finder` / `ok` / `game_log_team_table`
- Machine expectation status: `pass`
- Backend answer text: No: Jayson Tatum and Anthony Davis did not both play in the Los Angeles Lakers' latest original game against the Boston Celtics (2024-02-01).
- Answer summary: Top row: Los Angeles Lakers -- 114 PTS, 2024-02-01 LAL vs BOS
- Filters: `Opponent=BOS (team)`, `Last N games=1 (window)`, `Sample selection=Select the latest original matchup game before checking both played predicates (window)`, `Played check=Jayson Tatum and Anthony Davis both played (player)`
- Sections: `finder` 1 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### latest_original_both_source_true

#### latest_original_both_source_true

**Query**  
Of the Lakers last game against Celtics in 2023-24, did BOTH Jayson Tatum and Austin Reaves play?

**Answer shown**  
Yes: Jayson Tatum and Austin Reaves both played in the Los Angeles Lakers' latest original game against the Boston Celtics (2024-02-01).

**Rendered output**

##### Table — Game Detail

Subject: Los Angeles Lakers  
Mode: Team game log  
Filter: Opponent: BOS; Last N games: 1; Sample selection: Select the latest original matchup game before checking both played predicates; Played check: Jayson Tatum and Austin Reaves both played  
Table type: team_game_log  
Column schema: team_game_log_default  
Rows: 1  

| # | Date | Team |  | Opp | W/L | PTS | Margin | REB | AST | 3PM | FG | 3P | FT | TOV | STL | BLK | oreb | dreb |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Feb 1 | LAL |  | BOS | W | 114 | — | 52 | 30 | 19 | — | — | — | 7 | 11 | 2 | 15 | 37 |

- Query: `Of the Lakers last game against Celtics in 2023-24, did BOTH Jayson Tatum and Austin Reaves play?`
- Family / concept / variant: `game_finders` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `game_finder` / `ok` / `game_log_team_table`
- Actual route / status / shape: `game_finder` / `ok` / `game_log_team_table`
- Machine expectation status: `pass`
- Backend answer text: Yes: Jayson Tatum and Austin Reaves both played in the Los Angeles Lakers' latest original game against the Boston Celtics (2024-02-01).
- Answer summary: Top row: Los Angeles Lakers -- 114 PTS, 2024-02-01 LAL vs BOS
- Filters: `Opponent=BOS (team)`, `Last N games=1 (window)`, `Sample selection=Select the latest original matchup game before checking both played predicates (window)`, `Played check=Jayson Tatum and Austin Reaves both played (player)`
- Sections: `finder` 1 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### qualified_scalar_played_source_yes

#### qualified_scalar_played_source_yes

**Query**  
Did Jayson Tatum play in the Celtics last game against Lakers in 2023-24?

**Answer shown**  
Yes: Jayson Tatum played in the Boston Celtics' last game against the Los Angeles Lakers (2024-02-01): 23 points, 7 rebounds and 3 assists.

**Rendered output**

##### Table — Game Detail

Subject: Boston Celtics  
Mode: Team game log  
Filter: Opponent: LAL; Last N games: 1; Sample selection: Select the latest original team game before checking the played predicate; Played check: Jayson Tatum played  
Table type: team_game_log  
Column schema: team_game_log_default  
Rows: 1  

| # | Date | Team |  | Opp | W/L | PTS | Margin | REB | AST | 3PM | FG | 3P | FT | TOV | STL | BLK | oreb | dreb |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Feb 1 | BOS |  | LAL | L | 105 | — | 54 | 30 | 16 | — | — | — | 15 | 4 | 12 | 14 | 40 |

- Query: `Did Jayson Tatum play in the Celtics last game against Lakers in 2023-24?`
- Family / concept / variant: `game_finders` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `game_finder` / `ok` / `game_log_team_table`
- Actual route / status / shape: `game_finder` / `ok` / `game_log_team_table`
- Machine expectation status: `pass`
- Backend answer text: Yes: Jayson Tatum played in the Boston Celtics' last game against the Los Angeles Lakers (2024-02-01): 23 points, 7 rebounds and 3 assists.
- Answer summary: Top row: Boston Celtics -- 105 PTS, 2024-02-01 BOS vs LAL
- Filters: `Opponent=LAL (team)`, `Last N games=1 (window)`, `Sample selection=Select the latest original team game before checking the played predicate (window)`, `Played check=Jayson Tatum played (player)`
- Sections: `finder` 1 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### qualified_scalar_played_source_dnp_no

#### qualified_scalar_played_source_dnp_no

**Query**  
Did Anthony Davis play in the Lakers last game against Celtics in 2023-24?

**Answer shown**  
No: Anthony Davis did not play in the Los Angeles Lakers' last game against the Boston Celtics (2024-02-01).

**Rendered output**

##### Table — Game Detail

Subject: Los Angeles Lakers  
Mode: Team game log  
Filter: Opponent: BOS; Last N games: 1; Sample selection: Select the latest original team game before checking the played predicate; Played check: Anthony Davis played  
Table type: team_game_log  
Column schema: team_game_log_default  
Rows: 1  

| # | Date | Team |  | Opp | W/L | PTS | Margin | REB | AST | 3PM | FG | 3P | FT | TOV | STL | BLK | oreb | dreb |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Feb 1 | LAL |  | BOS | W | 114 | — | 52 | 30 | 19 | — | — | — | 7 | 11 | 2 | 15 | 37 |

- Query: `Did Anthony Davis play in the Lakers last game against Celtics in 2023-24?`
- Family / concept / variant: `game_finders` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `game_finder` / `ok` / `game_log_team_table`
- Actual route / status / shape: `game_finder` / `ok` / `game_log_team_table`
- Machine expectation status: `pass`
- Backend answer text: No: Anthony Davis did not play in the Los Angeles Lakers' last game against the Boston Celtics (2024-02-01).
- Answer summary: Top row: Los Angeles Lakers -- 114 PTS, 2024-02-01 LAL vs BOS
- Filters: `Opponent=BOS (team)`, `Last N games=1 (window)`, `Sample selection=Select the latest original team game before checking the played predicate (window)`, `Played check=Anthony Davis played (player)`
- Sections: `finder` 1 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### qualified_scalar_played_source_unknown

#### qualified_scalar_played_source_unknown

**Query**  
Did AD play last game in 2025-26?

**Answer shown**  
No answer returned.

**Rendered output**

##### Message — No result

No answer rows returned; reason=filter_not_supported.  

- Query: `Did AD play last game in 2025-26?`
- Family / concept / variant: `game_finders` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `game_finder` / `no_result` / `no_result`
- Actual route / status / shape: `game_finder` / `no_result` / `no_result`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: No answer rows returned; reason=filter_not_supported
- Filters: `Last N games=1 (window)`, `Sample selection=Check conditions within the last 1 games (window)`
- Sections: _none_
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### qualified_original_minutes_source_dnp_no

#### qualified_original_minutes_source_dnp_no

**Query**  
Did Anthony Davis play at least 30 minutes in the Lakers last game against Celtics in 2023-24?

**Answer shown**  
No: Anthony Davis did not play in the Los Angeles Lakers' latest original game against the Boston Celtics (2024-02-01); the check was played &gt;= 30 minutes.

**Rendered output**

##### Table — Game Detail

Subject: Los Angeles Lakers  
Mode: Team game log  
Filter: Opponent: BOS; Last N games: 1; Sample selection: Select the latest original team matchup before checking player minutes; Minutes check: Anthony Davis played &gt;= 30 minutes  
Table type: team_game_log  
Column schema: team_game_log_default  
Rows: 1  

| # | Date | Team |  | Opp | W/L | PTS | Margin | REB | AST | 3PM | FG | 3P | FT | TOV | STL | BLK | oreb | dreb |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Feb 1 | LAL |  | BOS | W | 114 | — | 52 | 30 | 19 | — | — | — | 7 | 11 | 2 | 15 | 37 |

- Query: `Did Anthony Davis play at least 30 minutes in the Lakers last game against Celtics in 2023-24?`
- Family / concept / variant: `game_finders` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `game_finder` / `ok` / `game_log_team_table`
- Actual route / status / shape: `game_finder` / `ok` / `game_log_team_table`
- Machine expectation status: `pass`
- Backend answer text: No: Anthony Davis did not play in the Los Angeles Lakers' latest original game against the Boston Celtics (2024-02-01); the check was played >= 30 minutes.
- Answer summary: Top row: Los Angeles Lakers -- 114 PTS, 2024-02-01 LAL vs BOS
- Filters: `Opponent=BOS (team)`, `Last N games=1 (window)`, `Sample selection=Select the latest original team matchup before checking player minutes (window)`, `Minutes check=Anthony Davis played >= 30 minutes (player)`
- Sections: `finder` 1 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### qualified_original_minutes_source_exact_no

#### qualified_original_minutes_source_exact_no

**Query**  
Did Jayson Tatum play at least 37 minutes in the Celtics last game against Lakers in 2023-24?

**Answer shown**  
No: Jayson Tatum played 36:37 in the Boston Celtics' latest original game against the Los Angeles Lakers (2024-02-01); the check was played &gt;= 37 minutes.

**Rendered output**

##### Table — Game Detail

Subject: Boston Celtics  
Mode: Team game log  
Filter: Opponent: LAL; Last N games: 1; Sample selection: Select the latest original team matchup before checking player minutes; Minutes check: Jayson Tatum played &gt;= 37 minutes  
Table type: team_game_log  
Column schema: team_game_log_default  
Rows: 1  

| # | Date | Team |  | Opp | W/L | PTS | Margin | REB | AST | 3PM | FG | 3P | FT | TOV | STL | BLK | oreb | dreb |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Feb 1 | BOS |  | LAL | L | 105 | — | 54 | 30 | 16 | — | — | — | 15 | 4 | 12 | 14 | 40 |

- Query: `Did Jayson Tatum play at least 37 minutes in the Celtics last game against Lakers in 2023-24?`
- Family / concept / variant: `game_finders` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `game_finder` / `ok` / `game_log_team_table`
- Actual route / status / shape: `game_finder` / `ok` / `game_log_team_table`
- Machine expectation status: `pass`
- Backend answer text: No: Jayson Tatum played 36:37 in the Boston Celtics' latest original game against the Los Angeles Lakers (2024-02-01); the check was played >= 37 minutes.
- Answer summary: Top row: Boston Celtics -- 105 PTS, 2024-02-01 BOS vs LAL
- Filters: `Opponent=LAL (team)`, `Last N games=1 (window)`, `Sample selection=Select the latest original team matchup before checking player minutes (window)`, `Minutes check=Jayson Tatum played >= 37 minutes (player)`
- Sections: `finder` 1 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### qualified_original_minutes_source_exact_yes

#### qualified_original_minutes_source_exact_yes

**Query**  
Did Jaylen Brown play over 27 minutes in the Celtics last game against Lakers in 2023-24?

**Answer shown**  
Yes: Jaylen Brown played 27:24 in the Boston Celtics' latest original game against the Los Angeles Lakers (2024-02-01); the check was played &gt; 27 minutes.

**Rendered output**

##### Table — Game Detail

Subject: Boston Celtics  
Mode: Team game log  
Filter: Opponent: LAL; Last N games: 1; Sample selection: Select the latest original team matchup before checking player minutes; Minutes check: Jaylen Brown played &gt; 27 minutes  
Table type: team_game_log  
Column schema: team_game_log_default  
Rows: 1  

| # | Date | Team |  | Opp | W/L | PTS | Margin | REB | AST | 3PM | FG | 3P | FT | TOV | STL | BLK | oreb | dreb |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Feb 1 | BOS |  | LAL | L | 105 | — | 54 | 30 | 16 | — | — | — | 15 | 4 | 12 | 14 | 40 |

- Query: `Did Jaylen Brown play over 27 minutes in the Celtics last game against Lakers in 2023-24?`
- Family / concept / variant: `game_finders` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `game_finder` / `ok` / `game_log_team_table`
- Actual route / status / shape: `game_finder` / `ok` / `game_log_team_table`
- Machine expectation status: `pass`
- Backend answer text: Yes: Jaylen Brown played 27:24 in the Boston Celtics' latest original game against the Los Angeles Lakers (2024-02-01); the check was played > 27 minutes.
- Answer summary: Top row: Boston Celtics -- 105 PTS, 2024-02-01 BOS vs LAL
- Filters: `Opponent=LAL (team)`, `Last N games=1 (window)`, `Sample selection=Select the latest original team matchup before checking player minutes (window)`, `Minutes check=Jaylen Brown played > 27 minutes (player)`
- Sections: `finder` 1 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### qualified_original_minutes_source_unknown

#### qualified_original_minutes_source_unknown

**Query**  
Did Anthony Davis play at least 30 minutes in the Lakers last game against Celtics in 2025-26?

**Answer shown**  
No answer returned.

**Rendered output**

##### Message — No result

No answer rows returned; reason=filter_not_supported.  

- Query: `Did Anthony Davis play at least 30 minutes in the Lakers last game against Celtics in 2025-26?`
- Family / concept / variant: `game_finders` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `game_finder` / `no_result` / `no_result`
- Actual route / status / shape: `game_finder` / `no_result` / `no_result`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: No answer rows returned; reason=filter_not_supported
- Filters: `Opponent=BOS (team)`, `Last N games=1 (window)`, `Sample selection=Check conditions within the last 1 games (window)`
- Sections: _none_
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### qualified_original_stat_pair_source_yes

#### qualified_original_stat_pair_source_yes

**Query**  
Did Payton Pritchard play at least 21 minutes and have at least 1 assist in the Celtics last game against Lakers in 2023-24?

**Answer shown**  
Yes: Payton Pritchard played 21:18 with 1 AST in the Boston Celtics' latest original game against the Los Angeles Lakers (2024-02-01); the check was played &gt;= 21 minutes and &gt;= 1 AST.

**Rendered output**

##### Table — Game Detail

Subject: Boston Celtics  
Mode: Team game log  
Filter: Opponent: LAL; Last N games: 1; Sample selection: Select the latest original team matchup before checking player minutes and count; Minutes check: Payton Pritchard played &gt;= 21 minutes; Count check: Payton Pritchard &gt;= 1 AST  
Table type: team_game_log  
Column schema: team_game_log_default  
Rows: 1  

| # | Date | Team |  | Opp | W/L | PTS | Margin | REB | AST | 3PM | FG | 3P | FT | TOV | STL | BLK | oreb | dreb |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Feb 1 | BOS |  | LAL | L | 105 | — | 54 | 30 | 16 | — | — | — | 15 | 4 | 12 | 14 | 40 |

- Query: `Did Payton Pritchard play at least 21 minutes and have at least 1 assist in the Celtics last game against Lakers in 2023-24?`
- Family / concept / variant: `game_finders` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `game_finder` / `ok` / `game_log_team_table`
- Actual route / status / shape: `game_finder` / `ok` / `game_log_team_table`
- Machine expectation status: `pass`
- Backend answer text: Yes: Payton Pritchard played 21:18 with 1 AST in the Boston Celtics' latest original game against the Los Angeles Lakers (2024-02-01); the check was played >= 21 minutes and >= 1 AST.
- Answer summary: Top row: Boston Celtics -- 105 PTS, 2024-02-01 BOS vs LAL
- Filters: `Opponent=LAL (team)`, `Last N games=1 (window)`, `Sample selection=Select the latest original team matchup before checking player minutes and count (window)`, `Minutes check=Payton Pritchard played >= 21 minutes (player)`, `Count check=Payton Pritchard >= 1 AST (player)`
- Sections: `finder` 1 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### qualified_original_stat_pair_source_no

#### qualified_original_stat_pair_source_no

**Query**  
Did Payton Pritchard play at least 21 minutes and have fewer than 1 assist in the Celtics last game against Lakers in 2023-24?

**Answer shown**  
No: Payton Pritchard played 21:18 with 1 AST in the Boston Celtics' latest original game against the Los Angeles Lakers (2024-02-01); the check was played &gt;= 21 minutes and &lt; 1 AST.

**Rendered output**

##### Table — Game Detail

Subject: Boston Celtics  
Mode: Team game log  
Filter: Opponent: LAL; Last N games: 1; Sample selection: Select the latest original team matchup before checking player minutes and count; Minutes check: Payton Pritchard played &gt;= 21 minutes; Count check: Payton Pritchard &lt; 1 AST  
Table type: team_game_log  
Column schema: team_game_log_default  
Rows: 1  

| # | Date | Team |  | Opp | W/L | PTS | Margin | REB | AST | 3PM | FG | 3P | FT | TOV | STL | BLK | oreb | dreb |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Feb 1 | BOS |  | LAL | L | 105 | — | 54 | 30 | 16 | — | — | — | 15 | 4 | 12 | 14 | 40 |

- Query: `Did Payton Pritchard play at least 21 minutes and have fewer than 1 assist in the Celtics last game against Lakers in 2023-24?`
- Family / concept / variant: `game_finders` / `<none>` / `synonym`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `game_finder` / `ok` / `game_log_team_table`
- Actual route / status / shape: `game_finder` / `ok` / `game_log_team_table`
- Machine expectation status: `pass`
- Backend answer text: No: Payton Pritchard played 21:18 with 1 AST in the Boston Celtics' latest original game against the Los Angeles Lakers (2024-02-01); the check was played >= 21 minutes and < 1 AST.
- Answer summary: Top row: Boston Celtics -- 105 PTS, 2024-02-01 BOS vs LAL
- Filters: `Opponent=LAL (team)`, `Last N games=1 (window)`, `Sample selection=Select the latest original team matchup before checking player minutes and count (window)`, `Minutes check=Payton Pritchard played >= 21 minutes (player)`, `Count check=Payton Pritchard < 1 AST (player)`
- Sections: `finder` 1 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### qualified_original_stat_pair_source_zero

#### qualified_original_stat_pair_source_zero

**Query**  
Did Payton Pritchard play at least 21 minutes and have at most 0 rebounds in the Celtics last game against Lakers in 2023-24?

**Answer shown**  
Yes: Payton Pritchard played 21:18 with 0 REB in the Boston Celtics' latest original game against the Los Angeles Lakers (2024-02-01); the check was played &gt;= 21 minutes and &lt;= 0 REB.

**Rendered output**

##### Table — Game Detail

Subject: Boston Celtics  
Mode: Team game log  
Filter: Opponent: LAL; Last N games: 1; Sample selection: Select the latest original team matchup before checking player minutes and count; Minutes check: Payton Pritchard played &gt;= 21 minutes; Count check: Payton Pritchard &lt;= 0 REB  
Table type: team_game_log  
Column schema: team_game_log_default  
Rows: 1  

| # | Date | Team |  | Opp | W/L | PTS | Margin | REB | AST | 3PM | FG | 3P | FT | TOV | STL | BLK | oreb | dreb |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Feb 1 | BOS |  | LAL | L | 105 | — | 54 | 30 | 16 | — | — | — | 15 | 4 | 12 | 14 | 40 |

- Query: `Did Payton Pritchard play at least 21 minutes and have at most 0 rebounds in the Celtics last game against Lakers in 2023-24?`
- Family / concept / variant: `game_finders` / `<none>` / `synonym`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `game_finder` / `ok` / `game_log_team_table`
- Actual route / status / shape: `game_finder` / `ok` / `game_log_team_table`
- Machine expectation status: `pass`
- Backend answer text: Yes: Payton Pritchard played 21:18 with 0 REB in the Boston Celtics' latest original game against the Los Angeles Lakers (2024-02-01); the check was played >= 21 minutes and <= 0 REB.
- Answer summary: Top row: Boston Celtics -- 105 PTS, 2024-02-01 BOS vs LAL
- Filters: `Opponent=LAL (team)`, `Last N games=1 (window)`, `Sample selection=Select the latest original team matchup before checking player minutes and count (window)`, `Minutes check=Payton Pritchard played >= 21 minutes (player)`, `Count check=Payton Pritchard <= 0 REB (player)`
- Sections: `finder` 1 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### qualified_original_stat_pair_source_dnp_no

#### qualified_original_stat_pair_source_dnp_no

**Query**  
Did Anthony Davis play at least 30 minutes and have at most 0 rebounds in the Lakers last game against Celtics in 2023-24?

**Answer shown**  
No: Anthony Davis did not play in the Los Angeles Lakers' latest original game against the Boston Celtics (2024-02-01); the check was played &gt;= 30 minutes and &lt;= 0 REB.

**Rendered output**

##### Table — Game Detail

Subject: Los Angeles Lakers  
Mode: Team game log  
Filter: Opponent: BOS; Last N games: 1; Sample selection: Select the latest original team matchup before checking player minutes and count; Minutes check: Anthony Davis played &gt;= 30 minutes; Count check: Anthony Davis &lt;= 0 REB  
Table type: team_game_log  
Column schema: team_game_log_default  
Rows: 1  

| # | Date | Team |  | Opp | W/L | PTS | Margin | REB | AST | 3PM | FG | 3P | FT | TOV | STL | BLK | oreb | dreb |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Feb 1 | LAL |  | BOS | W | 114 | — | 52 | 30 | 19 | — | — | — | 7 | 11 | 2 | 15 | 37 |

- Query: `Did Anthony Davis play at least 30 minutes and have at most 0 rebounds in the Lakers last game against Celtics in 2023-24?`
- Family / concept / variant: `game_finders` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `game_finder` / `ok` / `game_log_team_table`
- Actual route / status / shape: `game_finder` / `ok` / `game_log_team_table`
- Machine expectation status: `pass`
- Backend answer text: No: Anthony Davis did not play in the Los Angeles Lakers' latest original game against the Boston Celtics (2024-02-01); the check was played >= 30 minutes and <= 0 REB.
- Answer summary: Top row: Los Angeles Lakers -- 114 PTS, 2024-02-01 LAL vs BOS
- Filters: `Opponent=BOS (team)`, `Last N games=1 (window)`, `Sample selection=Select the latest original team matchup before checking player minutes and count (window)`, `Minutes check=Anthony Davis played >= 30 minutes (player)`, `Count check=Anthony Davis <= 0 REB (player)`
- Sections: `finder` 1 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### qualified_original_stat_pair_source_unknown

#### qualified_original_stat_pair_source_unknown

**Query**  
Did Anthony Davis play at least 30 minutes and have at least 1 assist in the Lakers last game against Celtics in 2025-26?

**Answer shown**  
No answer returned.

**Rendered output**

##### Message — No result

No answer rows returned; reason=filter_not_supported.  

- Query: `Did Anthony Davis play at least 30 minutes and have at least 1 assist in the Lakers last game against Celtics in 2025-26?`
- Family / concept / variant: `game_finders` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `game_finder` / `no_result` / `no_result`
- Actual route / status / shape: `game_finder` / `no_result` / `no_result`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: No answer rows returned; reason=filter_not_supported
- Filters: `Opponent=BOS (team)`, `Last N games=1 (window)`, `Sample selection=Check conditions within the last 1 games (window)`
- Sections: _none_
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### player_comparison_team_scope_source_primary

#### player_comparison_team_scope_source_primary

**Query**  
Compare Luka Doncic and Anthony Davis for the Lakers against the Warriors in 2024-25

**Answer shown**  
Luka Dončić -- 0-1 over 1 games, 19.0 PPG, 8.0 RPG, 7.0 APG

**Rendered output**

##### Table — Comparison

Mode: player comparison  
Table type: comparison_table  
Column schema: comparison_default  
Rows: 20  

| Metric | Luka Dončić | Anthony Davis |
| --- | --- | --- |
| games | 1 | 2 |
| wins | 0 | 2 |
| losses | 1 | 0 |

- Query: `Compare Luka Doncic and Anthony Davis for the Lakers against the Warriors in 2024-25`
- Family / concept / variant: `comparisons` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_compare` / `ok` / `comparison`
- Actual route / status / shape: `player_compare` / `ok` / `comparison`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Luka Dončić -- 0-1 over 1 games, 19 PPG, 8 RPG, 7 APG, Regular Season
- Filters: `Playing for=LAL (team)`, `Opponent=GSW (team)`
- Sections: `summary` 2 row(s), `comparison` 20 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### player_comparison_team_scope_source_question

#### player_comparison_team_scope_source_question

**Query**  
How did Luka Doncic and Anthony Davis compare for the Lakers against the Warriors in 2024-25?

**Answer shown**  
Luka Dončić -- 0-1 over 1 games, 19.0 PPG, 8.0 RPG, 7.0 APG

**Rendered output**

##### Table — Comparison

Mode: player comparison  
Table type: comparison_table  
Column schema: comparison_default  
Rows: 20  

| Metric | Luka Dončić | Anthony Davis |
| --- | --- | --- |
| games | 1 | 2 |
| wins | 0 | 2 |
| losses | 1 | 0 |

- Query: `How did Luka Doncic and Anthony Davis compare for the Lakers against the Warriors in 2024-25?`
- Family / concept / variant: `comparisons` / `<none>` / `sentence`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_compare` / `ok` / `comparison`
- Actual route / status / shape: `player_compare` / `ok` / `comparison`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Luka Dončić -- 0-1 over 1 games, 19 PPG, 8 RPG, 7 APG, Regular Season
- Filters: `Playing for=LAL (team)`, `Opponent=GSW (team)`
- Sections: `summary` 2 row(s), `comparison` 20 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### player_comparison_team_scope_source_count_partial_empty

#### player_comparison_team_scope_source_count_partial_empty

**Query**  
Compare Luka Doncic and Anthony Davis for the Lakers against the Warriors in 2024-25 with over 35.99999 points

**Answer shown**  
Luka Dončić -- 0-0 over 0 games, — PPG, — RPG, — APG

**Rendered output**

##### Table — Comparison

Mode: player comparison  
Table type: comparison_table  
Column schema: comparison_default  
Rows: 20  

| Metric | Luka Dončić | Anthony Davis |
| --- | --- | --- |
| games | 0 | 1 |
| wins | 0 | 1 |
| losses | 0 | 0 |

- Query: `Compare Luka Doncic and Anthony Davis for the Lakers against the Warriors in 2024-25 with over 35.99999 points`
- Family / concept / variant: `comparisons` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_compare` / `ok` / `comparison`
- Actual route / status / shape: `player_compare` / `ok` / `comparison`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Luka Dončić -- 0-0 over 0 games, None PPG, None RPG, None APG, Regular Season
- Filters: `Playing for=LAL (team)`, `Opponent=GSW (team)`, `Count filter=> 35.99999 PTS (integer execution: >= 36 PTS) (threshold)`
- Sections: `summary` 2 row(s), `comparison` 20 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### player_comparison_team_scope_source_count_empty

#### player_comparison_team_scope_source_count_empty

**Query**  
Compare Luka Doncic and Anthony Davis for the Lakers against the Warriors in 2024-25 with between 0.1 and 0.9 points

**Answer shown**  
No answer returned.

**Rendered output**

##### Message — No result

No answer rows returned; reason=no_match.  

- Query: `Compare Luka Doncic and Anthony Davis for the Lakers against the Warriors in 2024-25 with between 0.1 and 0.9 points`
- Family / concept / variant: `comparisons` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_compare` / `no_result` / `no_result`
- Actual route / status / shape: `player_compare` / `no_result` / `no_result`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: No answer rows returned; reason=no_match
- Filters: `Playing for=LAL (team)`, `Opponent=GSW (team)`, `Count filter=>= 0.1 and <= 0.9 PTS (integer execution: >= 1 and <= 0 PTS) (threshold)`
- Sections: _none_
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### player_comparison_team_scope_unresolved_operand

#### player_comparison_team_scope_unresolved_operand

**Query**  
Compare Luka Doncic and Blorg for the Lakers against Warriors in 2024-25

**Answer shown**  
No answer returned.

**Rendered output**

##### Message — No result

No answer rows returned; reason=unsupported.  

- Query: `Compare Luka Doncic and Blorg for the Lakers against Warriors in 2024-25`
- Family / concept / variant: `comparisons` / `<none>` / `typo_partial`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_compare` / `no_result` / `no_result`
- Actual route / status / shape: `player_compare` / `no_result` / `no_result`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: No answer rows returned; reason=unsupported
- Filters: _none_
- Sections: _none_
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### medical_subject_team_unavailable

#### medical_subject_team_unavailable

**Query**  
Boston record against the Lakers in 2025-26 when Derrick White is medically cleared.

**Answer shown**  
No answer returned.

**Rendered output**

##### Message — No result

No answer rows returned; reason=filter_not_supported.  

- Query: `Boston record against the Lakers in 2025-26 when Derrick White is medically cleared.`
- Family / concept / variant: `team_records` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `team_record` / `no_result` / `no_result`
- Actual route / status / shape: `team_record` / `no_result` / `no_result`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: No answer rows returned; reason=filter_not_supported
- Filters: _none_
- Sections: _none_
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### medical_subject_comparison_unavailable

#### medical_subject_comparison_unavailable

**Query**  
Show Embiid and Jokic side by side against Knicks in 2023-24 when Embiid is medically cleared.

**Answer shown**  
No answer returned.

**Rendered output**

##### Message — No result

No answer rows returned; reason=filter_not_supported.  

- Query: `Show Embiid and Jokic side by side against Knicks in 2023-24 when Embiid is medically cleared.`
- Family / concept / variant: `comparisons` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_compare` / `no_result` / `no_result`
- Actual route / status / shape: `player_compare` / `no_result` / `no_result`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: No answer rows returned; reason=filter_not_supported
- Filters: _none_
- Sections: _none_
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### medical_subject_team_played_control

#### medical_subject_team_played_control

**Query**  
Boston record against Lakers in 2025-26 when Derrick White plays.

**Answer shown**  
The Boston Celtics are 2-0 in 2025-26 Regular Season, a 100% win rate.

**Rendered output**

##### Card — Team Record

Subject: Boston Celtics  
Mode: Team record  
Filter: Opponent: LAL; With player: Derrick White  
Record: 2-0  
Games: 2  
Win %: 100.0%  
PPG: 118.5  
+/-: 21.5  

##### Table — Team record

Subject: Boston Celtics  
Mode: Team record  
Filter: Opponent: LAL; With player: Derrick White  
Table type: record_summary  
Column schema: team_record_summary_default  
Rows: 1  

| Team | W-L | Games | Win % | PPG | +/- | Opponent |
| --- | --- | --- | --- | --- | --- | --- |
| Boston Celtics | 2-0 | 2 | 100.0% | 118.5 | 21.5 | Lakers |

##### Detail — Game Detail

Subject: Boston Celtics  
Mode: Team game log  
Filter: Opponent: LAL; With player: Derrick White  
Table type: team_game_log  
Column schema: team_game_log_default  
Rows: 2  
Collapsed label: Show game detail  

| # | Date | Team |  | Opp | Score | W/L | PTS | Opp PTS | Margin | REB | AST | 3PM | FG | 3P | FT | TOV | STL | BLK | oreb | dreb |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Dec 5 | BOS |  | LAL | 126-105 | W | 126 | 105 | — | 38 | 31 | 24 | — | — | — | 14 | 9 | 5 | 8 | 30 |
| 2 | Feb 22 | BOS |  | LAL | 111-89 | W | 111 | 89 | — | 50 | 29 | 14 | — | — | — | 14 | 6 | 5 | 9 | 41 |

- Query: `Boston record against Lakers in 2025-26 when Derrick White plays.`
- Family / concept / variant: `team_records` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `team_record` / `ok` / `team_record`
- Actual route / status / shape: `team_record` / `ok` / `team_record`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Boston Celtics -- 2-0 over 2 games, 118.5 PPG, 44 RPG, 30 APG, Regular Season
- Filters: `Opponent=LAL (team)`, `With player=Derrick White (player)`
- Sections: `summary` 1 row(s), `by_season` 1 row(s), `game_log` 2 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k09_t1

#### k09_t1

**Query**  
Heat longest winning streak in 2012-13

**Answer shown**  
Top row: Miami Heat

**Rendered output**

##### Table — Streaks

Subject: Miami Heat  
Mode: streak table  
Table type: streak_table  
Column schema: streak_default  
Rows: 1  

| Rank | Team Name | Games | Wins | Losses | Pts Avg | Reb Avg | Ast Avg | Condition | Streak Length |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Miami Heat | 27 | 27 | 0 | 105.3 | 37.7 | 23.8 | wins | 27 |

- Query: `Heat longest winning streak in 2012-13`
- Family / concept / variant: `streaks` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `team_streak_finder` / `ok` / `<none>`
- Actual route / status / shape: `team_streak_finder` / `ok` / `streak_table`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: streak: Miami Heat -- 27 WINS, Miami Heat
- Filters: _none_
- Sections: `streak` 1 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k09_p1

#### k09_p1

**Query**  
Curry longest streak of 20 point games in 2025-26

**Answer shown**  
Top row: Stephen Curry

**Rendered output**

##### Table — Streaks

Subject: Stephen Curry  
Mode: streak table  
Table type: streak_table  
Column schema: streak_default  
Rows: 1  

| Rank | Player Name | Games | Wins | Losses | Pts Avg | Reb Avg | Ast Avg | Condition | Streak Length |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Stephen Curry | 11 | 8 | 3 | 28.7 | 3.5 | 5.6 | pts&gt;=20 | 11 |

- Query: `Curry longest streak of 20 point games in 2025-26`
- Family / concept / variant: `streaks` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_streak_finder` / `ok` / `<none>`
- Actual route / status / shape: `player_streak_finder` / `ok` / `streak_table`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: streak: Stephen Curry -- 8 WINS
- Filters: `pts min=20.0 (threshold)`
- Sections: `streak` 1 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k09_r1

#### k09_r1

**Query**  
how many times did the Heat win 5 straight in 2012-13

**Answer shown**  
The Heat have had 4 winning streaks of 5+ games in the 2012-13 regular season.

**Rendered output**

##### Table — Streaks

Subject: Miami Heat  
Mode: streak table  
Table type: streak_table  
Column schema: streak_default  
Rows: 4  

| Rank | Team Name | Games | Wins | Losses | Pts Avg | Reb Avg | Ast Avg | Condition | Streak Length |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Miami Heat | 27 | 27 | 0 | 105.3 | 37.7 | 23.8 | wins | 27 |
| 2 | Miami Heat | 8 | 8 | 0 | 100.9 | 43.1 | 24.9 | wins | 8 |
| 3 | Miami Heat | 6 | 6 | 0 | 104.7 | 38.5 | 23.2 | wins | 6 |

- Query: `how many times did the Heat win 5 straight in 2012-13`
- Family / concept / variant: `streaks` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `team_streak_finder` / `ok` / `<none>`
- Actual route / status / shape: `team_streak_finder` / `ok` / `streak_table`
- Machine expectation status: `pass`
- Backend answer text: The Heat have had 4 winning streaks of 5+ games in the 2012-13 regular season.
- Answer summary: Count: 4
- Filters: _none_
- Sections: `count` 1 row(s), `streak` 4 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k09_r2

#### k09_r2

**Query**  
How many times did Curry score 20 or more points in 3 straight appearances in 2025-26?

**Answer shown**  
Stephen Curry has had 5 streaks of 3+ straight games with 20+ points in the 2025-26 regular season.

**Rendered output**

##### Table — Streaks

Subject: Stephen Curry  
Mode: streak table  
Table type: streak_table  
Column schema: streak_default  
Rows: 5  

| Rank | Player Name | Games | Wins | Losses | Pts Avg | Reb Avg | Ast Avg | Condition | Streak Length |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Stephen Curry | 11 | 8 | 3 | 28.7 | 3.5 | 5.6 | pts&gt;=20 | 11 |
| 2 | Stephen Curry | 5 | 2 | 3 | 28.6 | 2.0 | 3.2 | pts&gt;=20 | 5 |
| 3 | Stephen Curry | 3 | 1 | 2 | 34.3 | 3.0 | 5.0 | pts&gt;=20 | 3 |

- Query: `How many times did Curry score 20 or more points in 3 straight appearances in 2025-26?`
- Family / concept / variant: `streaks` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_streak_finder` / `ok` / `<none>`
- Actual route / status / shape: `player_streak_finder` / `ok` / `streak_table`
- Machine expectation status: `pass`
- Backend answer text: Stephen Curry has had 5 streaks of 3+ straight games with 20+ points in the 2025-26 regular season.
- Answer summary: Count: 5
- Filters: `pts min=20.0 (threshold)`
- Sections: `count` 1 row(s), `streak` 5 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k09_w1

#### k09_w1

**Query**  
Celtics best 10 game stretch in 2023-24

**Answer shown**  
The Boston Celtics went 10-0 from 2024-02-07 to 2024-03-03 (+20.3 per game), their best 10-game stretch of 2023-24.

**Rendered output**

##### Table — Leaderboard

Subject: Teams  
Mode: Leaderboard  
Table type: leaderboard  
Column schema: leaderboard_default  
Rows: 7  

| # | Team | Stretch Value | Season | TM | Wins | Losses |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | Boston Celtics | 10 | 2023-24 | BOS | 10 | 0 |
| 2 | Boston Celtics | 9 | 2023-24 | BOS | 9 | 1 |
| 3 | Boston Celtics | 9 | 2023-24 | BOS | 9 | 1 |

- Query: `Celtics best 10 game stretch in 2023-24`
- Family / concept / variant: `rolling_stretches` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `team_stretch_leaderboard` / `ok` / `<none>`
- Actual route / status / shape: `team_stretch_leaderboard` / `ok` / `leaderboard_table`
- Machine expectation status: `pass`
- Backend answer text: The Boston Celtics went 10-0 from 2024-02-07 to 2024-03-03 (+20.3 per game), their best 10-game stretch of 2023-24.
- Answer summary: Top row: Boston Celtics -- 10 WINS, BOS
- Filters: _none_
- Sections: `leaderboard` 7 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k09_w2

#### k09_w2

**Query**  
Stephen Curry best 5 game 3 point shooting stretch in 2015-16

**Answer shown**  
Stephen Curry's best 5-game stretch of 2015-16 was 59.2% from three from 2015-11-28 to 2015-12-06.

**Rendered output**

##### Table — Rolling Stretch

Subject: Stephen Curry  
Mode: rolling stretch  
Table type: leaderboard  
Column schema: leaderboard_default  
Rows: 10  

| Rank | Player Name | Team Abbr | Window Size | Stretch Metric | Window Start Date | Window End Date | Window Start Season | Games In Window | Window End Season |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Stephen Curry | GSW | 5 | fg3_pct | Nov 28 | Dec 6 | 2015-16 | 5 | 2015-16 |
| 2 | Stephen Curry | GSW | 5 | fg3_pct | Feb 20 | Feb 27 | 2015-16 | 5 | 2015-16 |
| 3 | Stephen Curry | GSW | 5 | fg3_pct | Mar 27 | Apr 3 | 2015-16 | 5 | 2015-16 |

- Query: `Stephen Curry best 5 game 3 point shooting stretch in 2015-16`
- Family / concept / variant: `rolling_stretches` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_stretch_leaderboard` / `ok` / `<none>`
- Actual route / status / shape: `player_stretch_leaderboard` / `ok` / `rolling_stretch`
- Machine expectation status: `pass`
- Backend answer text: Stephen Curry's best 5-game stretch of 2015-16 was 59.2% from three from 2015-11-28 to 2015-12-06.
- Answer summary: Top row: Stephen Curry -- GSW
- Filters: _none_
- Sections: `leaderboard` 10 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k09_c1

#### k09_c1

**Query**  
Stephen Curry longest streak of 20 point games in 2025-26 from 2026-01-22 to 2026-04-05

**Answer shown**  
Top row: Stephen Curry

**Rendered output**

##### Table — Streaks

Subject: Stephen Curry  
Mode: streak table  
Table type: streak_table  
Column schema: streak_default  
Rows: 1  

| Rank | Player Name | Games | Wins | Losses | Pts Avg | Reb Avg | Ast Avg | Condition | Streak Length |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Stephen Curry | 5 | 2 | 3 | 28.6 | 2.0 | 3.2 | pts&gt;=20 | 5 |

- Query: `Stephen Curry longest streak of 20 point games in 2025-26 from 2026-01-22 to 2026-04-05`
- Family / concept / variant: `streaks` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_streak_finder` / `ok` / `<none>`
- Actual route / status / shape: `player_streak_finder` / `ok` / `streak_table`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: streak: Stephen Curry -- 2 WINS
- Filters: `pts min=20.0 (threshold)`, `Date range=2026-01-22 – 2026-04-05 (date)`
- Sections: `streak` 1 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k09_c2

#### k09_c2

**Query**  
Curry most consecutive games with a three from 2015-16 to 2016-17

**Answer shown**  
Top row: Stephen Curry

**Rendered output**

##### Table — Streaks

Subject: Stephen Curry  
Mode: streak table  
Table type: streak_table  
Column schema: streak_default  
Rows: 1  

| Rank | Player Name | Games | Wins | Losses | Pts Avg | Reb Avg | Ast Avg | Condition | Streak Length |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Stephen Curry | 84 | 75 | 9 | 29.8 | 5.2 | 6.6 | made_three | 84 |

- Query: `Curry most consecutive games with a three from 2015-16 to 2016-17`
- Family / concept / variant: `streaks` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_streak_finder` / `ok` / `<none>`
- Actual route / status / shape: `player_streak_finder` / `ok` / `streak_table`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: streak: Stephen Curry -- 75 WINS
- Filters: `Season range=2015-16 – 2016-17 (season)`
- Sections: `streak` 1 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k09_r2_synonym_control

#### k09_r2_synonym_control

**Query**  
How many times did Curry score 20 or more points in 3 straight games in 2025-26?

**Answer shown**  
Stephen Curry has had 5 streaks of 3+ straight games with 20+ points in the 2025-26 regular season.

**Rendered output**

##### Table — Streaks

Subject: Stephen Curry  
Mode: streak table  
Table type: streak_table  
Column schema: streak_default  
Rows: 5  

| Rank | Player Name | Games | Wins | Losses | Pts Avg | Reb Avg | Ast Avg | Condition | Streak Length |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Stephen Curry | 11 | 8 | 3 | 28.7 | 3.5 | 5.6 | pts&gt;=20 | 11 |
| 2 | Stephen Curry | 5 | 2 | 3 | 28.6 | 2.0 | 3.2 | pts&gt;=20 | 5 |
| 3 | Stephen Curry | 3 | 1 | 2 | 34.3 | 3.0 | 5.0 | pts&gt;=20 | 3 |

- Query: `How many times did Curry score 20 or more points in 3 straight games in 2025-26?`
- Family / concept / variant: `streaks` / `<none>` / `synonym`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_streak_finder` / `ok` / `<none>`
- Actual route / status / shape: `player_streak_finder` / `ok` / `streak_table`
- Machine expectation status: `pass`
- Backend answer text: Stephen Curry has had 5 streaks of 3+ straight games with 20+ points in the 2025-26 regular season.
- Answer summary: Count: 5
- Filters: `pts min=20.0 (threshold)`
- Sections: `count` 1 row(s), `streak` 5 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k09_w1_last_n_control

#### k09_w1_last_n_control

**Query**  
Celtics record in their last 10 games in 2023-24

**Answer shown**  
The Boston Celtics are 7-3 in 2023-24 Regular Season, a 70% win rate.

**Rendered output**

##### Card — Team Record

Subject: Boston Celtics  
Mode: Team record  
Filter: Last N games: 10; Sample selection: Select the last 10 games matching the conditions  
Record: 7-3  
Games: 10  
Win %: 70.0%  
PPG: 116.7  
+/-: 9.9  

##### Table — Team record

Subject: Boston Celtics  
Mode: Team record  
Filter: Last N games: 10; Sample selection: Select the last 10 games matching the conditions  
Table type: record_summary  
Column schema: team_record_summary_default  
Rows: 1  

| Team | W-L | Games | Win % | PPG | +/- |
| --- | --- | --- | --- | --- | --- |
| Boston Celtics | 7-3 | 10 | 70.0% | 116.7 | 9.9 |

##### Detail — Game Detail

Subject: Boston Celtics  
Mode: Team game log  
Filter: Last N games: 10; Sample selection: Select the last 10 games matching the conditions  
Table type: team_game_log  
Column schema: team_game_log_default  
Rows: 10  
Collapsed label: Show game detail  

| # | Date | Team |  | Opp | Score | W/L | PTS | Opp PTS | Margin | REB | AST | 3PM | FG | 3P | FT | TOV | STL | BLK | oreb | dreb |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Mar 28 | BOS |  | ATL | 122-123 | L | 122 | 123 | — | 43 | 28 | 14 | — | — | — | 12 | 7 | 6 | 9 | 34 |
| 2 | Mar 30 | BOS |  | NOP | 104-92 | W | 104 | 92 | — | 51 | 27 | 15 | — | — | — | 12 | 7 | 7 | 8 | 43 |
| 3 | Apr 1 | BOS |  | CHA | 118-104 | W | 118 | 104 | — | 51 | 28 | 19 | — | — | — | 10 | 3 | 3 | 11 | 40 |

- Query: `Celtics record in their last 10 games in 2023-24`
- Family / concept / variant: `team_records` / `<none>` / `inverse_sibling`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `team_record` / `ok` / `<none>`
- Actual route / status / shape: `team_record` / `ok` / `team_record`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Boston Celtics -- 7-3 over 10 games, 116.7 PPG, 45.7 RPG, 29 APG, Regular Season
- Filters: `Last N games=10 (window)`, `Sample selection=Select the last 10 games matching the conditions (window)`
- Sections: `summary` 1 row(s), `by_season` 1 row(s), `game_log` 10 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k09_w2_last_n_control

#### k09_w2_last_n_control

**Query**  
Stephen Curry best 5 game 3 point shooting stretch over his last 5 games in 2015-16

**Answer shown**  
Stephen Curry's best 5-game stretch of 2015-16 was 38.1% from three from 2016-04-05 to 2016-04-13.

**Rendered output**

##### Table — Rolling Stretch

Subject: Stephen Curry  
Mode: rolling stretch  
Table type: leaderboard  
Column schema: leaderboard_default  
Rows: 1  

| Rank | Player Name | Team Abbr | Window Size | Stretch Metric | Window Start Date | Window End Date | Window Start Season | Games In Window | Window End Season |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Stephen Curry | GSW | 5 | fg3_pct | Apr 5 | Apr 13 | 2015-16 | 5 | 2015-16 |

- Query: `Stephen Curry best 5 game 3 point shooting stretch over his last 5 games in 2015-16`
- Family / concept / variant: `rolling_stretches` / `<none>` / `inverse_sibling`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_stretch_leaderboard` / `ok` / `<none>`
- Actual route / status / shape: `player_stretch_leaderboard` / `ok` / `rolling_stretch`
- Machine expectation status: `pass`
- Backend answer text: Stephen Curry's best 5-game stretch of 2015-16 was 38.1% from three from 2016-04-05 to 2016-04-13.
- Answer summary: Top row: Stephen Curry -- GSW
- Filters: `Last N games=5 (window)`, `Sample selection=Check conditions within the last 5 games (window)`
- Sections: `leaderboard` 1 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k09_c2_single_season_control

#### k09_c2_single_season_control

**Query**  
Curry most consecutive games with a three in 2015-16

**Answer shown**  
Top row: Stephen Curry

**Rendered output**

##### Table — Streaks

Subject: Stephen Curry  
Mode: streak table  
Table type: streak_table  
Column schema: streak_default  
Rows: 1  

| Rank | Player Name | Games | Wins | Losses | Pts Avg | Reb Avg | Ast Avg | Condition | Streak Length |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Stephen Curry | 79 | 71 | 8 | 30.1 | 5.4 | 6.7 | made_three | 79 |

- Query: `Curry most consecutive games with a three in 2015-16`
- Family / concept / variant: `streaks` / `<none>` / `inverse_sibling`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_streak_finder` / `ok` / `<none>`
- Actual route / status / shape: `player_streak_finder` / `ok` / `streak_table`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: streak: Stephen Curry -- 71 WINS
- Filters: _none_
- Sections: `streak` 1 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k10_g1

#### k10_g1

**Query**  
Warriors playoff record in 2015-16

**Answer shown**  
The Golden State Warriors are 15-9 in 2015-16 Playoffs, a 62.5% win rate.

**Rendered output**

##### Card — Team Record

Subject: Golden State Warriors  
Mode: Team record  
Record: 15-9  
Games: 24  
Win %: 62.5%  
PPG: 107.7  
+/-: 4.4  

##### Table — Team record

Subject: Golden State Warriors  
Mode: Team record  
Table type: record_summary  
Column schema: team_record_summary_default  
Rows: 1  

| Team | W-L | Games | Win % | PPG | +/- |
| --- | --- | --- | --- | --- | --- |
| Golden State Warriors | 15-9 | 24 | 62.5% | 107.7 | 4.4 |

- Query: `Warriors playoff record in 2015-16`
- Family / concept / variant: `playoff_history` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `team_record` / `ok` / `<none>`
- Actual route / status / shape: `team_record` / `ok` / `team_record`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Golden State Warriors -- 15-9 over 24 games, 107.708 PPG, 43.208 RPG, 24.292 APG, Playoffs
- Filters: _none_
- Sections: `summary` 1 row(s), `by_season` 1 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k10_s1

#### k10_s1

**Query**  
Warriors playoff series record in 2015-16

**Answer shown**  
The Golden State Warriors went 3-1 in playoff series in 2015-16 (15-9 in games).

**Rendered output**

##### Table — Playoff History

Mode: history  
Table type: playoff_history  
Column schema: playoff_history_default  
Rows: 1  

| Season | Games | Wins | Losses | Win Pct | Deepest Round |
| --- | --- | --- | --- | --- | --- |
| 2015-16 | 24 | 15 | 9 | 62.5% | Finals |

- Query: `Warriors playoff series record in 2015-16`
- Family / concept / variant: `playoff_history` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `playoff_history` / `ok` / `<none>`
- Actual route / status / shape: `playoff_history` / `ok` / `playoff_history`
- Machine expectation status: `pass`
- Backend answer text: The Golden State Warriors went 3-1 in playoff series in 2015-16 (15-9 in games).
- Answer summary: Golden State Warriors -- 15-9 over 24 games, Playoffs
- Filters: _none_
- Sections: `summary` 1 row(s), `by_season` 1 row(s), `series` 4 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k10_a1

#### k10_a1

**Query**  
Warriors playoff appearances from 2014-15 to 2018-19

**Answer shown**  
The Golden State Warriors reached the playoffs 5 times from 2014-15 to 2018-19.

**Rendered output**

##### Table — Playoff History

Mode: appearances  
Table type: playoff_history  
Column schema: playoff_history_default  
Rows: 5  

| Season | Games | Wins | Losses | Win Pct |
| --- | --- | --- | --- | --- |
| 2014-15 | 21 | 16 | 5 | 76.2% |
| 2015-16 | 24 | 15 | 9 | 62.5% |
| 2016-17 | 17 | 16 | 1 | 94.1% |

- Query: `Warriors playoff appearances from 2014-15 to 2018-19`
- Family / concept / variant: `playoff_history` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `playoff_appearances` / `ok` / `<none>`
- Actual route / status / shape: `playoff_appearances` / `ok` / `leaderboard_table`
- Machine expectation status: `pass`
- Backend answer text: The Golden State Warriors reached the playoffs 5 times from 2014-15 to 2018-19.
- Answer summary: Golden State Warriors -- Playoffs
- Filters: `Season range=2014-15 – 2018-19 (season)`
- Sections: `summary` 1 row(s), `by_season` 5 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k10_r1

#### k10_r1

**Query**  
Warriors Finals record in 2015-16

**Answer shown**  
The Golden State Warriors won 0 of 1 Finals series in 2015-16, going 3-4 in those games.

**Rendered output**

##### Table — Playoff History

Mode: history  
Table type: playoff_history  
Column schema: playoff_history_default  
Rows: 1  

| Season | Games | Wins | Losses | Win Pct |
| --- | --- | --- | --- | --- |
| 2015-16 | 7 | 3 | 4 | 42.9% |

- Query: `Warriors Finals record in 2015-16`
- Family / concept / variant: `playoff_history` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `playoff_history` / `ok` / `<none>`
- Actual route / status / shape: `playoff_history` / `ok` / `playoff_history`
- Machine expectation status: `pass`
- Backend answer text: The Golden State Warriors won 0 of 1 Finals series in 2015-16, going 3-4 in those games.
- Answer summary: Golden State Warriors -- 3-4 over 7 games, Playoffs
- Filters: _none_
- Sections: `summary` 1 row(s), `by_season` 1 row(s), `series` 1 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k10_q1

#### k10_q1

**Query**  
Warriors record in elimination games in 2015-16

**Answer shown**  
The Golden State Warriors are 3-1 in 2015-16 Playoffs, a 75% win rate.

**Rendered output**

##### Card — Team Record

Subject: Golden State Warriors  
Mode: Team record  
Filter: Series situation: elimination games (one loss from going home)  
Record: 3-1  
Games: 4  
Win %: 75.0%  
PPG: 103.2  
+/-: 5.0  

##### Table — Team record

Subject: Golden State Warriors  
Mode: Team record  
Filter: Series situation: elimination games (one loss from going home)  
Table type: record_summary  
Column schema: team_record_summary_default  
Rows: 1  

| Team | W-L | Games | Win % | PPG | +/- |
| --- | --- | --- | --- | --- | --- |
| Golden State Warriors | 3-1 | 4 | 75.0% | 103.2 | 5.0 |

- Query: `Warriors record in elimination games in 2015-16`
- Family / concept / variant: `playoff_history` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `team_record` / `ok` / `<none>`
- Actual route / status / shape: `team_record` / `ok` / `team_record`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Golden State Warriors -- 3-1 over 4 games, 103.25 PPG, 43.5 RPG, 22.5 APG, Playoffs
- Filters: `Series situation=elimination games (one loss from going home) (situation)`
- Sections: `summary` 1 row(s), `by_season` 1 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k10_f1

#### k10_f1

**Query**  
Thunder playoff appearances from 2000-01 to 2004-05

**Answer shown**  
The Seattle SuperSonics reached the playoffs 2 times from 2000-01 to 2004-05.

**Rendered output**

##### Table — Playoff History

Mode: appearances  
Table type: playoff_history  
Column schema: playoff_history_default  
Rows: 2  

| Season | Games | Wins | Losses | Win Pct |
| --- | --- | --- | --- | --- |
| 2001-02 | 5 | 2 | 3 | 40.0% |
| 2004-05 | 11 | 6 | 5 | 54.5% |

- Query: `Thunder playoff appearances from 2000-01 to 2004-05`
- Family / concept / variant: `playoff_history` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `playoff_appearances` / `ok` / `<none>`
- Actual route / status / shape: `playoff_appearances` / `ok` / `leaderboard_table`
- Machine expectation status: `pass`
- Backend answer text: The Seattle SuperSonics reached the playoffs 2 times from 2000-01 to 2004-05.
- Answer summary: Seattle SuperSonics -- Playoffs
- Filters: `Season range=2000-01 – 2004-05 (season)`
- Sections: `summary` 1 row(s), `by_season` 2 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k10_t1

#### k10_t1

**Query**  
Lakers titles from 2000 to 2002

**Answer shown**  
The Los Angeles Lakers won 3 titles from 1999-00 to 2001-02 (1999-00, 2000-01, 2001-02), in 3 Finals appearances.

**Rendered output**

##### Table — Playoff History

Mode: history  
Table type: playoff_history  
Column schema: playoff_history_default  
Rows: 3  

| Season | Games | Wins | Losses | Win Pct | Deepest Round |
| --- | --- | --- | --- | --- | --- |
| 1999-00 | 23 | 15 | 8 | 65.2% | Finals |
| 2000-01 | 16 | 15 | 1 | 93.8% | Finals |
| 2001-02 | 19 | 15 | 4 | 78.9% | Finals |

- Query: `Lakers titles from 2000 to 2002`
- Family / concept / variant: `playoff_history` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `playoff_history` / `ok` / `<none>`
- Actual route / status / shape: `playoff_history` / `ok` / `playoff_history`
- Machine expectation status: `pass`
- Backend answer text: The Los Angeles Lakers won 3 titles from 1999-00 to 2001-02 (1999-00, 2000-01, 2001-02), in 3 Finals appearances.
- Answer summary: Los Angeles Lakers -- 45-13 over 58 games, Playoffs
- Filters: `Season range=1999-00 – 2001-02 (season)`
- Sections: `summary` 1 row(s), `by_season` 3 row(s), `series` 12 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k10_t2

#### k10_t2

**Query**  
Cavaliers titles from 2014-15 to 2017-18

**Answer shown**  
The Cleveland Cavaliers won 1 title from 2014-15 to 2017-18 (2015-16), in 4 Finals appearances.

**Rendered output**

##### Table — Playoff History

Mode: history  
Table type: playoff_history  
Column schema: playoff_history_default  
Rows: 4  

| Season | Games | Wins | Losses | Win Pct | Deepest Round |
| --- | --- | --- | --- | --- | --- |
| 2014-15 | 20 | 14 | 6 | 70.0% | Finals |
| 2015-16 | 21 | 16 | 5 | 76.2% | Finals |
| 2016-17 | 18 | 13 | 5 | 72.2% | Finals |

- Query: `Cavaliers titles from 2014-15 to 2017-18`
- Family / concept / variant: `playoff_history` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `playoff_history` / `ok` / `<none>`
- Actual route / status / shape: `playoff_history` / `ok` / `playoff_history`
- Machine expectation status: `pass`
- Backend answer text: The Cleveland Cavaliers won 1 title from 2014-15 to 2017-18 (2015-16), in 4 Finals appearances.
- Answer summary: Cleveland Cavaliers -- 55-26 over 81 games, Playoffs
- Filters: `Season range=2014-15 – 2017-18 (season)`
- Sections: `summary` 1 row(s), `by_season` 4 row(s), `series` 16 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k10_f1_seattle

#### k10_f1_seattle

**Query**  
How many times did Seattle make the playoffs between 2000-01 and 2004-05?

**Answer shown**  
The Seattle SuperSonics reached the playoffs 2 times from 2000-01 to 2004-05.

**Rendered output**

##### Table — Playoff History

Mode: appearances  
Table type: playoff_history  
Column schema: playoff_history_default  
Rows: 2  

| Season | Games | Wins | Losses | Win Pct |
| --- | --- | --- | --- | --- |
| 2001-02 | 5 | 2 | 3 | 40.0% |
| 2004-05 | 11 | 6 | 5 | 54.5% |

- Query: `How many times did Seattle make the playoffs between 2000-01 and 2004-05?`
- Family / concept / variant: `playoff_history` / `<none>` / `synonym`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `playoff_appearances` / `ok` / `<none>`
- Actual route / status / shape: `playoff_appearances` / `ok` / `leaderboard_table`
- Machine expectation status: `pass`
- Backend answer text: The Seattle SuperSonics reached the playoffs 2 times from 2000-01 to 2004-05.
- Answer summary: Seattle SuperSonics -- Playoffs
- Filters: `Season range=2000-01 – 2004-05 (season)`
- Sections: `summary` 1 row(s), `by_season` 2 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k10_s1_postseason

#### k10_s1_postseason

**Query**  
Golden State postseason series record in 2015-16

**Answer shown**  
The Golden State Warriors went 3-1 in playoff series in 2015-16 (15-9 in games).

**Rendered output**

##### Table — Playoff History

Mode: history  
Table type: playoff_history  
Column schema: playoff_history_default  
Rows: 1  

| Season | Games | Wins | Losses | Win Pct | Deepest Round |
| --- | --- | --- | --- | --- | --- |
| 2015-16 | 24 | 15 | 9 | 62.5% | Finals |

- Query: `Golden State postseason series record in 2015-16`
- Family / concept / variant: `playoff_history` / `<none>` / `synonym`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `playoff_history` / `ok` / `<none>`
- Actual route / status / shape: `playoff_history` / `ok` / `playoff_history`
- Machine expectation status: `pass`
- Backend answer text: The Golden State Warriors went 3-1 in playoff series in 2015-16 (15-9 in games).
- Answer summary: Golden State Warriors -- 15-9 over 24 games, Playoffs
- Filters: _none_
- Sections: `summary` 1 row(s), `by_season` 1 row(s), `series` 4 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k11_l1

#### k11_l1

**Query**  
top 5 scoring games in 2023-24

**Answer shown**  
Luka Dončić had the top scoring game in 2023-24 Regular Season with 73 points in a win against ATL on Jan 26.

**Rendered output**

##### Table — Top Performances

Subject: Players  
Mode: single-game player performances  
Table type: top_performances  
Column schema: top_performances_default  
Rows: 5  

| Rank | Player | Team | Date | Opp | W/L | PTS | MIN | REB | AST | FG | 3P |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Luka Dončić | DAL | Jan 26 | ATL | W | 73 | 45 | 10 | 7 | — | — |
| 2 | Joel Embiid | PHI | Jan 22 | SAS | W | 70 | 37 | 18 | 5 | — | — |
| 3 | Giannis Antetokounmpo | MIL | Dec 13 | IND | W | 64 | 37 | 14 | 3 | — | — |

- Query: `top 5 scoring games in 2023-24`
- Family / concept / variant: `top_single_game_performances` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `top_player_games` / `ok` / `<none>`
- Actual route / status / shape: `top_player_games` / `ok` / `top_performances`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Top row: Luka Dončić -- 73 PTS, 2024-01-26 DAL vs ATL
- Filters: _none_
- Sections: `leaderboard` 5 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k11_l2

#### k11_l2

**Query**  
top 3 assist games vs Celtics in 2023-24

**Answer shown**  
Dejounte Murray had the top assist game in 2023-24 Regular Season with 15 assists in a win against BOS on Mar 25.

**Rendered output**

##### Table — Top Performances

Subject: Players  
Mode: single-game player performances  
Filter: Opponent: BOS  
Table type: top_performances  
Column schema: top_performances_default  
Rows: 3  

| Rank | Player | Team | Date | Opp | W/L | AST | MIN | PTS | REB | FG | 3P |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Dejounte Murray | ATL | Mar 25 | BOS | W | 15 | 41 | 19 | 5 | — | — |
| 2 | D'Angelo Russell | LAL | Feb 1 | BOS | W | 14 | 39 | 16 | 8 | — | — |
| 3 | Tyrese Haliburton | IND | Dec 4 | BOS | W | 13 | 40 | 26 | 10 | — | — |

- Query: `top 3 assist games vs Celtics in 2023-24`
- Family / concept / variant: `top_single_game_performances` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `top_player_games` / `ok` / `<none>`
- Actual route / status / shape: `top_player_games` / `ok` / `top_performances`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Top row: Dejounte Murray -- 15 AST, 2024-03-25 ATL vs BOS
- Filters: `Opponent=BOS (team)`
- Sections: `leaderboard` 3 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k11_t1

#### k11_t1

**Query**  
Lakers players top 5 scoring games in 2023-24

**Answer shown**  
D'Angelo Russell had 5 games matching in 2023-24.

**Rendered output**

##### Table — Player Game Detail

Subject: D'Angelo Russell  
Mode: Player game log  
Table type: player_game_log  
Column schema: player_game_log_default  
Rows: 5  

| # | Player | Date | TM |  | Opp | W/L | MIN | PTS | REB | AST | FG | 3P | FT | STL | BLK | TOV | +/- | TS% | eFG% |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | D'Angelo Russell | Mar 8 | LAL |  | MIL | W | 38 | 44 | 6 | 9 | — | — | — | 0 | 1 | 2 | 1 | 86.5% | 86.0% |
| 2 | Anthony Davis | Jan 9 | LAL |  | TOR | W | 40 | 41 | 11 | 6 | — | — | — | 0 | 1 | 3 | 0 | 88.5% | 82.4% |
| 3 | LeBron James | Mar 31 | LAL |  | BKN | W | 37 | 40 | 7 | 5 | — | — | — | 0 | 0 | 4 | 22 | 1.0% | 1.0% |

- Query: `Lakers players top 5 scoring games in 2023-24`
- Family / concept / variant: `game_finders` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_game_finder` / `ok` / `<none>`
- Actual route / status / shape: `player_game_finder` / `ok` / `game_log_table`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Top row: D'Angelo Russell -- 44 PTS, 2024-03-08 LAL vs MIL
- Filters: _none_
- Sections: `finder` 5 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k11_t2

#### k11_t2

**Query**  
Celtics players top 3 rebounding games vs Knicks in 2023-24

**Answer shown**  
Jayson Tatum had 3 games matching in 2023-24.

**Rendered output**

##### Table — Player Game Detail

Subject: Jayson Tatum  
Mode: Player game log  
Filter: Opponent: NYK  
Table type: player_game_log  
Column schema: player_game_log_default  
Rows: 3  

| # | Player | Date | TM |  | Opp | W/L | MIN | PTS | REB | AST | FG | 3P | FT | STL | BLK | TOV | +/- | TS% | eFG% |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Jayson Tatum | Oct 25 | BOS |  | NYK | W | 39 | 34 | 11 | 4 | — | — | — | 2 | 1 | 4 | 0 | 69.0% | 65.9% |
| 2 | Al Horford | Dec 8 | BOS |  | NYK | W | 27 | 14 | 10 | 2 | — | — | — | 0 | 0 | 2 | 9 | 82.9% | 81.2% |
| 3 | Kristaps Porziņģis | Apr 11 | BOS |  | NYK | L | 25 | 14 | 8 | 1 | — | — | — | 0 | 2 | 1 | -14 | 54.3% | 50.0% |

- Query: `Celtics players top 3 rebounding games vs Knicks in 2023-24`
- Family / concept / variant: `game_finders` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_game_finder` / `ok` / `<none>`
- Actual route / status / shape: `player_game_finder` / `ok` / `game_log_table`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Top row: Jayson Tatum -- 11 REB, 2023-10-25 BOS vs NYK
- Filters: `Opponent=NYK (team)`
- Sections: `finder` 3 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k11_r1

#### k11_r1

**Query**  
top 5 scoring games by rookies in 2023-24

**Answer shown**  
GG Jackson had 5 games matching in 2023-24.

**Rendered output**

##### Table — Player Game Detail

Subject: GG Jackson  
Mode: Player game log  
Filter: Experience: Rookies  
Table type: player_game_log  
Column schema: player_game_log_default  
Rows: 5  

| # | Player | Date | TM |  | Opp | W/L | MIN | PTS | REB | AST | FG | 3P | FT | STL | BLK | TOV | +/- | TS% | eFG% |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | GG Jackson | Apr 14 | MEM |  | DEN | L | 44 | 44 | 12 | 1 | — | — | — | 2 | 1 | 3 | -13 | 56.3% | 52.8% |
| 2 | Victor Wembanyama | Mar 29 | SAS |  | NYK | W | 38 | 40 | 20 | 7 | — | — | — | 2 | 1 | 4 | 1 | 73.3% | 68.2% |
| 3 | Victor Wembanyama | Nov 2 | SAS |  | PHX | W | 34 | 38 | 10 | 2 | — | — | — | 1 | 2 | 2 | 21 | 66.3% | 63.5% |

- Query: `top 5 scoring games by rookies in 2023-24`
- Family / concept / variant: `game_finders` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_game_finder` / `ok` / `<none>`
- Actual route / status / shape: `player_game_finder` / `ok` / `game_log_table`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Top row: GG Jackson -- 44 PTS, 2024-04-14 MEM vs DEN
- Filters: `Experience=Rookies (position)`
- Sections: `finder` 5 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k11_r2

#### k11_r2

**Query**  
top 5 scoring games by rookies in 1998-99

**Answer shown**  
Ricky Davis had 5 games matching in 1998-99.

**Rendered output**

##### Table — Player Game Detail

Subject: Ricky Davis  
Mode: Player game log  
Filter: Experience: Rookies  
Table type: player_game_log  
Column schema: player_game_log_default  
Rows: 5  

| # | Player | Date | TM |  | Opp | W/L | MIN | PTS | REB | AST | FG | 3P | FT | STL | BLK | TOV | +/- | TS% | eFG% |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Ricky Davis | May 5 | CHH |  | BOS | W | 41 | 32 | 7 | 2 | — | — | — | 1 | 1 | 2 | 18 | 66.8% | 60.0% |
| 2 | Brad Miller | May 5 | CHH |  | BOS | W | 38 | 32 | 13 | 4 | — | — | — | 0 | 1 | 2 | 18 | 68.1% | 56.2% |
| 3 | Vince Carter | Mar 25 | TOR |  | HOU | L | 42 | 32 | 2 | 6 | — | — | — | 1 | 1 | 4 | -7 | 73.5% | 70.0% |

- Query: `top 5 scoring games by rookies in 1998-99`
- Family / concept / variant: `game_finders` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_game_finder` / `ok` / `<none>`
- Actual route / status / shape: `player_game_finder` / `ok` / `game_log_table`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Top row: Ricky Davis -- 32 PTS, 1999-05-05 CHH vs BOS
- Filters: `Experience=Rookies (position)`
- Sections: `finder` 5 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k11_p1

#### k11_p1

**Query**  
top 5 rebounding games by centers in 2023-24

**Answer shown**  
Jusuf Nurkić had 5 games matching in 2023-24.

**Rendered output**

##### Table — Player Game Detail

Subject: Jusuf Nurkić  
Mode: Player game log  
Filter: Position: centers  
Table type: player_game_log  
Column schema: player_game_log_default  
Rows: 5  

| # | Player | Date | TM |  | Opp | W/L | MIN | PTS | REB | AST | FG | 3P | FT | STL | BLK | TOV | +/- | TS% | eFG% |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Jusuf Nurkić | Mar 3 | PHX |  | OKC | L | 32 | 14 | 31 | 4 | — | — | — | 0 | 1 | 5 | 10 | 43.8% | 43.8% |
| 2 | Andre Drummond | Feb 28 | CHI |  | CLE | W | 36 | 17 | 26 | 1 | — | — | — | 0 | 3 | 3 | 2 | 66.0% | 66.7% |
| 3 | Andre Drummond | Dec 26 | CHI |  | ATL | W | 38 | 24 | 25 | 1 | — | — | — | 3 | 2 | 2 | 4 | 86.5% | 84.6% |

- Query: `top 5 rebounding games by centers in 2023-24`
- Family / concept / variant: `game_finders` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_game_finder` / `ok` / `<none>`
- Actual route / status / shape: `player_game_finder` / `ok` / `game_log_table`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Top row: Jusuf Nurkić -- 31 REB, 2024-03-03 PHX vs OKC
- Filters: `Position=centers (position)`
- Sections: `finder` 5 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k11_p2

#### k11_p2

**Query**  
top 3 assist games by guards in 2023-24

**Answer shown**  
Tyrese Haliburton had 3 games matching in 2023-24.

**Rendered output**

##### Table — Player Game Detail

Subject: Tyrese Haliburton  
Mode: Player game log  
Filter: Position: guards  
Table type: player_game_log  
Column schema: player_game_log_default  
Rows: 3  

| # | Player | Date | TM |  | Opp | W/L | MIN | PTS | REB | AST | FG | 3P | FT | STL | BLK | TOV | +/- | TS% | eFG% |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Tyrese Haliburton | Dec 30 | IND |  | NYK | W | 36 | 22 | 5 | 23 | — | — | — | 2 | 1 | 2 | 19 | 58.6% | 52.9% |
| 2 | Tyrese Haliburton | Dec 28 | IND |  | CHI | W | 37 | 21 | 3 | 20 | — | — | — | 2 | 1 | 0 | 32 | 58.7% | 58.8% |
| 3 | Immanuel Quickley | Mar 7 | TOR |  | PHX | L | 40 | 21 | 9 | 18 | — | — | — | 1 | 0 | 2 | 2 | 58.7% | 58.8% |

- Query: `top 3 assist games by guards in 2023-24`
- Family / concept / variant: `game_finders` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_game_finder` / `ok` / `<none>`
- Actual route / status / shape: `player_game_finder` / `ok` / `game_log_table`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Top row: Tyrese Haliburton -- 23 AST, 2023-12-30 IND vs NYK
- Filters: `Position=guards (position)`
- Sections: `finder` 3 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k11_p3

#### k11_p3

**Query**  
top 3 scoring games by forwards in 1998-99

**Answer shown**  
Antonio McDyess had 3 games matching in 1998-99.

**Rendered output**

##### Table — Player Game Detail

Subject: Antonio McDyess  
Mode: Player game log  
Filter: Position: forwards  
Table type: player_game_log  
Column schema: player_game_log_default  
Rows: 3  

| # | Player | Date | TM |  | Opp | W/L | MIN | PTS | REB | AST | FG | 3P | FT | STL | BLK | TOV | +/- | TS% | eFG% |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Antonio McDyess | Feb 28 | DEN |  | VAN | W | 41 | 46 | 19 | 1 | — | — | — | 1 | 4 | 3 | 2 | 69.9% | 64.0% |
| 2 | Grant Hill | Feb 8 | DET |  | WAS | W | 43 | 46 | 7 | 7 | — | — | — | 2 | 2 | 4 | 17 | 75.0% | 66.7% |
| 3 | Tim Duncan | Apr 1 | SAS |  | VAN | W | 46 | 39 | 13 | 0 | — | — | — | 0 | 6 | 3 | 11 | 62.0% | 61.3% |

- Query: `top 3 scoring games by forwards in 1998-99`
- Family / concept / variant: `game_finders` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_game_finder` / `ok` / `<none>`
- Actual route / status / shape: `player_game_finder` / `ok` / `game_log_table`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Top row: Antonio McDyess -- 46 PTS, 1999-02-28 DEN vs VAN
- Filters: `Position=forwards (position)`
- Sections: `finder` 3 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k11_c1

#### k11_c1

**Query**  
top 3 scoring games by rookie guards in 2023-24

**Answer shown**  
Jordan Hawkins had 3 games matching in 2023-24.

**Rendered output**

##### Table — Player Game Detail

Subject: Jordan Hawkins  
Mode: Player game log  
Filter: Position: guards; Experience: Rookies  
Table type: player_game_log  
Column schema: player_game_log_default  
Rows: 3  

| # | Player | Date | TM |  | Opp | W/L | MIN | PTS | REB | AST | FG | 3P | FT | STL | BLK | TOV | +/- | TS% | eFG% |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Jordan Hawkins | Jan 13 | NOP |  | DAL | W | 37 | 34 | 5 | 4 | — | — | — | 2 | 0 | 3 | 10 | 75.5% | 73.7% |
| 2 | Keyonte George | Feb 15 | UTA |  | GSW | L | 41 | 33 | 2 | 6 | — | — | — | 3 | 0 | 2 | 7 | 70.8% | 70.5% |
| 3 | Scoot Henderson | Jan 14 | POR |  | PHX | L | 40 | 33 | 7 | 9 | — | — | — | 3 | 0 | 3 | -12 | 47.2% | 41.9% |

- Query: `top 3 scoring games by rookie guards in 2023-24`
- Family / concept / variant: `game_finders` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_game_finder` / `ok` / `<none>`
- Actual route / status / shape: `player_game_finder` / `ok` / `game_log_table`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Top row: Jordan Hawkins -- 34 PTS, 2024-01-13 NOP vs DAL
- Filters: `Position=guards (position)`, `Experience=Rookies (position)`
- Sections: `finder` 3 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k11_r2_leading_season

#### k11_r2_leading_season

**Query**  
In 1998-99, rookies top 5 scoring performances

**Answer shown**  
Ricky Davis had 5 games matching in 1998-99.

**Rendered output**

##### Table — Player Game Detail

Subject: Ricky Davis  
Mode: Player game log  
Filter: Experience: Rookies  
Table type: player_game_log  
Column schema: player_game_log_default  
Rows: 5  

| # | Player | Date | TM |  | Opp | W/L | MIN | PTS | REB | AST | FG | 3P | FT | STL | BLK | TOV | +/- | TS% | eFG% |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Ricky Davis | May 5 | CHH |  | BOS | W | 41 | 32 | 7 | 2 | — | — | — | 1 | 1 | 2 | 18 | 66.8% | 60.0% |
| 2 | Brad Miller | May 5 | CHH |  | BOS | W | 38 | 32 | 13 | 4 | — | — | — | 0 | 1 | 2 | 18 | 68.1% | 56.2% |
| 3 | Vince Carter | Mar 25 | TOR |  | HOU | L | 42 | 32 | 2 | 6 | — | — | — | 1 | 1 | 4 | -7 | 73.5% | 70.0% |

- Query: `In 1998-99, rookies top 5 scoring performances`
- Family / concept / variant: `game_finders` / `<none>` / `sentence`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_game_finder` / `ok` / `<none>`
- Actual route / status / shape: `player_game_finder` / `ok` / `game_log_table`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Top row: Ricky Davis -- 32 PTS, 1999-05-05 CHH vs BOS
- Filters: `Experience=Rookies (position)`
- Sections: `finder` 5 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k12_s1

#### k12_s1

**Query**  
Stephen Curry averages in 2023-24

**Answer shown**  
Stephen Curry -- 43-31 over 74 games, 26.4 PPG, 4.5 RPG, 5.1 APG

**Rendered output**

##### Card — Summary

Subject: Stephen Curry  
Mode: entity summary  
Games: 74  
Record: 43-31  
PPG: 26.4  
RPG: 4.5  
APG: 5.1  

##### Table — By Season

Subject: Stephen Curry  
Mode: season stats  
Table type: record_summary  
Column schema: player_by_season_default  
Rows: 1  

| Season | Games | Wins | Losses | PPG | REB | AST |
| --- | --- | --- | --- | --- | --- | --- |
| 2023-24 | 74 | 43 | 31 | 26.4 | 4.5 | 5.1 |

- Query: `Stephen Curry averages in 2023-24`
- Family / concept / variant: `player_stats_this_season` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_game_summary` / `ok` / `<none>`
- Actual route / status / shape: `player_game_summary` / `ok` / `entity_summary`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Stephen Curry -- 43-31 over 74 games, 26.432 PPG, 4.459 RPG, 5.122 APG, Regular Season
- Filters: _none_
- Sections: `summary` 1 row(s), `by_season` 1 row(s), `game_log` 74 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k12_r1

#### k12_r1

**Query**  
Celtics record vs NYK from 2023-11-01 to 2024-03-01

**Answer shown**  
The Boston Celtics are 3-0 in 2023-24 Regular Season, a 100% win rate.

**Rendered output**

##### Card — Team Record

Subject: Boston Celtics  
Mode: Team record  
Filter: Opponent: NYK; Date range: 2023-11-01 – 2024-03-01  
Record: 3-0  
Games: 3  
Win %: 100.0%  
PPG: 121.0  
+/-: 13.3  

##### Table — Team record

Subject: Boston Celtics  
Mode: Team record  
Filter: Opponent: NYK; Date range: 2023-11-01 – 2024-03-01  
Table type: record_summary  
Column schema: team_record_summary_default  
Rows: 1  

| Team | W-L | Games | Win % | PPG | +/- | Opponent |
| --- | --- | --- | --- | --- | --- | --- |
| Boston Celtics | 3-0 | 3 | 100.0% | 121.0 | 13.3 | Knicks |

- Query: `Celtics record vs NYK from 2023-11-01 to 2024-03-01`
- Family / concept / variant: `team_records` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `team_record` / `ok` / `<none>`
- Actual route / status / shape: `team_record` / `ok` / `team_record`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Boston Celtics -- 3-0 over 3 games, 121 PPG, 35.667 RPG, 26 APG, Regular Season
- Filters: `Opponent=NYK (team)`, `Date range=2023-11-01 – 2024-03-01 (date)`
- Sections: `summary` 1 row(s), `by_season` 1 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k12_b1

#### k12_b1

**Query**  
Top 5 players by three point percentage in 2023-24 minimum 300 attempts

**Answer shown**  
Grayson Allen led with 46.1% fg3 pct.

**Rendered output**

##### Table — Leaderboard

Subject: League  
Mode: Leaderboard  
Table type: leaderboard  
Column schema: leaderboard_default  
Rows: 5  

| # | Player | 3P% | Season | TM | GP | Type | 3PM | 3PA |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Grayson Allen | 46.1% | 2023-24 | PHX | 75 | Regular Season | 205 | 445 |
| 2 | Mike Conley | 44.2% | 2023-24 | MIN | 76 | Regular Season | 179 | 405 |
| 3 | Norman Powell | 43.5% | 2023-24 | LAC | 76 | Regular Season | 167 | 384 |

- Query: `Top 5 players by three point percentage in 2023-24 minimum 300 attempts`
- Family / concept / variant: `leaderboards` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `season_leaders` / `ok` / `<none>`
- Actual route / status / shape: `season_leaders` / `ok` / `leaderboard_table`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Top row: Grayson Allen -- 0.461 FG3_PCT, PHX
- Filters: _none_
- Sections: `leaderboard` 5 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k12_c1

#### k12_c1

**Query**  
In 2023-24, how many Jalen Brunson games had 8 or more assists and no turnovers?

**Answer shown**  
Jalen Brunson has had 4 games with 8+ assists and at most 0 turnovers in the 2023-24 regular season.

**Rendered output**

_No rendered blocks._
- Query: `In 2023-24, how many Jalen Brunson games had 8 or more assists and no turnovers?`
- Family / concept / variant: `count_queries` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_occurrence_leaders` / `ok` / `<none>`
- Actual route / status / shape: `player_occurrence_leaders` / `ok` / `leaderboard_table`
- Machine expectation status: `pass`
- Backend answer text: Jalen Brunson has had 4 games with 8+ assists and at most 0 turnovers in the 2023-24 regular season.
- Answer summary: Count: 4
- Filters: `ast min=8.0 (threshold)`, `tov max=0.0 (threshold)`
- Sections: `count` 1 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k12_l1

#### k12_l1

**Query**  
top 5 scoring games by rookies in 2023-24

**Answer shown**  
GG Jackson had 5 games matching in 2023-24.

**Rendered output**

##### Table — Player Game Detail

Subject: GG Jackson  
Mode: Player game log  
Filter: Experience: Rookies  
Table type: player_game_log  
Column schema: player_game_log_default  
Rows: 5  

| # | Player | Date | TM |  | Opp | W/L | MIN | PTS | REB | AST | FG | 3P | FT | STL | BLK | TOV | +/- | TS% | eFG% |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | GG Jackson | Apr 14 | MEM |  | DEN | L | 44 | 44 | 12 | 1 | — | — | — | 2 | 1 | 3 | -13 | 56.3% | 52.8% |
| 2 | Victor Wembanyama | Mar 29 | SAS |  | NYK | W | 38 | 40 | 20 | 7 | — | — | — | 2 | 1 | 4 | 1 | 73.3% | 68.2% |
| 3 | Victor Wembanyama | Nov 2 | SAS |  | PHX | W | 34 | 38 | 10 | 2 | — | — | — | 1 | 2 | 2 | 21 | 66.3% | 63.5% |

- Query: `top 5 scoring games by rookies in 2023-24`
- Family / concept / variant: `game_finders` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_game_finder` / `ok` / `<none>`
- Actual route / status / shape: `player_game_finder` / `ok` / `game_log_table`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Top row: GG Jackson -- 44 PTS, 2024-04-14 MEM vs DEN
- Filters: `Experience=Rookies (position)`
- Sections: `finder` 5 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k12_x1

#### k12_x1

**Query**  
Nuggets home vs away splits against Timberwolves with at least 110 points in 2023-24

**Answer shown**  
Denver Nuggets

**Rendered output**

##### Table — Split Comparison

Mode: team split  
Table type: split_comparison  
Column schema: split_comparison_default  
Rows: 2  

| Games | Wins | Losses | Win Pct | Pts Avg | Reb Avg | Ast Avg | Bucket | Stl Avg | Blk Avg |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 1 | 0 | 100.0% | 116.0 | 44.0 | 31.0 | home | 7.0 | 8.0 |
| 1 | 1 | 0 | 100.0% | 115.0 | 49.0 | 26.0 | away | 5.0 | 1.0 |

- Query: `Nuggets home vs away splits against Timberwolves with at least 110 points in 2023-24`
- Family / concept / variant: `splits` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `team_split_summary` / `ok` / `<none>`
- Actual route / status / shape: `team_split_summary` / `ok` / `entity_summary`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Denver Nuggets -- Regular Season
- Filters: `Opponent=MIN (team)`, `Location=Home (location)`, `Location=Away (location)`, `pts min=110.0 (threshold)`
- Sections: `summary` 1 row(s), `split_comparison` 2 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k12_m1

#### k12_m1

**Query**  
Compare Stephen Curry and Jalen Brunson averages in 2023-24.

**Answer shown**  
Stephen Curry -- 43-31 over 74 games, 26.4 PPG, 4.5 RPG, 5.1 APG

**Rendered output**

##### Table — Comparison

Mode: player comparison  
Table type: comparison_table  
Column schema: comparison_default  
Rows: 20  

| Metric | Stephen Curry | Jalen Brunson |
| --- | --- | --- |
| games | 74 | 77 |
| wins | 43 | 49 |
| losses | 31 | 28 |

- Query: `Compare Stephen Curry and Jalen Brunson averages in 2023-24.`
- Family / concept / variant: `comparisons` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_compare` / `ok` / `<none>`
- Actual route / status / shape: `player_compare` / `ok` / `comparison`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Stephen Curry -- 43-31 over 74 games, 26.432 PPG, 4.459 RPG, 5.122 APG, Regular Season
- Filters: _none_
- Sections: `summary` 2 row(s), `comparison` 20 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k12_z1

#### k12_z1

**Query**  
How many Nikola Jokic games reached at least 80 points in 2023-24?

**Answer shown**  
Nikola Jokić has had 0 games with 80+ points in the 2023-24 regular season.

**Rendered output**

_No rendered blocks._
- Query: `How many Nikola Jokic games reached at least 80 points in 2023-24?`
- Family / concept / variant: `count_queries` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_game_finder` / `ok` / `<none>`
- Actual route / status / shape: `player_game_finder` / `ok` / `unknown`
- Machine expectation status: `pass`
- Backend answer text: Nikola Jokić has had 0 games with 80+ points in the 2023-24 regular season.
- Answer summary: Count: 0
- Filters: `pts min=80.0 (threshold)`
- Sections: `count` 1 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k12_e1

#### k12_e1

**Query**  
List Jalen Brunson games with 80 or more points in 2023-24.

**Answer shown**  
No answer returned.

**Rendered output**

##### Message — No result

No answer rows returned; reason=no_match.  

- Query: `List Jalen Brunson games with 80 or more points in 2023-24.`
- Family / concept / variant: `game_finders` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_game_finder` / `no_result` / `<none>`
- Actual route / status / shape: `player_game_finder` / `no_result` / `no_result`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: No answer rows returned; reason=no_match
- Filters: `pts min=80.0 (threshold)`
- Sections: _none_
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k12_n1

#### k12_n1

**Query**  
Stephen Curry stats in 2026-27

**Answer shown**  
No answer returned.

**Rendered output**

##### Message — No result

No answer rows returned; reason=no_data.  

- Query: `Stephen Curry stats in 2026-27`
- Family / concept / variant: `player_stats_this_season` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_game_summary` / `no_result` / `<none>`
- Actual route / status / shape: `player_game_summary` / `no_result` / `no_result`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: No answer rows returned; reason=no_data
- Filters: _none_
- Sections: _none_
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k12_h1

#### k12_h1

**Query**  
Patrick Ewing career stats

**Answer shown**  
Patrick Ewing -- 205-143 over 348 games, 14.4 PPG, 8.4 RPG, 1.2 APG

**Rendered output**

##### Card — Summary

Subject: Patrick Ewing  
Mode: entity summary  
Filter: Season range: 1996-97 – 2025-26  
Games: 348  
Record: 205-143  
PPG: 14.4  
RPG: 8.4  
APG: 1.2  

##### Table — By Season

Subject: Patrick Ewing  
Mode: season stats  
Filter: Season range: 1996-97 – 2025-26  
Table type: record_summary  
Column schema: player_by_season_default  
Rows: 6  

| Season | Games | Wins | Losses | PPG | REB | AST |
| --- | --- | --- | --- | --- | --- | --- |
| 1996-97 | 78 | 54 | 24 | 22.4 | 10.7 | 2.0 |
| 1997-98 | 26 | 15 | 11 | 20.8 | 10.2 | 1.1 |
| 1998-99 | 38 | 20 | 18 | 17.3 | 9.9 | 1.1 |

##### Table — Player Game Log

Subject: Patrick Ewing  
Mode: Player game log  
Filter: Season range: 1996-97 – 2025-26  
Table type: player_game_log  
Column schema: player_game_log_default  
Rows: 348  

| # | Date | TM |  | Opp | W/L | MIN | PTS | REB | AST | FG | 3P | FT | STL | BLK | TOV | +/- | TS% | eFG% |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | Nov 1 | NYK |  | TOR | W | 23 | 18 | 6 | 0 | — | — | — | 2 | 1 | 4 | -5 | 56.4% | 58.3% |
| 2 | Nov 3 | NYK |  | CHH | W | 27 | 16 | 4 | 3 | — | — | — | 3 | 2 | 2 | 32 | 58.7% | 45.5% |
| 3 | Nov 5 | NYK |  | LAL | L | 40 | 21 | 6 | 0 | — | — | — | 3 | 0 | 3 | 1 | 42.6% | 36.4% |

- Query: `Patrick Ewing career stats`
- Family / concept / variant: `player_stats_this_season` / `<none>` / `canonical`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `player_game_summary` / `ok` / `<none>`
- Actual route / status / shape: `player_game_summary` / `ok` / `entity_summary`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Patrick Ewing -- 205-143 over 348 games, 14.445 PPG, 8.414 RPG, 1.184 APG, Regular Season
- Filters: `Season range=1996-97 – 2025-26 (season)`
- Sections: `summary` 1 row(s), `by_season` 6 row(s), `game_log` 348 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

### k12_r1_win_loss

#### k12_r1_win_loss

**Query**  
Celtics win-loss record against Knicks from 2023-11-01 to 2024-03-01

**Answer shown**  
The Boston Celtics are 3-0 in 2023-24 Regular Season, a 100% win rate.

**Rendered output**

##### Card — Team Record

Subject: Boston Celtics  
Mode: Team record  
Filter: Opponent: NYK; Date range: 2023-11-01 – 2024-03-01  
Record: 3-0  
Games: 3  
Win %: 100.0%  
PPG: 121.0  
+/-: 13.3  

##### Table — Team record

Subject: Boston Celtics  
Mode: Team record  
Filter: Opponent: NYK; Date range: 2023-11-01 – 2024-03-01  
Table type: record_summary  
Column schema: team_record_summary_default  
Rows: 1  

| Team | W-L | Games | Win % | PPG | +/- | Opponent |
| --- | --- | --- | --- | --- | --- | --- |
| Boston Celtics | 3-0 | 3 | 100.0% | 121.0 | 13.3 | Knicks |

- Query: `Celtics win-loss record against Knicks from 2023-11-01 to 2024-03-01`
- Family / concept / variant: `team_records` / `<none>` / `synonym`
- Review role: `<none>`
- Sibling of: `<none>`
- Expected route / status / shape: `team_record` / `ok` / `<none>`
- Actual route / status / shape: `team_record` / `ok` / `team_record`
- Machine expectation status: `pass`
- Backend answer text: _not backend-provided_
- Answer summary: Boston Celtics -- 3-0 over 3 games, 121 PPG, 35.667 RPG, 26 APG, Regular Season
- Filters: `Opponent=NYK (team)`, `Date range=2023-11-01 – 2024-03-01 (date)`
- Sections: `summary` 1 row(s), `by_season` 1 row(s)
- Manual review status: `unreviewed`
- Reviewer checkbox: [ ] output scope and answer look correct
- Reviewer notes:

## Unsupported / No-Broad-Fallback Rows

| Case | Family | Variant | Expected status | Actual route/status/shape | Machine expectation |
|---|---|---|---|---|---|
| jokic_triple_double_count | count_queries | canonical | ok | player_game_finder / ok / count_with_finder | pass |
| celtics_record_playoff_teams | playoff_history | inverse_sibling | ok | team_record / ok / team_record | pass |
| team_record_thunder_top_10_teams_006 | team_records | synonym | ok | team_record / ok / team_record | pass |
| team_record_celtics_top_5_teams_006 | team_records | synonym | ok | team_record / ok / team_record | pass |
| team_record_bucks_losing_teams_006 | team_records | synonym | ok | team_record / ok / team_record | pass |
| team_record_suns_bad_teams_006 | team_records | synonym | ok | team_record / ok / team_record | pass |
| team_record_lakers_playoff_teams_006 | team_records | synonym | ok | team_record / ok / team_record | pass |
| team_record_nuggets_winning_teams_006 | team_records | synonym | ok | team_record / ok / team_record | pass |
| team_record_knicks_over_500_006 | team_records | synonym | ok | team_record / ok / team_record | pass |
| team_record_mavericks_west_playoff_teams_006 | team_records | inverse_sibling | ok | team_record / ok / team_record | pass |
| suns_without_booker |  |  | ok | game_summary / no_result / no_result | fail |
| hottest_3_game_scoring_stretch | rolling_stretches | canonical | ok | player_stretch_leaderboard / ok / rolling_stretch | pass |
| jokic_5_straight_20_points | streaks | canonical | ok | player_streak_finder / ok / streak_table | pass |
| lakers_playoff_history | playoff_history | canonical | ok | playoff_history / ok / playoff_history | pass |
| most_points_last_night | date_window_filters | inverse_sibling | no_result | season_leaders / no_result / no_result | pass |
| cooled_off_last_10 | unsupported_subjective_narrative | sentence | no_result | None / no_result / no_result | pass |
| a01_salary_contract_boundary | player_stats_this_season | nearby_unsupported | no_result | None / no_result / no_result | pass |
| a01_multi_player_both_play_count_boundary | count_queries | nearby_unsupported | no_result | None / no_result / no_result | pass |
| a02_team_clutch_count_coverage_boundary | count_queries | nearby_unsupported | no_result | game_finder / no_result / no_result | pass |
| a02_player_clutch_count_coverage_boundary | count_queries | nearby_unsupported | no_result | player_game_finder / no_result / no_result | pass |
| a06_boolean_count_top_level_or | count_queries | sentence | ok | player_game_finder / ok / count_with_finder | pass |
| a06_boolean_count_grouped_or | count_queries | synonym | ok | player_game_finder / ok / count_with_finder | pass |
| rebound_leaders_this_season | top_single_game_performances | inverse_sibling | ok | season_leaders / ok / leaderboard_table | pass |
| defensive_team_leaders_recent |  |  | no_result | season_team_leaders / no_result / no_result | pass |
| most_assists_single_game | leaderboards | inverse_sibling | ok | top_player_games / ok / top_performances | pass |
| most_rebounds_single_game | top_single_game_performances | short | ok | top_player_games / ok / top_performances | pass |
| most_rebounds_single_game_this_year_public_sweep | top_single_game_performances | sentence | ok | top_player_games / ok / top_performances | pass |
| top_scoring_games_single_game_007 | top_single_game_performances | synonym | ok | top_player_games / ok / top_performances | pass |
| highest_team_scoring_games_single_game_007 | top_single_game_performances | sentence | ok | top_team_games / ok / top_performances | pass |
| most_points_by_team_in_game_007 | top_single_game_performances | inverse_sibling | ok | top_team_games / ok / top_performances | pass |
| highest_scoring_teams_season_leader_boundary_007 | top_single_game_performances | inverse_sibling | ok | season_team_leaders / ok / leaderboard_table | pass |
| tatum_recent_form | player_summaries_recent_form | canonical | ok | player_game_summary / ok / entity_summary | pass |
| tatum_vs_lakers_no_result |  |  | no_result | player_game_finder / no_result / no_result | pass |
| tatum_good_teams | player_summaries_recent_form | sentence | ok | player_game_summary / ok / entity_summary | pass |
| celtics_overall_record | team_records | canonical | ok | team_record / ok / team_record | pass |
| lakers_lebron_ad_both_play |  |  | no_result | team_record / no_result / no_result | pass |
| suns_without_booker_shorthand |  |  | ok | team_record / no_result / no_result | fail |
| bucks_without_giannis |  |  | ok | team_record / no_result / no_result | fail |
| knicks_without_brunson |  |  | ok | team_record / no_result / no_result | fail |
| lakers_record_without_luka_public_sweep | team_record_availability | inverse_sibling | ok | team_record / no_result / no_result | fail |
| lakers_record_with_luka_public_sweep | team_record_availability | canonical | ok | team_record / ok / team_record | pass |
| pqa_availability_short_lakers_w_luka | team_record_availability | short | ok | team_record / ok / team_record | pass |
| lakers_record_with_reaves_public_sweep | team_record_availability | synonym | ok | team_record / ok / team_record | pass |
| pqa_availability_synonym_reaves_available | team_record_availability | synonym | ok | team_record / no_result / no_result | fail |
| lakers_record_with_reaves_without_luka_public_sweep | team_record_availability | nearby_unsupported | no_result | team_record / no_result / no_result | pass |
| lakers_record_without_luk_public_sweep | team_record_availability | typo_partial | no_result | team_record / no_result / no_result | pass |
| warriors_wins_without_curry |  |  | ok | team_record / no_result / no_result | fail |
| players_10_assist_count | count_queries | synonym | ok | player_occurrence_leaders / ok / leaderboard_table | pass |
| jokic_30_10_10_finder | count_queries | inverse_sibling | ok | player_game_finder / ok / game_log_table | pass |
| curry_5_threes_finder | game_finders | short | ok | player_game_finder / ok / game_log_table | pass |
| lakers_win_streak | streaks | short | ok | team_streak_finder / ok / streak_table | pass |
| booker_4_game_scoring_stretch | rolling_stretches | short | ok | player_stretch_leaderboard / ok / rolling_stretch | pass |
| team_5_game_scoring_stretch | rolling_stretches | inverse_sibling | ok | team_stretch_leaderboard / ok / leaderboard_table | pass |
| lakers_finals_appearances | playoff_history | short | ok | playoff_appearances / ok / leaderboard_table | pass |
| a03_player_finals_appearances_boundary | playoff_history | sentence | ok | playoff_appearances / ok / leaderboard_table | pass |
| specific_date_jan_1 | date_window_filters | sentence | ok | top_player_games / ok / top_performances | pass |
| jokic_since_all_star_break | date_window_filters | synonym | ok | player_game_finder / ok / game_log_table | pass |
| top_scorers_in_march | date_window_filters | canonical | ok | season_leaders / ok / leaderboard_table | pass |
| best_offensive_teams_since_january |  |  | no_result | season_team_leaders / no_result / no_result | pass |
| jokic_home_away_split | splits | canonical | ok | player_split_summary / ok / entity_summary | pass |
| celtics_wins_losses_split | splits | short | ok | team_split_summary / ok / entity_summary | pass |
| tatum_clutch_stats | unsupported_subjective_narrative | inverse_sibling | no_result | player_game_summary / no_result / no_result | pass |
| best_defender_subjective | unsupported_subjective_narrative | canonical | error | None / error / error | pass |
| mvp_candidates_subjective | player_stats_this_season | nearby_unsupported | error | None / error / error | pass |
| feedback_mvp_award_winner_boundary |  |  | no_result | None / no_result / no_result | pass |
| best_player_lately_ambiguous | player_summaries_recent_form | nearby_unsupported | no_result | None / no_result / no_result | pass |
| true_shooting_percentage_per_game_leaders |  |  | no_result | season_leaders / no_result / no_result | pass |
| biggest_team_three_point_games_boundary | top_single_game_performances | nearby_unsupported | error | None / error / error | pass |
| luka_last_5_summary | date_window_filters | short | ok | player_game_summary / ok / entity_summary | pass |
| anthony_edwards_last_10_summary_no_match | game_finders | inverse_sibling | ok | player_game_summary / ok / entity_summary | pass |
| kd_ts_top_defenses_missing_filters | player_summaries_recent_form | synonym | ok | player_game_summary / ok / entity_summary | pass |
| anthony_davis_without_lebron_summary |  |  | ok | player_game_summary / no_result / no_result | fail |
| maxey_without_embiid_summary |  |  | ok | player_game_summary / no_result / no_result | fail |
| knicks_road_record | splits | inverse_sibling | ok | team_record / ok / team_record | pass |
| lakers_road_record_last_season | team_records | synonym | ok | team_record / ok / team_record | pass |
| curry_5_threes_count | streaks | inverse_sibling | ok | player_game_finder / ok / count_with_finder | pass |
| luka_40_point_count | player_stats_this_season | inverse_sibling | ok | player_game_finder / ok / count_with_finder | pass |
| celtics_120_15_threes_count_missing_filter | count_queries | sentence | ok | team_occurrence_leaders / ok / leaderboard_table | pass |
| thunder_110_point_streak | streaks | synonym | ok | team_streak_finder / ok / streak_table | pass |
| efficient_10_game_stretch | rolling_stretches | synonym | ok | player_stretch_leaderboard / ok / rolling_stretch | pass |
| team_net_rating_stretch_unsupported | rolling_stretches | synonym | ok | team_stretch_leaderboard / ok / leaderboard_table | pass |
| team_game_score_stretch_unsupported | rolling_stretches | nearby_unsupported | no_result | team_stretch_leaderboard / no_result / no_result | pass |
| jokic_embiid_recent_comparison | comparisons | short | ok | player_compare / ok / comparison | pass |
| anthony_edwards_wins_losses_split_no_match | splits | sentence | ok | player_split_summary / ok / entity_summary | pass |
| nuggets_jokic_on_off_unsupported |  |  | no_result | player_on_off / no_result / no_result | pass |
| best_5_man_lineups_unsupported |  |  | no_result | lineup_leaderboard / no_result / no_result | pass |
| best_duo_unsupported | unsupported_subjective_narrative | nearby_unsupported | error | None / error / error | pass |
| centers_rebound_leaders_wave4 | leaderboards | sentence | ok | season_leaders / ok / leaderboard_table | pass |
| rookie_scoring_leaders_wave4 | leaderboards | nearby_unsupported | ok | season_leaders / ok / leaderboard_table | pass |
| celtics_bench_scoring_boundary_wave4 | game_finders | nearby_unsupported | no_result | game_finder / no_result / no_result | pass |
| curry_home_away_last_20_split_wave4 | splits | synonym | ok | player_split_summary / ok / entity_summary | pass |
| tatum_brown_last10_comparison_wave4 | player_summaries_recent_form | inverse_sibling | ok | player_compare / ok / comparison | pass |
| celtics_tatum_on_off_boundary_wave4 |  |  | no_result | player_on_off / no_result / no_result | pass |
| lebron_durant_comparison_wave4 | comparisons | canonical | ok | player_compare / ok / comparison | pass |
| bare_lebron_kd_ambiguous_boundary_v1 | comparisons | nearby_unsupported | no_result | player_compare / no_result / no_result | pass |
| bare_lebron_durant_ambiguous_boundary_v1 | comparisons | nearby_unsupported | no_result | player_compare / no_result / no_result | pass |
| bare_jokic_embiid_ambiguous_boundary_v1 | comparisons | nearby_unsupported | no_result | player_compare / no_result / no_result | pass |
| bulls_finals_record_wave4 | playoff_history | short | ok | playoff_history / ok / playoff_history | pass |
| heat_knicks_playoff_series_record_wave4 | playoff_history | synonym | ok | playoff_matchup_history / ok / playoff_matchup_history | pass |
| top_scorer_feb_14_2026_wave4 |  |  | no_result | top_player_games / no_result / no_result | pass |
| best_perimeter_defenders_wave4 |  |  | error | None / error / error | pass |
| mvp_right_now_wave4 |  |  | error | None / error / error | pass |
| lineups_edwards_gobert_wave4 |  |  | no_result | lineup_summary / no_result / no_result | pass |
| leaders_in_steals_wave5 | leaderboards | short | ok | season_leaders / ok / leaderboard_table | pass |
| luka_last_10_summary_wave5 | player_summaries_recent_form | short | ok | player_game_summary / ok / entity_summary | pass |
| lakers_celtics_playoff_matchup_history_wave5 | playoff_history | sentence | ok | playoff_matchup_history / ok / playoff_matchup_history | pass |
| compare_lebron_durant_wave5 | comparisons | sentence | ok | player_compare / ok / comparison | pass |
| question_form_lebron_durant_comparison_wave2b | comparisons | sentence | ok | player_compare / ok / comparison | pass |
| celtics_bucks_comparison_this_season_wave5 | comparisons | synonym | ok | team_compare / ok / comparison | pass |
| warriors_lakers_record_this_season_wave5 | team_records | inverse_sibling | ok | team_matchup_record / ok / comparison | pass |
| jokic_game_log_vs_embiid_wave5 |  |  | no_result | player_game_finder / no_result / no_result | pass |
| lebron_stats_vs_durant_wave5 | comparisons | inverse_sibling | ok | player_game_finder / ok / game_log_table | pass |
| celtics_bench_points_wave5 |  |  | no_result | game_finder / no_result / no_result | pass |
| celtics_against_east_coast_teams_guard |  |  | no_result | team_record / no_result / no_result | pass |
| celtics_atlantic_division_guard | team_records | synonym | ok | team_record / ok / team_record | pass |
| record_against_northwest_division_teams_guard | team_records | inverse_sibling | ok | team_record_leaderboard / ok / leaderboard_table | pass |
| playoff_record_against_northwest_division_teams_guard | team_records | inverse_sibling | ok | team_record_leaderboard / ok / leaderboard_table | pass |
| celtics_atlantic_division_coverage_guard |  |  | no_result | team_record / no_result / no_result | pass |
| lakers_western_conference_pacific_division_guard |  |  | no_result | team_record / no_result / no_result | pass |
| celtics_conference_finals_atlantic_division_guard |  |  | no_result | playoff_history / no_result / no_result | pass |
| most_clutch_player_wave5 | unsupported_subjective_narrative | synonym | no_result | season_leaders / no_result / no_result | pass |
| cooled_off_lately_wave5 | streaks | nearby_unsupported | no_result | None / no_result / no_result | pass |
| true_shooting_leaders_phrase_wave5 | leaderboards | synonym | ok | season_leaders / ok / leaderboard_table | pass |
| pqa_player_stats_typo_jokc | player_stats_this_season | typo_partial | error | None / error / error | pass |
| pqa_availability_sentence_luka_plays | team_record_availability | sentence | ok | team_record / ok / team_record | fail |
| pqa_player_recent_typo_tatm | player_summaries_recent_form | typo_partial | error | None / error / error | pass |
| pqa_top_games_synonym_single_game_rebounds | top_single_game_performances | synonym | ok | top_player_games / ok / top_performances | pass |
| pqa_top_games_stat_typo_rebunds | top_single_game_performances | typo_partial | error | None / error / error | pass |
| pqa_count_unsupported_players_played | count_queries | nearby_unsupported | error | None / error / error | pass |
| pqa_count_typo_jokc_triple_doubles | count_queries | typo_partial | error | None / error / error | pass |
| pqa_finder_sentence_tatum_35_5_threes | game_finders | sentence | no_result | player_game_finder / no_result / no_result | pass |
| pqa_finder_typo_curr_5_threes | game_finders | typo_partial | error | None / error / error | pass |
| pqa_split_typo_jokc_home_away | splits | typo_partial | error | None / error / error | pass |
| pqa_streak_typo_jok_longest | streaks | typo_partial | error | None / error / error | pass |
| pqa_comparison_subjective_better_jokic_embiid | comparisons | nearby_unsupported | no_result | player_game_summary / no_result / no_result | pass |
| pqa_playoff_typo_lakeers_history | playoff_history | typo_partial | error | None / error / error | pass |
| pqa_subjective_short_mvp_candidates | unsupported_subjective_narrative | short | error | None / error / error | pass |
| pqa_subjective_typo_defnder | unsupported_subjective_narrative | typo_partial | error | None / error / error | pass |
| pqa_typo_short_jokc_stats | typo_partial_entity_behavior | short | error | None / error / error | pass |
| pqa_team_record_typo_celtcs | team_records | typo_partial | no_result | team_record_leaderboard / no_result / no_result | pass |
| pqa_typo_team_lakeers_record | typo_partial_entity_behavior | typo_partial | no_result | team_record_leaderboard / no_result / no_result | pass |
| pqa_leaderboard_stat_typo_pionts | leaderboards | typo_partial | no_result | season_leaders / no_result / no_result | pass |
| pqa_date_typo_marhc | date_window_filters | typo_partial | no_result | season_leaders / no_result / no_result | pass |
| pqa_date_unsupported_since_trade_deadline | date_window_filters | nearby_unsupported | no_result | season_team_leaders / no_result / no_result | pass |
| pqa_stretch_typo_bookr | rolling_stretches | typo_partial | no_result | player_stretch_leaderboard / no_result / no_result | pass |
| pqa_comparison_typo_kevn_durant | comparisons | typo_partial | no_result | player_compare / no_result / no_result | pass |
| pqa_typo_synonym_stephn_averages | player_stats_this_season | typo_partial | no_result | player_game_summary / no_result / no_result | pass |
| pqa_count_short_lebron_triple_doubles | count_queries | short | ok | player_game_finder / ok / count_with_finder | pass |
| pqa_split_unsupported_celtics_bench_home_away | splits | nearby_unsupported | no_result | game_finder / no_result / no_result | pass |
| pqa_streak_sentence_curry_3_threes | streaks | sentence | ok | player_streak_finder / ok / streak_table | pass |
| fan_lakers_play_next_boundary |  |  | no_result | None / no_result / no_result | pass |
| fan_unanchored_playoffs_default_note |  |  | no_result | player_game_finder / no_result / no_result | pass |
| fan_windowed_team_advanced_still_refused |  |  | no_result | game_summary / no_result / no_result | pass |
| fan_bench_leaderboard_no_coverage_refused |  |  | no_result | season_leaders / no_result / no_result | pass |
| fan_lebron_vs_jordan_career_refuses |  |  | no_result | player_compare / no_result / no_result | pass |
| fan_best_player_on_team_refuses |  |  | no_result | None / no_result / no_result | pass |
| fan_two_player_combined_refuses |  |  | no_result | None / no_result / no_result | pass |
| fan_best_playoff_performances |  |  | no_result | top_player_games / no_result / no_result | pass |
| opponent_quality_player_leaderboard_refuses_unfiltered |  |  | no_result | season_leaders / no_result / no_result | pass |
| opponent_quality_team_leaderboard_refuses_unfiltered |  |  | no_result | season_team_leaders / no_result / no_result | pass |
| team_compound_occurrence_elliptical_verbs | count_queries | canonical | ok | team_occurrence_leaders / ok / leaderboard_table | pass |
| efficient_thirty_point_games_unexecutable | leaderboards | nearby_unsupported | no_result | season_leaders / no_result / no_result | pass |
| forty_point_games_injury_condition_unsupported | leaderboards | nearby_unsupported | no_result | season_leaders / no_result / no_result | pass |
| team_leading_scorer_with_absence_unsupported | team_record_availability | nearby_unsupported | no_result | season_leaders / no_result / no_result | pass |
| k03_e2 |  |  | no_result | player_game_finder / no_result / no_result | pass |
| qualified_played_pair_source_empty |  |  | no_result | team_record / no_result / no_result | pass |
| original_window_played_pair_source_empty | team_record_availability | canonical | no_result | team_record / no_result / no_result | pass |
| original_window_played_pair_source_positive | team_record_availability | canonical | ok | team_record / ok / team_record | pass |
| original_window_played_pair_source_qualifying | team_record_availability | canonical | ok | team_record / ok / team_record | pass |
| latest_original_both_source_false | game_finders | canonical | ok | game_finder / ok / game_log_team_table | pass |
| latest_original_both_source_true | game_finders | canonical | ok | game_finder / ok / game_log_team_table | pass |
| qualified_scalar_played_source_yes | game_finders | canonical | ok | game_finder / ok / game_log_team_table | pass |
| qualified_scalar_played_source_dnp_no | game_finders | canonical | ok | game_finder / ok / game_log_team_table | pass |
| qualified_scalar_played_source_unknown | game_finders | canonical | no_result | game_finder / no_result / no_result | pass |
| qualified_original_minutes_source_dnp_no | game_finders | canonical | ok | game_finder / ok / game_log_team_table | pass |
| qualified_original_minutes_source_exact_no | game_finders | canonical | ok | game_finder / ok / game_log_team_table | pass |
| qualified_original_minutes_source_exact_yes | game_finders | canonical | ok | game_finder / ok / game_log_team_table | pass |
| qualified_original_minutes_source_unknown | game_finders | canonical | no_result | game_finder / no_result / no_result | pass |
| qualified_original_stat_pair_source_yes | game_finders | canonical | ok | game_finder / ok / game_log_team_table | pass |
| qualified_original_stat_pair_source_no | game_finders | synonym | ok | game_finder / ok / game_log_team_table | pass |
| qualified_original_stat_pair_source_zero | game_finders | synonym | ok | game_finder / ok / game_log_team_table | pass |
| qualified_original_stat_pair_source_dnp_no | game_finders | canonical | ok | game_finder / ok / game_log_team_table | pass |
| qualified_original_stat_pair_source_unknown | game_finders | canonical | no_result | game_finder / no_result / no_result | pass |
| player_comparison_team_scope_source_primary | comparisons | canonical | ok | player_compare / ok / comparison | pass |
| player_comparison_team_scope_source_question | comparisons | sentence | ok | player_compare / ok / comparison | pass |
| player_comparison_team_scope_source_count_partial_empty | comparisons | canonical | ok | player_compare / ok / comparison | pass |
| player_comparison_team_scope_source_count_empty | comparisons | canonical | no_result | player_compare / no_result / no_result | pass |
| player_comparison_team_scope_unresolved_operand | comparisons | typo_partial | no_result | player_compare / no_result / no_result | pass |
| medical_subject_team_unavailable | team_records | canonical | no_result | team_record / no_result / no_result | pass |
| medical_subject_comparison_unavailable | comparisons | canonical | no_result | player_compare / no_result / no_result | pass |
| medical_subject_team_played_control | team_records | canonical | ok | team_record / ok / team_record | pass |
| k09_t1 | streaks | canonical | ok | team_streak_finder / ok / streak_table | pass |
| k09_p1 | streaks | canonical | ok | player_streak_finder / ok / streak_table | pass |
| k09_r1 | streaks | canonical | ok | team_streak_finder / ok / streak_table | pass |
| k09_r2 | streaks | canonical | ok | player_streak_finder / ok / streak_table | pass |
| k09_w1 | rolling_stretches | canonical | ok | team_stretch_leaderboard / ok / leaderboard_table | pass |
| k09_w2 | rolling_stretches | canonical | ok | player_stretch_leaderboard / ok / rolling_stretch | pass |
| k09_c1 | streaks | canonical | ok | player_streak_finder / ok / streak_table | pass |
| k09_c2 | streaks | canonical | ok | player_streak_finder / ok / streak_table | pass |
| k09_r2_synonym_control | streaks | synonym | ok | player_streak_finder / ok / streak_table | pass |
| k09_w1_last_n_control | team_records | inverse_sibling | ok | team_record / ok / team_record | pass |
| k09_w2_last_n_control | rolling_stretches | inverse_sibling | ok | player_stretch_leaderboard / ok / rolling_stretch | pass |
| k09_c2_single_season_control | streaks | inverse_sibling | ok | player_streak_finder / ok / streak_table | pass |
| k10_g1 | playoff_history | canonical | ok | team_record / ok / team_record | pass |
| k10_s1 | playoff_history | canonical | ok | playoff_history / ok / playoff_history | pass |
| k10_a1 | playoff_history | canonical | ok | playoff_appearances / ok / leaderboard_table | pass |
| k10_r1 | playoff_history | canonical | ok | playoff_history / ok / playoff_history | pass |
| k10_q1 | playoff_history | canonical | ok | team_record / ok / team_record | pass |
| k10_f1 | playoff_history | canonical | ok | playoff_appearances / ok / leaderboard_table | pass |
| k10_t1 | playoff_history | canonical | ok | playoff_history / ok / playoff_history | pass |
| k10_t2 | playoff_history | canonical | ok | playoff_history / ok / playoff_history | pass |
| k10_f1_seattle | playoff_history | synonym | ok | playoff_appearances / ok / leaderboard_table | pass |
| k10_s1_postseason | playoff_history | synonym | ok | playoff_history / ok / playoff_history | pass |
| k11_l1 | top_single_game_performances | canonical | ok | top_player_games / ok / top_performances | pass |
| k11_l2 | top_single_game_performances | canonical | ok | top_player_games / ok / top_performances | pass |
| k11_t1 | game_finders | canonical | ok | player_game_finder / ok / game_log_table | pass |
| k11_t2 | game_finders | canonical | ok | player_game_finder / ok / game_log_table | pass |
| k11_r1 | game_finders | canonical | ok | player_game_finder / ok / game_log_table | pass |
| k11_r2 | game_finders | canonical | ok | player_game_finder / ok / game_log_table | pass |
| k11_p1 | game_finders | canonical | ok | player_game_finder / ok / game_log_table | pass |
| k11_p2 | game_finders | canonical | ok | player_game_finder / ok / game_log_table | pass |
| k11_p3 | game_finders | canonical | ok | player_game_finder / ok / game_log_table | pass |
| k11_c1 | game_finders | canonical | ok | player_game_finder / ok / game_log_table | pass |
| k11_r2_leading_season | game_finders | sentence | ok | player_game_finder / ok / game_log_table | pass |
| k12_s1 | player_stats_this_season | canonical | ok | player_game_summary / ok / entity_summary | pass |
| k12_r1 | team_records | canonical | ok | team_record / ok / team_record | pass |
| k12_b1 | leaderboards | canonical | ok | season_leaders / ok / leaderboard_table | pass |
| k12_c1 | count_queries | canonical | ok | player_occurrence_leaders / ok / leaderboard_table | pass |
| k12_l1 | game_finders | canonical | ok | player_game_finder / ok / game_log_table | pass |
| k12_x1 | splits | canonical | ok | team_split_summary / ok / entity_summary | pass |
| k12_m1 | comparisons | canonical | ok | player_compare / ok / comparison | pass |
| k12_z1 | count_queries | canonical | ok | player_game_finder / ok / unknown | pass |
| k12_e1 | game_finders | canonical | no_result | player_game_finder / no_result / no_result | pass |
| k12_n1 | player_stats_this_season | canonical | no_result | player_game_summary / no_result / no_result | pass |
| k12_h1 | player_stats_this_season | canonical | ok | player_game_summary / ok / entity_summary | pass |
| k12_r1_win_loss | team_records | synonym | ok | team_record / ok / team_record | pass |
| k08_original_mixed_qualified_empty |  |  | no_result | team_record / no_result / no_result | pass |
| k08_pair_missing_nonempty |  |  | ok | team_record / no_result / no_result | fail |
| k08_pair_missing_zero |  |  | no_result | team_record / no_result / no_result | fail |
| k08_pair_missing_zero_count |  |  | ok | game_finder / no_result / no_result | fail |

## Product Decisions Needed

_None._

## Suspicious Rows

| Case | Family | Flags |
|---|---|---|
| suns_without_booker |  | expected_ok_returned_non_ok |
| suns_without_booker_shorthand |  | expected_ok_returned_non_ok |
| bucks_without_giannis |  | expected_ok_returned_non_ok |
| knicks_without_brunson |  | expected_ok_returned_non_ok |
| lakers_record_without_luka_public_sweep | team_record_availability | expected_ok_returned_non_ok |
| pqa_availability_synonym_reaves_available | team_record_availability | expected_ok_returned_non_ok |
| warriors_wins_without_curry |  | expected_ok_returned_non_ok |
| anthony_davis_without_lebron_summary |  | expected_ok_returned_non_ok |
| maxey_without_embiid_summary |  | expected_ok_returned_non_ok |
| k08_pair_missing_nonempty |  | expected_ok_returned_non_ok |
| k08_pair_missing_zero_count |  | expected_ok_returned_non_ok |

## Human Review Worksheet

### Player stats this season

- Coverage questions: `['Do player-season fragments, sentences, and aliases stay on the player summary route?', 'Do unresolved player names fail cleanly without a broad summary?']`
- [ ] Examples represent real public usage.
- [ ] Representative outputs have correct scope and answer shape.
- [ ] Missing variants are resolved or recorded as follow-up.
- Reviewer notes:

### Team records

- Coverage questions: `['Do single-team record phrasings preserve location, season, opponent, conference, and division qualifiers?', 'Do matchup and no-subject division leaderboard siblings route intentionally while mixed conference-plus-division and playoff division siblings avoid broad fallback?']`
- [ ] Examples represent real public usage.
- [ ] Representative outputs have correct scope and answer shape.
- [ ] Missing variants are resolved or recorded as follow-up.
- Reviewer notes:

### Team record with or without player

- Coverage questions: `['Do presence and absence wording stay on the team-record route?', 'Does compound or unresolved availability fail cleanly without a broad record?']`
- [ ] Examples represent real public usage.
- [ ] Representative outputs have correct scope and answer shape.
- [ ] Missing variants are resolved or recorded as follow-up.
- Reviewer notes:

### Player summaries and recent form

- Coverage questions: `['Do recent-form and last-N phrases preserve player summary scope?', 'Do comparison siblings and unresolved player names avoid broad fallback?']`
- [ ] Examples represent real public usage.
- [ ] Representative outputs have correct scope and answer shape.
- [ ] Missing variants are resolved or recorded as follow-up.
- Reviewer notes:

### Leaderboards

- Coverage questions: `['Do stat aliases and filters remain attached to the requested leaderboard?', 'Do top-single-game and unsupported-stat siblings avoid default-points fallback?']`
- [ ] Examples represent real public usage.
- [ ] Representative outputs have correct scope and answer shape.
- [ ] Missing variants are resolved or recorded as follow-up.
- Reviewer notes:

### Top single-game performances

- Coverage questions: `['Do single-game phrases remain distinct from per-game season leaderboards?', 'Do stat typos fail cleanly without falling back to scoring games?']`
- [ ] Examples represent real public usage.
- [ ] Representative outputs have correct scope and answer shape.
- [ ] Missing variants are resolved or recorded as follow-up.
- Reviewer notes:

### Count queries

- Coverage questions: `['Do count fragments retain the requested player, event, and window?', 'Do unsupported broad-count and typo forms avoid unrelated answers?']`
- [ ] Examples represent real public usage.
- [ ] Representative outputs have correct scope and answer shape.
- [ ] Missing variants are resolved or recorded as follow-up.
- Reviewer notes:

### Game finders

- Coverage questions: `['Do finder fragments and sentences retain all threshold and context filters?', 'Do empty samples and unresolved players avoid broad finder results?']`
- [ ] Examples represent real public usage.
- [ ] Representative outputs have correct scope and answer shape.
- [ ] Missing variants are resolved or recorded as follow-up.
- Reviewer notes:

### Splits

- Coverage questions: `['Do player and team split qualifiers route to the intended split result?', 'Do unsupported role combinations and unresolved players fail cleanly?']`
- [ ] Examples represent real public usage.
- [ ] Representative outputs have correct scope and answer shape.
- [ ] Missing variants are resolved or recorded as follow-up.
- Reviewer notes:

### Streaks

- Coverage questions: `['Do longest/current streak phrases preserve thresholds and player scope?', 'Do subjective trend and typo forms avoid broad streak or finder fallback?']`
- [ ] Examples represent real public usage.
- [ ] Representative outputs have correct scope and answer shape.
- [ ] Missing variants are resolved or recorded as follow-up.
- Reviewer notes:

### Rolling stretches

- Coverage questions: `['Do rolling-window phrases preserve player, metric, and window size?', 'Do unsupported team and unresolved-player forms fail cleanly?']`
- [ ] Examples represent real public usage.
- [ ] Representative outputs have correct scope and answer shape.
- [ ] Missing variants are resolved or recorded as follow-up.
- Reviewer notes:

### Comparisons

- Coverage questions: `['Do objective comparison phrases remain separate from subjective winner questions?', 'Do team, player, and matchup comparison siblings route intentionally?']`
- [ ] Examples represent real public usage.
- [ ] Representative outputs have correct scope and answer shape.
- [ ] Missing variants are resolved or recorded as follow-up.
- Reviewer notes:

### Playoff history

- Coverage questions: `['Do history, matchup, appearance, and round phrases preserve playoff scope?', 'Do opponent-quality siblings and unresolved teams avoid broad playoff fallback?']`
- [ ] Examples represent real public usage.
- [ ] Representative outputs have correct scope and answer shape.
- [ ] Missing variants are resolved or recorded as follow-up.
- Reviewer notes:

### Date and window filters

- Coverage questions: `['Do exact dates, month windows, relative windows, and date anchors stay attached?', 'Do malformed or unsupported anchors avoid full-scope fallback?']`
- [ ] Examples represent real public usage.
- [ ] Representative outputs have correct scope and answer shape.
- [ ] Missing variants are resolved or recorded as follow-up.
- Reviewer notes:

### Unsupported subjective and narrative questions

- Coverage questions: `['Do subjective and narrative questions decline cleanly?', 'Does wording variation avoid accidental leaderboard or summary fallback?']`
- [ ] Examples represent real public usage.
- [ ] Representative outputs have correct scope and answer shape.
- [ ] Missing variants are resolved or recorded as follow-up.
- Reviewer notes:

### Typo and partial-entity guardrails

- Coverage questions: `['Do unresolved entities fail clearly instead of widening query scope?', 'Which typo and partial-name forms should remain unsupported by product decision?']`
- [ ] Examples represent real public usage.
- [ ] Representative outputs have correct scope and answer shape.
- [ ] Missing variants are resolved or recorded as follow-up.
- Reviewer notes:

## What To Send ChatGPT

Send ChatGPT this file:

`outputs/raw_query_answer_qa/r2_validation/product_review.md`

Use this exact instruction block:

```text
Review this NBA Tools Raw QA product-review artifact as a product coverage
audit. Do not treat machine pass counts as sufficient. For each feature
family:
1. Decide whether the examples represent real public usage.
2. Flag missing canonical, short, sentence, synonym, sibling/inverse,
   nearby-unsupported, or typo/partial variants.
3. Review the representative answer outputs for wrong scope, misleading
   answers, and broad fallback.
4. Separate behavior bugs from corpus gaps and product decisions.
5. Return a family-by-family table with verdict, missing cases, suspicious
   outputs, and recommended next action.
```
