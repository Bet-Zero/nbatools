#!/bin/sh
cd -- "$(dirname -- "$0")" || exit 1
found=0
for runtime in python3 python; do
    if "$runtime" -c 'import nba_api' >/dev/null 2>&1; then
        "$runtime" run_capture.py
        found=1
        break
    fi
done
if [ "$found" -eq 0 ]; then
    python3 run_capture.py
fi
printf '
Return readiness-capture/collection.zip, including after a failure.
'
printf 'Press Return to close.'
read -r ignored
